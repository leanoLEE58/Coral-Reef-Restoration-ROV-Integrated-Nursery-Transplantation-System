# ui/model3d_widget.py
from OpenGL.raw.GLUT import glutSolidSphere
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QSlider, QLabel, QCheckBox, QPushButton
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QVector3D, QMatrix4x4, QColor
import numpy as np
from OpenGL.GL import *
from OpenGL.GLU import *
from PyQt5.QtOpenGL import QGLWidget
from OpenGL.GLUT import *
import sys
from OpenGL.GLUT import *
import sys

# 确保这段代码在使用glutSolidSphere之前执行
if not glutGet(GLUT_INIT_STATE):
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH)
class Model3DWidget(QGLWidget):
    """3D模型显示组件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(400, 300)

        # 旋转角度
        self.xRot = 0
        self.yRot = 0
        self.zRot = 0

        # 模型位置和缩放
        self.xPos = 0.0
        self.yPos = 0.0
        self.zPos = -5.0
        self.scale = 1.0

        # 鼠标位置
        self.lastPos = None

        # 模型属性
        self.attitude = {
            'roll': 0.0,  # 横滚角(度)
            'pitch': 0.0,  # 俯仰角(度)
            'yaw': 0.0  # 偏航角(度)
        }

        # 显示选项
        self.show_grid = True
        self.show_axes = True
        self.show_info = True

        # 光照开关
        self.lighting_enabled = True

        # 背景颜色 (深蓝色 - 模拟水下)
        self.bg_color = QColor(10, 30, 70)

    def initializeGL(self):
        """OpenGL初始化"""
        # 设置背景色
        glClearColor(self.bg_color.redF(), self.bg_color.greenF(),
                     self.bg_color.blueF(), 1.0)

        # 启用深度测试
        glEnable(GL_DEPTH_TEST)

        # 设置光照
        if self.lighting_enabled:
            self._setup_lighting()

        # 初始化材质
        self._setup_materials()

    def _setup_lighting(self):
        """设置光照"""
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)

        # 环境光
        ambient = [0.2, 0.2, 0.2, 1.0]
        glLightfv(GL_LIGHT0, GL_AMBIENT, ambient)

        # 漫反射光
        diffuse = [0.8, 0.8, 0.8, 1.0]
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse)

        # 镜面反射光
        specular = [1.0, 1.0, 1.0, 1.0]
        glLightfv(GL_LIGHT0, GL_SPECULAR, specular)

        # 光源位置
        position = [0.0, 0.0, 10.0, 1.0]
        glLightfv(GL_LIGHT0, GL_POSITION, position)

    def _setup_materials(self):
        """设置材质"""
        # 启用颜色材质跟踪
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE)

        # 设置材质属性
        mat_ambient = [0.2, 0.2, 0.2, 1.0]
        mat_diffuse = [0.8, 0.8, 0.8, 1.0]
        mat_specular = [1.0, 1.0, 1.0, 1.0]
        mat_shininess = [50.0]

        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient)
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse)
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular)
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess)

    def resizeGL(self, width, height):
        """调整OpenGL视口"""
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()

        aspect = width / float(height or 1)
        gluPerspective(45.0, aspect, 0.1, 100.0)

        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):
        """绘制场景"""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()

        # 设置相机位置
        glTranslatef(self.xPos, self.yPos, self.zPos)

        # 应用用户旋转
        glRotatef(self.xRot / 16.0, 1.0, 0.0, 0.0)
        glRotatef(self.yRot / 16.0, 0.0, 1.0, 0.0)
        glRotatef(self.zRot / 16.0, 0.0, 0.0, 1.0)

        # 应用缩放
        glScalef(self.scale, self.scale, self.scale)

        # 绘制网格
        if self.show_grid:
            self._draw_grid()

        # 绘制坐标轴
        if self.show_axes:
            self._draw_axes()

        # 保存当前矩阵
        glPushMatrix()

        # 应用机器人姿态
        glRotatef(self.attitude['roll'], 0.0, 0.0, 1.0)  # 横滚角
        glRotatef(self.attitude['pitch'], 1.0, 0.0, 0.0)  # 俯仰角
        glRotatef(self.attitude['yaw'], 0.0, 1.0, 0.0)  # 偏航角

        # 绘制机器人模型
        self._draw_rov_model()

        # 恢复矩阵
        glPopMatrix()

        # 绘制信息文本
        if self.show_info:
            self._draw_info()

    def _draw_grid(self):
        """绘制参考网格"""
        glDisable(GL_LIGHTING)

        # 设置网格颜色和线宽
        glColor3f(0.3, 0.3, 0.3)
        glLineWidth(1.0)

        # 绘制网格线
        size = 10.0  # 网格大小
        step = 1.0  # 网格间距

        glBegin(GL_LINES)

        # X方向线
        for i in np.arange(-size, size + step, step):
            glVertex3f(i, -size, 0)
            glVertex3f(i, size, 0)

        # Y方向线
        for i in np.arange(-size, size + step, step):
            glVertex3f(-size, i, 0)
            glVertex3f(size, i, 0)

        glEnd()

        if self.lighting_enabled:
            glEnable(GL_LIGHTING)

    def _draw_axes(self):
        """绘制坐标轴"""
        glDisable(GL_LIGHTING)

        # 设置线宽
        glLineWidth(3.0)

        glBegin(GL_LINES)

        # X轴 (红色)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(1.0, 0.0, 0.0)

        # Y轴 (绿色)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 1.0, 0.0)

        # Z轴 (蓝色)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 1.0)

        glEnd()

        if self.lighting_enabled:
            glEnable(GL_LIGHTING)

    def _draw_rov_model(self):
        """绘制ROV模型"""
        # 如果有详细的模型数据，可以从文件加载
        # 这里使用简单几何体表示ROV

        # 设置模型颜色
        glColor3f(1.0, 0.7, 0.2)  # 橙黄色

        # 主体 (长方体)
        self._draw_box(1.5, 0.8, 0.5)

        # 左右推进器
        glPushMatrix()
        glTranslatef(0.0, 0.5, 0.0)
        glRotatef(90, 0.0, 1.0, 0.0)
        glColor3f(0.2, 0.2, 0.7)  # 蓝色
        self._draw_cylinder(0.15, 0.15, 0.4)
        glPopMatrix()

        glPushMatrix()
        glTranslatef(0.0, -0.5, 0.0)
        glRotatef(90, 0.0, 1.0, 0.0)
        glColor3f(0.2, 0.2, 0.7)  # 蓝色
        self._draw_cylinder(0.15, 0.15, 0.4)
        glPopMatrix()

        # 前后推进器
        glPushMatrix()
        glTranslatef(0.8, 0.3, 0.0)
        glColor3f(0.2, 0.2, 0.7)  # 蓝色
        self._draw_cylinder(0.15, 0.15, 0.3)
        glPopMatrix()

        glPushMatrix()
        glTranslatef(0.8, -0.3, 0.0)
        glColor3f(0.2, 0.2, 0.7)  # 蓝色
        self._draw_cylinder(0.15, 0.15, 0.3)
        glPopMatrix()

        # 垂直推进器
        glPushMatrix()
        glTranslatef(0.0, 0.0, 0.3)
        glRotatef(90, 1.0, 0.0, 0.0)
        glColor3f(0.2, 0.2, 0.7)  # 蓝色
        self._draw_cylinder(0.15, 0.15, 0.3)
        glPopMatrix()

        # 摄像头
        glPushMatrix()
        glTranslatef(0.8, 0.0, 0.0)
        glColor3f(0.1, 0.1, 0.1)  # 黑色
        self._draw_sphere(0.2, 16, 16)
        glPopMatrix()

    def _draw_box(self, length, width, height):
        """绘制长方体"""
        l, w, h = length / 2, width / 2, height / 2

        # 定义顶点
        vertices = [
            # 前面
            [-l, -w, h], [l, -w, h], [l, w, h], [-l, w, h],
            # 后面
            [-l, -w, -h], [l, -w, -h], [l, w, -h], [-l, w, -h]
        ]

        # 定义面
        faces = [
            [0, 1, 2, 3],  # 前面
            [1, 5, 6, 2],  # 右面
            [5, 4, 7, 6],  # 后面
            [4, 0, 3, 7],  # 左面
            [3, 2, 6, 7],  # 上面
            [4, 5, 1, 0]  # 下面
        ]

        # 定义法线
        normals = [
            [0, 0, 1],  # 前面
            [1, 0, 0],  # 右面
            [0, 0, -1],  # 后面
            [-1, 0, 0],  # 左面
            [0, 1, 0],  # 上面
            [0, -1, 0]  # 下面
        ]

        # 绘制每个面
        glBegin(GL_QUADS)

        for i, face in enumerate(faces):
            glNormal3fv(normals[i])
            for vertex_index in face:
                glVertex3fv(vertices[vertex_index])

        glEnd()

    def _draw_sphere(self, radius, slices, stacks):
        """自定义球体绘制函数，替代glutSolidSphere"""
        for i in range(stacks):
            lat0 = np.pi * (-0.5 + (i / stacks))
            z0 = np.sin(lat0) * radius
            zr0 = np.cos(lat0) * radius

            lat1 = np.pi * (-0.5 + ((i + 1) / stacks))
            z1 = np.sin(lat1) * radius
            zr1 = np.cos(lat1) * radius

            glBegin(GL_QUAD_STRIP)
            for j in range(slices + 1):
                lng = 2 * np.pi * (j / slices)
                x = np.cos(lng)
                y = np.sin(lng)

                glNormal3f(x * zr0, y * zr0, z0)
                glVertex3f(x * zr0, y * zr0, z0)

                glNormal3f(x * zr1, y * zr1, z1)
                glVertex3f(x * zr1, y * zr1, z1)
            glEnd()

    def _draw_cylinder(self, base_radius, top_radius, height, slices=16, stacks=1):
        """绘制圆柱体"""
        # 绘制侧面
        glBegin(GL_QUAD_STRIP)

        for i in range(slices + 1):
            angle = 2.0 * np.pi * i / slices
            x = np.cos(angle)
            y = np.sin(angle)

            # 计算表面法线
            normal = [x, y, 0.0]
            length = np.sqrt(normal[0] ** 2 + normal[1] ** 2 + normal[2] ** 2)
            normal = [comp / length for comp in normal]

            glNormal3fv(normal)
            glVertex3f(top_radius * x, top_radius * y, height / 2)
            glVertex3f(base_radius * x, base_radius * y, -height / 2)

        glEnd()

        # 绘制顶面和底面
        for side in [-1, 1]:
            radius = top_radius if side == 1 else base_radius
            z = height / 2 * side

            glBegin(GL_TRIANGLE_FAN)
            glNormal3f(0.0, 0.0, side)
            glVertex3f(0.0, 0.0, z)

            for i in range(slices + 1):
                angle = 2.0 * np.pi * i / slices * (1 if side == 1 else -1)
                x = np.cos(angle) * radius
                y = np.sin(angle) * radius
                glVertex3f(x, y, z)

            glEnd()

    def _draw_info(self):
        """绘制信息文本"""
        # 在真实实现中需要渲染文本，这里只是占位
        pass

    def set_attitude(self, roll, pitch, yaw):
        """设置模型姿态"""
        self.attitude['roll'] = roll
        self.attitude['pitch'] = pitch
        self.attitude['yaw'] = yaw
        self.updateGL()

    def toggle_grid(self, show):
        """切换网格显示"""
        self.show_grid = show
        self.updateGL()

    def toggle_axes(self, show):
        """切换坐标轴显示"""
        self.show_axes = show
        self.updateGL()

    def toggle_info(self, show):
        """切换信息显示"""
        self.show_info = show
        self.updateGL()

    def toggle_lighting(self, enabled):
        """切换光照"""
        self.lighting_enabled = enabled
        if enabled:
            glEnable(GL_LIGHTING)
        else:
            glDisable(GL_LIGHTING)
        self.updateGL()

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        self.lastPos = event.pos()

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if self.lastPos is None:
            return

        dx = event.x() - self.lastPos.x()
        dy = event.y() - self.lastPos.y()

        if event.buttons() & Qt.LeftButton:
            # 旋转视图
            self.yRot += 8 * dx
            self.xRot += 8 * dy
            self.updateGL()
        elif event.buttons() & Qt.RightButton:
            # 缩放视图
            self.scale *= pow(1.1, dy / 10.0)
            self.scale = max(0.1, min(self.scale, 10.0))
            self.updateGL()
        elif event.buttons() & Qt.MiddleButton:
            # 平移视图
            self.xPos += dx * 0.01
            self.yPos -= dy * 0.01
            self.updateGL()

        self.lastPos = event.pos()

    def wheelEvent(self, event):
        """鼠标滚轮事件"""
        delta = event.angleDelta().y()
        self.zPos += delta * 0.01
        self.updateGL()


class Model3DControlWidget(QWidget):
    """3D模型显示控制器组件"""

    def __init__(self, parent=None):
        super().__init__(parent)

        # 创建3D视图
        self.model_view = Model3DWidget()

        # 初始化UI
        self._init_ui()

    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 添加3D视图
        main_layout.addWidget(self.model_view)

        # 控制面板
        control_layout = QHBoxLayout()

        # 横滚角控制
        roll_layout = QVBoxLayout()
        roll_layout.addWidget(QLabel("横滚角"))
        self.roll_slider = QSlider(Qt.Horizontal)
        self.roll_slider.setRange(-180, 180)
        self.roll_slider.setValue(0)
        self.roll_slider.valueChanged.connect(self._update_attitude)
        roll_layout.addWidget(self.roll_slider)
        control_layout.addLayout(roll_layout)

        # 俯仰角控制
        pitch_layout = QVBoxLayout()
        pitch_layout.addWidget(QLabel("俯仰角"))
        self.pitch_slider = QSlider(Qt.Horizontal)
        self.pitch_slider.setRange(-90, 90)
        self.pitch_slider.setValue(0)
        self.pitch_slider.valueChanged.connect(self._update_attitude)
        pitch_layout.addWidget(self.pitch_slider)
        control_layout.addLayout(pitch_layout)

        # 偏航角控制
        yaw_layout = QVBoxLayout()
        yaw_layout.addWidget(QLabel("偏航角"))
        self.yaw_slider = QSlider(Qt.Horizontal)
        self.yaw_slider.setRange(-180, 180)
        self.yaw_slider.setValue(0)
        self.yaw_slider.valueChanged.connect(self._update_attitude)
        yaw_layout.addWidget(self.yaw_slider)
        control_layout.addLayout(yaw_layout)

        main_layout.addLayout(control_layout)

        # 显示选项
        options_layout = QHBoxLayout()

        # 网格显示选项
        self.grid_check = QCheckBox("显示网格")
        self.grid_check.setChecked(True)
        self.grid_check.toggled.connect(self.model_view.toggle_grid)
        options_layout.addWidget(self.grid_check)

        # 坐标轴显示选项
        self.axes_check = QCheckBox("显示坐标轴")
        self.axes_check.setChecked(True)
        self.axes_check.toggled.connect(self.model_view.toggle_axes)
        options_layout.addWidget(self.axes_check)

        # 光照选项
        self.lighting_check = QCheckBox("启用光照")
        self.lighting_check.setChecked(True)
        self.lighting_check.toggled.connect(self.model_view.toggle_lighting)
        options_layout.addWidget(self.lighting_check)

        # 重置视图按钮
        self.reset_btn = QPushButton("重置视图")
        self.reset_btn.clicked.connect(self._reset_view)
        options_layout.addWidget(self.reset_btn)

        main_layout.addLayout(options_layout)

    def _update_attitude(self):
        """更新姿态"""
        roll = self.roll_slider.value()
        pitch = self.pitch_slider.value()
        yaw = self.yaw_slider.value()

        self.model_view.set_attitude(roll, pitch, yaw)

    def _reset_view(self):
        """重置视图"""
        # 重置角度滑块
        self.roll_slider.setValue(0)
        self.pitch_slider.setValue(0)
        self.yaw_slider.setValue(0)

        # 重置视图参数
        self.model_view.xRot = 0
        self.model_view.yRot = 0
        self.model_view.zRot = 0
        self.model_view.xPos = 0.0
        self.model_view.yPos = 0.0
        self.model_view.zPos = -5.0
        self.model_view.scale = 1.0

        self.model_view.updateGL()

    def set_attitude(self, roll, pitch, yaw):
        """设置姿态 (供外部调用)"""
        self.roll_slider.setValue(int(roll))
        self.pitch_slider.setValue(int(pitch))
        self.yaw_slider.setValue(int(yaw))