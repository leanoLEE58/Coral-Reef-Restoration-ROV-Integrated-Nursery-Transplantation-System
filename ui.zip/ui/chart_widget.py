# ui/chart_widget.py
import pyqtgraph as pg
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QLabel, QPushButton
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QRectF
from PyQt5.QtGui import QPainter, QColor, QPen
import numpy as np
import time
from OpenGL.GLUT import *
import sys

class RealtimeChartWidget(QWidget):
    """实时数据曲线图组件"""

    def __init__(self, title="实时数据", parent=None):
        super().__init__(parent)
        self.title = title
        self.history_length = 300  # 默认显示300个数据点
        self.data_dict = {}  # 存储多条曲线的数据
        self.update_interval = 100  # 更新间隔(毫秒)

        # 初始化UI
        self._init_ui()

        # 设置更新定时器
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_plot)
        self.timer.start(self.update_interval)

        # 上次更新时间
        self.last_update = time.time()

    def _init_ui(self):
        """初始化UI"""
        layout = QVBoxLayout(self)

        # 顶部控制栏
        control_layout = QHBoxLayout()

        # 图表类型选择
        self.chart_type_combo = QComboBox()
        self.chart_type_combo.addItems(["折线图", "阶梯图", "点图", "线条+点"])
        self.chart_type_combo.currentIndexChanged.connect(self._on_chart_type_changed)
        control_layout.addWidget(QLabel("图表类型:"))
        control_layout.addWidget(self.chart_type_combo)

        # 时间跨度选择
        self.timespan_combo = QComboBox()
        self.timespan_combo.addItems(["10秒", "30秒", "1分钟", "5分钟", "全部"])
        self.timespan_combo.currentIndexChanged.connect(self._on_timespan_changed)
        control_layout.addWidget(QLabel("时间跨度:"))
        control_layout.addWidget(self.timespan_combo)

        # 清除按钮
        self.clear_btn = QPushButton("清除")
        self.clear_btn.clicked.connect(self.clear_data)
        control_layout.addWidget(self.clear_btn)

        # 自动缩放按钮
        self.autoscale_btn = QPushButton("自动缩放")
        self.autoscale_btn.setCheckable(True)
        self.autoscale_btn.setChecked(True)
        self.autoscale_btn.clicked.connect(self._on_autoscale_toggled)
        control_layout.addWidget(self.autoscale_btn)

        control_layout.addStretch()
        layout.addLayout(control_layout)

        # 创建图表
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground('k')
        self.plot_widget.setTitle(self.title, color='w', size='12pt')
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)

        # 设置坐标轴
        self.plot_widget.setLabel('left', 'Value', color='white', size='10pt')
        self.plot_widget.setLabel('bottom', 'Time', units='s', color='white', size='10pt')

        # 添加图例
        self.plot_widget.addLegend()

        layout.addWidget(self.plot_widget)

        # 创建曲线字典
        self.curves = {}

    def add_data_line(self, name, color=None, style=None):
        """
        添加一条数据曲线

        Args:
            name: 曲线名称
            color: 曲线颜色 (可选)
            style: 曲线样式 (可选, 'line', 'step', 'scatter', 'line+scatter')

        Returns:
            成功添加则返回True
        """
        if name in self.curves:
            return False

        # 如果未指定颜色，使用预定义颜色
        if color is None:
            colors = ['r', 'g', 'b', 'c', 'm', 'y', 'w']
            color = colors[len(self.curves) % len(colors)]

        # 如果未指定样式，使用当前选择
        if style is None:
            style_map = ["line", "step", "scatter", "line+scatter"]
            style = style_map[self.chart_type_combo.currentIndex()]

        # 创建空数据数组
        self.data_dict[name] = {
            'time': np.array([]),
            'value': np.array([]),
            'color': color,
            'style': style
        }

        # 创建曲线
        pen = pg.mkPen(color=color, width=2)

        if style == 'line':
            self.curves[name] = self.plot_widget.plot(
                [], [], pen=pen, name=name
            )
        elif style == 'step':
            self.curves[name] = self.plot_widget.plot(
                [], [], pen=pen, name=name, stepMode=True
            )
        elif style == 'scatter':
            self.curves[name] = pg.ScatterPlotItem(
                pen=pen, brush=pg.mkBrush(color), name=name
            )
            self.plot_widget.addItem(self.curves[name])
        elif style == 'line+scatter':
            self.curves[name] = self.plot_widget.plot(
                [], [], pen=pen, name=name,
                symbol='o', symbolSize=5, symbolBrush=pg.mkBrush(color)
            )

        return True

    def add_data_point(self, name, value, timestamp=None):
        """
        添加一个数据点到指定曲线

        Args:
            name: 曲线名称
            value: 数据值
            timestamp: 时间戳 (如果不提供则使用当前时间)

        Returns:
            成功添加则返回True
        """
        if name not in self.data_dict:
            self.add_data_line(name)

        if timestamp is None:
            timestamp = time.time() - self.last_update

        # 添加数据点
        self.data_dict[name]['time'] = np.append(self.data_dict[name]['time'], timestamp)
        self.data_dict[name]['value'] = np.append(self.data_dict[name]['value'], value)

        # 限制数据点数量
        if len(self.data_dict[name]['time']) > self.history_length:
            self.data_dict[name]['time'] = self.data_dict[name]['time'][-self.history_length:]
            self.data_dict[name]['value'] = self.data_dict[name]['value'][-self.history_length:]

        return True

    def update_plot(self):
        """更新图表显示"""
        # 计算当前时间
        current_time = time.time()
        elapsed = current_time - self.last_update

        # 更新所有曲线
        for name, curve_data in self.data_dict.items():
            if name in self.curves:
                curve = self.curves[name]
                times = curve_data['time']
                values = curve_data['value']

                if len(times) > 0:
                    style = curve_data['style']

                    if style == 'scatter':
                        curve.setData(times, values)
                    else:  # line, step, line+scatter
                        curve.setData(times, values)

        # 根据选定的时间跨度调整X轴范围
        self._adjust_time_axis()

        # 如果启用自动缩放，则调整Y轴范围
        if self.autoscale_btn.isChecked():
            self.plot_widget.enableAutoRange(axis='y')

        # 更新上次更新时间
        self.last_update = current_time

    def _adjust_time_axis(self):
        """根据选定的时间跨度调整X轴范围"""
        timespan_idx = self.timespan_combo.currentIndex()

        # 获取所有数据的最大时间
        max_time = 0
        for data in self.data_dict.values():
            if len(data['time']) > 0:
                max_time = max(max_time, data['time'][-1])

        # 设置X轴范围
        if timespan_idx == 0:  # 10秒
            self.plot_widget.setXRange(max(0, max_time - 10), max_time)
        elif timespan_idx == 1:  # 30秒
            self.plot_widget.setXRange(max(0, max_time - 30), max_time)
        elif timespan_idx == 2:  # 1分钟
            self.plot_widget.setXRange(max(0, max_time - 60), max_time)
        elif timespan_idx == 3:  # 5分钟
            self.plot_widget.setXRange(max(0, max_time - 300), max_time)
        else:  # 全部
            min_time = float('inf')
            for data in self.data_dict.values():
                if len(data['time']) > 0:
                    min_time = min(min_time, data['time'][0])

            if min_time != float('inf'):
                self.plot_widget.setXRange(min_time, max_time)

    def clear_data(self):
        """清除所有数据"""
        for name in self.data_dict:
            self.data_dict[name]['time'] = np.array([])
            self.data_dict[name]['value'] = np.array([])

        # 更新图表
        self.update_plot()

    def _on_chart_type_changed(self, index):
        """图表类型改变处理"""
        style_map = ["line", "step", "scatter", "line+scatter"]
        new_style = style_map[index]

        # 更新所有曲线的样式
        for name, data in self.data_dict.items():
            data['style'] = new_style

            # 移除旧曲线
            if name in self.curves:
                self.plot_widget.removeItem(self.curves[name])

            # 创建新曲线
            pen = pg.mkPen(color=data['color'], width=2)

            if new_style == 'line':
                self.curves[name] = self.plot_widget.plot(
                    data['time'], data['value'], pen=pen, name=name
                )
            elif new_style == 'step':
                self.curves[name] = self.plot_widget.plot(
                    data['time'], data['value'], pen=pen, name=name, stepMode=True
                )
            elif new_style == 'scatter':
                self.curves[name] = pg.ScatterPlotItem(
                    x=data['time'], y=data['value'], pen=pen,
                    brush=pg.mkBrush(data['color']), name=name
                )
                self.plot_widget.addItem(self.curves[name])
            elif new_style == 'line+scatter':
                self.curves[name] = self.plot_widget.plot(
                    data['time'], data['value'], pen=pen, name=name,
                    symbol='o', symbolSize=5, symbolBrush=pg.mkBrush(data['color'])
                )

    def _on_timespan_changed(self, index):
        """时间跨度改变处理"""
        # 调整X轴范围
        self._adjust_time_axis()

    def _on_autoscale_toggled(self, checked):
        """自动缩放切换处理"""
        if checked:
            self.plot_widget.enableAutoRange(axis='y')
        else:
            self.plot_widget.disableAutoRange(axis='y')