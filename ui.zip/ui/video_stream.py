# modules/video_stream.py
"""
视频流处理模块 - 增强版
支持RTSP流、自适应视频质量、视频录制和流畅帧缓冲
"""
import cv2
import time
import numpy as np
import logging
import threading
import queue
import socket
from PyQt5.QtCore import QThread, pyqtSignal, QMutex, QMutexLocker, QTimer
from PyQt5.QtGui import QImage

import config


class VideoProcessor:
    """视频处理器类，用于处理视频帧"""

    def __init__(self):
        """初始化视频处理器"""
        self.edge_detection_enabled = False
        self.blur_enabled = False
        self.threshold_enabled = False

        # 处理参数
        self.edge_threshold1 = 50
        self.edge_threshold2 = 150
        self.blur_kernel_size = 5
        self.threshold_value = 127
        self.threshold_max = 255

    def process(self, frame):
        """
        处理视频帧

        Args:
            frame: 要处理的视频帧

        Returns:
            处理后的视频帧
        """
        if frame is None:
            return None

        # 创建副本以避免修改原始帧
        processed = frame.copy()

        # 应用高斯模糊
        if self.blur_enabled:
            kernel_size = self.blur_kernel_size
            if kernel_size % 2 == 0:  # 确保核大小是奇数
                kernel_size += 1
            processed = cv2.GaussianBlur(processed, (kernel_size, kernel_size), 0)

        # 应用阈值处理
        if self.threshold_enabled:
            gray = cv2.cvtColor(processed, cv2.COLOR_BGR2GRAY)
            _, thresholded = cv2.threshold(gray, self.threshold_value, self.threshold_max, cv2.THRESH_BINARY)
            processed = cv2.cvtColor(thresholded, cv2.COLOR_GRAY2BGR)

        # 应用边缘检测
        if self.edge_detection_enabled:
            gray = cv2.cvtColor(processed, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, self.edge_threshold1, self.edge_threshold2)
            # 将边缘转回彩色图像以便显示
            processed = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

        return processed

    def set_edge_detection(self, enabled, threshold1=None, threshold2=None):
        """设置边缘检测参数"""
        self.edge_detection_enabled = enabled
        if threshold1 is not None:
            self.edge_threshold1 = threshold1
        if threshold2 is not None:
            self.edge_threshold2 = threshold2

    def set_blur(self, enabled, kernel_size=None):
        """设置模糊参数"""
        self.blur_enabled = enabled
        if kernel_size is not None:
            self.blur_kernel_size = kernel_size

    def set_threshold(self, enabled, threshold=None, max_val=None):
        """设置阈值处理参数"""
        self.threshold_enabled = enabled
        if threshold is not None:
            self.threshold_value = threshold
        if max_val is not None:
            self.threshold_max = max_val

    def detect_objects(self, frame):
        """
        检测图像中的对象

        Args:
            frame: 要分析的视频帧

        Returns:
            dict: 包含检测到的对象信息的字典
        """
        if frame is None:
            return {"objects": []}

        # 转为灰度图
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # 应用高斯模糊减少噪声
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)

        # 应用Canny边缘检测
        edges = cv2.Canny(blurred, self.edge_threshold1, self.edge_threshold2)

        # 查找轮廓
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # 处理检测到的轮廓
        objects = []
        for contour in contours:
            # 计算轮廓面积，过滤小轮廓
            area = cv2.contourArea(contour)
            if area < 500:  # 过滤小面积轮廓
                continue

            # 计算边界框
            x, y, w, h = cv2.boundingRect(contour)

            # 添加对象信息
            objects.append({
                "x": x,
                "y": y,
                "width": w,
                "height": h,
                "area": area,
                "center": (x + w // 2, y + h // 2)
            })

        return {
            "objects": objects,
            "count": len(objects),
            "frame_size": frame.shape[:2]  # (height, width)
        }
class VideoRecorder:
    """视频录制器"""

    def __init__(self, fps=30, output_path=None):
        self.fps = fps
        self.output_path = output_path
        self.recording = False
        self.writer = None
        self.frame_size = None

    def start(self, frame):
        """开始录制"""
        if self.recording:
            return False

        if self.output_path is None:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            self.output_path = f"video_{timestamp}.avi"

        h, w = frame.shape[:2]
        self.frame_size = (w, h)

        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        self.writer = cv2.VideoWriter(self.output_path, fourcc, self.fps, self.frame_size)

        if not self.writer.isOpened():
            return False

        self.recording = True
        return True

    def write_frame(self, frame):
        """写入帧"""
        if not self.recording or self.writer is None:
            return

        # 确保帧大小一致
        if frame.shape[1] != self.frame_size[0] or frame.shape[0] != self.frame_size[1]:
            frame = cv2.resize(frame, self.frame_size)

        self.writer.write(frame)

    def stop(self):
        """停止录制"""
        if not self.recording:
            return False

        self.recording = False
        if self.writer:
            self.writer.release()
            self.writer = None

        return True


class CameraInfo:
    """摄像头信息类"""

    def __init__(self, id=0, name="未知摄像头", is_ip_camera=False):
        self.id = id
        self.name = name
        self.is_ip_camera = is_ip_camera
        self.url = ""
        self.resolution = (0, 0)
        self.fps = 0
        self.capabilities = {}

    def to_dict(self):
        """转换为字典"""
        return {
            "id": self.id,
            "name": self.name,
            "is_ip_camera": self.is_ip_camera,
            "url": self.url,
            "resolution": self.resolution,
            "fps": self.fps,
            "capabilities": self.capabilities
        }


class StreamBuffer:
    """视频流缓冲区"""

    def __init__(self, max_size=10):
        self.buffer = queue.Queue(maxsize=max_size)
        self.mutex = QMutex()
        self.current_frame = None
        self.frame_count = 0

    def put(self, frame):
        """添加帧到缓冲区"""
        with QMutexLocker(self.mutex):
            # 确保缓冲区不会阻塞
            if self.buffer.full():
                try:
                    self.buffer.get_nowait()
                except:
                    pass
            try:
                self.buffer.put_nowait(frame)
                self.frame_count += 1
            except:
                pass

    def get(self):
        """获取最新帧"""
        with QMutexLocker(self.mutex):
            if self.buffer.empty():
                return self.current_frame

            # 取出所有帧，只保留最新的
            while not self.buffer.empty():
                try:
                    self.current_frame = self.buffer.get_nowait()
                except:
                    break

            return self.current_frame

    def clear(self):
        """清空缓冲区"""
        with QMutexLocker(self.mutex):
            while not self.buffer.empty():
                try:
                    self.buffer.get_nowait()
                except:
                    pass
            self.current_frame = None


class VideoStreamThread(QThread):
    """视频流处理线程 - 增强版"""
    # 定义信号
    frame_ready = pyqtSignal(QImage)  # QImage信号
    raw_frame_ready = pyqtSignal(np.ndarray)  # 原始帧信号
    error = pyqtSignal(str)  # 错误信号
    status_update = pyqtSignal(dict)  # 状态更新信号
    resolution_changed = pyqtSignal(int, int)  # 分辨率变化信号(宽,高)
    connection_status_changed = pyqtSignal(bool, str)  # 连接状态变化信号(是否连接,消息)

    def __init__(self, video_source=None):
        """
        初始化视频流线程

        Args:
            video_source: 视频源，可以是摄像头索引或URL
        """
        super().__init__()

        # 视频源配置
        self.video_source = video_source
        self.rtsp_url = None
        self.is_rtsp = False
        self.reconnect_interval = 5.0  # 重连间隔(秒)

        # 线程控制
        self.running = False
        self.paused = False
        self.reconnect_timer = None
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 10

        # OpenCV捕获对象
        self.cap = None

        # 视频处理
        self.frame_processor = None
        self.recorder = None
        self.is_recording = False

        # 帧缓冲
        self.frame_buffer = StreamBuffer(max_size=20)
        self.render_timer = None

        # 性能监控
        self.start_time = time.time()
        self.frame_count = 0
        self.fps_stats = []
        self.processing_times = []
        self.network_stats = {"latency": 0, "drops": 0}

        # 自适应视频质量
        self.current_resolution = (640, 480)
        self.target_fps = config.VIDEO_FPS
        self.quality_adjustment_enabled = True
        self.quality_check_interval = 5.0
        self.last_quality_check = 0

        # 日志
        self.logger = logging.getLogger("VideoStreamThread")

        # 摄像头信息
        self.camera_info = CameraInfo()

        # 设置视频源
        self.set_video_source(video_source)

    def set_video_source(self, source):
        """
        设置视频源

        Args:
            source: 视频源，可以是摄像头索引或URL
        """
        # 停止当前视频流
        was_running = self.running
        if was_running:
            self.stop()

        self.video_source = source

        # 分析视频源类型
        if source is None:
            self.video_source = config.VIDEO_SOURCE

        if isinstance(self.video_source, str) and (
                self.video_source.startswith("rtsp://") or
                self.video_source.startswith("http://") or
                self.video_source.startswith("https://")
        ):
            self.is_rtsp = True
            self.rtsp_url = self.video_source

            # 设置摄像头信息
            self.camera_info = CameraInfo(0, "网络摄像头", True)
            self.camera_info.url = self.rtsp_url
        else:
            self.is_rtsp = False
            self.rtsp_url = None

            # 设置摄像头信息
            self.camera_info = CameraInfo(int(self.video_source) if isinstance(self.video_source, (int, str)) else 0)

        # 重新启动流(如果之前在运行)
        if was_running:
            self.start()

    def set_frame_processor(self, processor):
        """
        设置帧处理器

        Args:
            processor: 一个接受并返回帧的函数
        """
        self.frame_processor = processor

    def start_recording(self, output_path=None):
        """
        开始录制视频

        Args:
            output_path: 输出文件路径，默认使用时间戳

        Returns:
            bool: 是否成功开始录制
        """
        if self.is_recording:
            return False

        # 获取当前帧
        frame = self.frame_buffer.get()
        if frame is None:
            self.error.emit("没有可用的视频帧，无法开始录制")
            return False

        # 创建录制器
        if self.recorder is None:
            self.recorder = VideoRecorder(self.target_fps, output_path)

        # 开始录制
        if self.recorder.start(frame):
            self.is_recording = True
            return True
        else:
            self.error.emit("开始录制失败")
            return False

    def stop_recording(self):
        """
        停止录制视频

        Returns:
            bool: 是否成功停止录制
        """
        if not self.is_recording or self.recorder is None:
            return False

        self.is_recording = False
        result = self.recorder.stop()

        # 显示录制完成消息
        if result:
            output_path = self.recorder.output_path
            self.status_update.emit({
                "message": f"视频已保存到: {output_path}",
                "recording": False
            })

        return result

    def pause(self):
        """暂停视频流"""
        self.paused = True

    def resume(self):
        """恢复视频流"""
        self.paused = False

    def run(self):
        """线程主函数"""
        self.running = True
        self.paused = False
        self.frame_count = 0
        self.start_time = time.time()
        self.last_quality_check = 0
        self.fps_stats = []
        self.processing_times = []
        self.network_stats = {"latency": 0, "drops": 0}

        # 清空帧缓冲
        self.frame_buffer.clear()

        # 初始化渲染定时器(在主线程)
        if self.render_timer is None:
            self.render_timer = QTimer()
            self.render_timer.timeout.connect(self._render_frame)
            self.render_timer.start(1000 // 60)  # 60Hz渲染

        # 连接到视频源
        if not self._connect_to_source():
            self.running = False
            return

        # 计算最佳缓冲区大小
        target_buffer_ms = 500  # 目标缓冲500毫秒
        buffer_size = max(5, int(self.target_fps * target_buffer_ms / 1000))
        self.frame_buffer = StreamBuffer(max_size=buffer_size)

        while self.running:
            try:
                # 如果暂停，则等待
                if self.paused:
                    time.sleep(0.1)
                    continue

                # 检查连接是否有效
                if self.cap is None or not self.cap.isOpened():
                    self._handle_connection_lost("摄像头连接丢失")
                    continue

                # 获取帧
                start_capture = time.time()
                ret, frame = self.cap.read()
                capture_time = time.time() - start_capture

                # 连接丢失或获取帧失败
                if not ret or frame is None:
                    self._handle_connection_lost("获取视频帧失败")
                    continue

                # 更新摄像头信息
                if self.frame_count == 0:
                    width = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
                    height = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
                    fps = self.cap.get(cv2.CAP_PROP_FPS)

                    self.camera_info.resolution = (int(width), int(height))
                    self.camera_info.fps = fps if fps > 0 else self.target_fps
                    self.current_resolution = (int(width), int(height))

                    # 发送分辨率变化信号
                    self.resolution_changed.emit(int(width), int(height))

                # 记录帧获取的延迟
                self.network_stats["latency"] = capture_time
                if capture_time > 1.0 / (self.target_fps / 2):
                    self.network_stats["drops"] += 1

                # 更新帧计数和FPS计算
                self.frame_count += 1
                elapsed = time.time() - self.start_time
                current_fps = self.frame_count / elapsed if elapsed > 0 else 0

                # 收集FPS统计
                self.fps_stats.append(current_fps)
                if len(self.fps_stats) > 10:
                    self.fps_stats.pop(0)

                # 应用帧处理器
                if self.frame_processor:
                    start_process = time.time()
                    try:
                        frame = self.frame_processor(frame)
                    except Exception as e:
                        self.error.emit(f"帧处理错误: {str(e)}")
                    process_time = time.time() - start_process

                    # 收集处理时间统计
                    self.processing_times.append(process_time)
                    if len(self.processing_times) > 10:
                        self.processing_times.pop(0)

                # 每秒发射一次状态更新
                if elapsed >= 1.0:
                    avg_fps = sum(self.fps_stats) / len(self.fps_stats) if self.fps_stats else 0
                    avg_process_time = sum(self.processing_times) / len(
                        self.processing_times) if self.processing_times else 0

                    status = {
                        "fps": avg_fps,
                        "frame_count": self.frame_count,
                        "resolution": self.current_resolution,
                        "processing_time": avg_process_time * 1000,  # 转换为毫秒
                        "network": self.network_stats,
                        "recording": self.is_recording,
                        "buffer_size": self.frame_buffer.frame_count
                    }

                    self.status_update.emit(status)

                    # 重置计数器
                    self.frame_count = 0
                    self.start_time = time.time()

                # 检查是否需要调整视频质量
                if self.quality_adjustment_enabled and time.time() - self.last_quality_check > self.quality_check_interval:
                    self._adjust_video_quality()
                    self.last_quality_check = time.time()

                # 将帧添加到缓冲区
                self.frame_buffer.put(frame.copy())

                # 录制视频(如果启用)
                if self.is_recording and self.recorder:
                    self.recorder.write_frame(frame)

                # 控制捕获频率(尽量接近目标FPS)
                target_frame_time = 1.0 / self.target_fps
                elapsed_frame_time = time.time() - start_capture
                sleep_time = max(0, target_frame_time - elapsed_frame_time)
                if sleep_time > 0:
                    time.sleep(sleep_time)

            except Exception as e:
                self.error.emit(f"视频处理错误: {str(e)}")
                time.sleep(0.1)

        # 清理资源
        self._cleanup()

    def stop(self):
        """停止视频流"""
        self.running = False

        # 等待线程结束
        if self.isRunning():
            self.wait(1000)

        # 停止录制
        if self.is_recording:
            self.stop_recording()

        # 停止渲染定时器
        if self.render_timer:
            self.render_timer.stop()

        # 停止重连定时器
        if self.reconnect_timer:
            self.reconnect_timer.stop()

        # 清理资源
        self._cleanup()

    def is_connected(self):
        """检查是否已连接到视频源"""
        return self.cap is not None and self.cap.isOpened()

    def get_camera_info(self):
        """获取摄像头信息"""
        # 如果连接中，更新一些信息
        if self.is_connected():
            self.camera_info.resolution = self.current_resolution
            try:
                self.camera_info.fps = self.cap.get(cv2.CAP_PROP_FPS)
                if self.camera_info.fps <= 0:
                    self.camera_info.fps = self.target_fps
            except:
                self.camera_info.fps = self.target_fps

        return self.camera_info.to_dict()

    def set_resolution(self, width, height):
        """
        设置摄像头分辨率

        Args:
            width: 宽度
            height: 高度

        Returns:
            bool: 是否成功设置
        """
        if not self.is_connected():
            return False

        try:
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

            # 验证设置是否成功
            actual_width = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            actual_height = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

            self.current_resolution = (int(actual_width), int(actual_height))
            self.camera_info.resolution = self.current_resolution

            # 发送分辨率变化信号
            self.resolution_changed.emit(int(actual_width), int(actual_height))

            return abs(actual_width - width) < 10 and abs(actual_height - height) < 10

        except Exception as e:
            self.error.emit(f"设置分辨率失败: {str(e)}")
            return False

    @staticmethod
    def list_available_cameras():
        """
        列出可用的摄像头

        Returns:
            list: 摄像头信息列表
        """
        available_cameras = []

        # 尝试列出本地摄像头
        for i in range(10):  # 尝试10个索引
            try:
                cap = cv2.VideoCapture(i)
                if cap.isOpened():
                    ret, frame = cap.read()
                    if ret:
                        info = CameraInfo(i)
                        info.name = f"摄像头 #{i}"
                        info.is_ip_camera = False

                        # 获取分辨率和帧率
                        info.resolution = (
                            int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                            int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        )
                        info.fps = cap.get(cv2.CAP_PROP_FPS)

                        available_cameras.append(info.to_dict())
                    cap.release()
            except:
                pass

        # 如果配置中有RTSP URL，也添加它
        if hasattr(config, 'VIDEO_RTSP_URL') and config.VIDEO_RTSP_URL:
            info = CameraInfo(len(available_cameras), "网络摄像头", True)
            info.url = config.VIDEO_RTSP_URL
            available_cameras.append(info.to_dict())

        return available_cameras

    def _render_frame(self):
        """从缓冲区获取并渲染帧"""
        if not self.running or self.paused:
            return

        # 从缓冲区获取最新帧
        frame = self.frame_buffer.get()
        if frame is None:
            return

        # 发送原始帧信号
        self.raw_frame_ready.emit(frame)

        # 转换为QImage
        try:
            # BGR转RGB
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # 转换为QImage
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w
            qt_image = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)

            # 发送QImage信号
            self.frame_ready.emit(qt_image)
        except Exception as e:
            self.error.emit(f"渲染帧错误: {str(e)}")

    def _connect_to_source(self):
        """连接到视频源"""
        try:
            # 释放之前的捕获对象
            if self.cap is not None:
                self.cap.release()

            # 连接摄像头
            self.cap = cv2.VideoCapture(self.video_source)

            # 检查连接是否成功
            if not self.cap.isOpened():
                self.error.emit(f"无法连接到视频源: {self.video_source}")
                self._schedule_reconnect()
                return False

            # 设置属性
            if not self.is_rtsp:  # 本地摄像头可以设置属性
                # 设置分辨率
                self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.VIDEO_WIDTH)
                self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.VIDEO_HEIGHT)

                # 使用MJPG格式可以提高性能(如果支持)
                self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))

                # 尝试设置帧率
                self.cap.set(cv2.CAP_PROP_FPS, self.target_fps)

            # 获取实际分辨率
            width = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            height = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            self.current_resolution = (int(width), int(height))

            # 重置重连计数
            self.reconnect_attempts = 0

            # 发送连接状态变化信号
            self.connection_status_changed.emit(True, f"已连接到{'RTSP流' if self.is_rtsp else '摄像头'}")

            return True

        except Exception as e:
            self.error.emit(f"连接视频源错误: {str(e)}")
            self._schedule_reconnect()
            return False

    def _handle_connection_lost(self, reason):
        """处理连接丢失"""
        # 发送连接状态变化信号
        self.connection_status_changed.emit(False, reason)

        # 安排重连
        self._schedule_reconnect()

        # 避免CPU占用过高
        time.sleep(0.5)

    def _schedule_reconnect(self):
        """安排重连"""
        # 增加重连计数
        self.reconnect_attempts += 1

        # 超过最大重试次数
        if self.reconnect_attempts > self.max_reconnect_attempts:
            self.error.emit(f"重连失败: 已达到最大重试次数 ({self.max_reconnect_attempts})")
            return

        # 计算退避时间
        backoff = min(self.reconnect_interval * (1.5 ** (self.reconnect_attempts - 1)), 30)

        # 直接在线程中等待
        time.sleep(backoff)

        # 尝试重连
        self._connect_to_source()

    def _adjust_video_quality(self):
        """根据性能动态调整视频质量"""
        if not self.quality_adjustment_enabled or not self.is_connected():
            return

        # 获取当前性能指标
        avg_fps = sum(self.fps_stats) / len(self.fps_stats) if self.fps_stats else 0
        avg_process_time = sum(self.processing_times) / len(self.processing_times) if self.processing_times else 0

        # 性能太差，降低分辨率
        if avg_fps < self.target_fps * 0.7 or avg_process_time > 1.0 / self.target_fps:
            width, height = self.current_resolution

            # 计算新分辨率(降低25%)
            new_width = int(width * 0.75)
            new_height = int(height * 0.75)

            # 确保分辨率不会过低
            if new_width >= 320 and new_height >= 240:
                self.set_resolution(new_width, new_height)
                self.logger.info(f"性能不足，降低分辨率至 {new_width}x{new_height}")

        # 性能良好，可以提高分辨率
        elif avg_fps > self.target_fps * 1.5 and avg_process_time < 1.0 / (self.target_fps * 2):
            width, height = self.current_resolution

            # 计算新分辨率(提高25%)
            new_width = int(width * 1.25)
            new_height = int(height * 1.25)

            # 确保分辨率不会过高
            if new_width <= 1920 and new_height <= 1080:
                self.set_resolution(new_width, new_height)
                self.logger.info(f"性能充足，提高分辨率至 {new_width}x{new_height}")

    def _cleanup(self):
        """清理资源"""
        # 停止录制
        if self.is_recording and self.recorder:
            self.stop_recording()

        # 释放摄像头
        if self.cap is not None:
            try:
                self.cap.release()
            except:
                pass
            self.cap = None