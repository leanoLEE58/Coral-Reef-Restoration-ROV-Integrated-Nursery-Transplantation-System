# ui/status_indicators.py
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout,
                             QGroupBox, QProgressBar, QSizePolicy)
from PyQt5.QtCore import Qt, QRectF, QTimer, pyqtProperty
from PyQt5.QtGui import QPainter, QColor, QPen, QBrush, QFont, QLinearGradient, QRadialGradient, QPainterPath
import numpy as np
from OpenGL.GLUT import *
import sys
class CircularGauge(QWidget):
    """圆形仪表组件"""

    def __init__(self, title="", min_value=0, max_value=100, parent=None):
        super().__init__(parent)
        self.title = title
        self.min_value = min_value
        self.max_value = max_value
        self.value = min_value
        self.units = ""
        self.color = QColor(52, 152, 219)  # 默认蓝色
        self.warning_color = QColor(231, 76, 60)  # 默认红色
        self.warning_threshold = 0.8 * max_value
        self.setMinimumSize(120, 120)

    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 确定绘制区域
        rect = self.rect()
        width = rect.width()
        height = rect.height()
        size = min(width, height)

        # 居中绘制
        painter.translate(rect.center())
        painter.scale(size / 200.0, size / 200.0)  # 标准化到200x200坐标系

        self._draw_gauge(painter)
        self._draw_value(painter)
        self._draw_title(painter)

    def _draw_gauge(self, painter):
        """绘制仪表盘"""
        # 确定颜色
        is_warning = self.value >= self.warning_threshold
        color = self.warning_color if is_warning else self.color

        # 绘制背景圆环
        pen = QPen(Qt.gray, 10)
        pen.setCapStyle(Qt.FlatCap)
        painter.setPen(pen)
        painter.drawArc(-85, -85, 170, 170, 0, 360 * 16)

        # 计算当前值对应的角度
        progress = (self.value - self.min_value) / (self.max_value - self.min_value)
        angle = -progress * 270 - 225  # 从225度开始，逆时针绘制270度

        # 绘制值指示圆环
        pen = QPen(color, 10)
        pen.setCapStyle(Qt.RoundCap)
        painter.setPen(pen)
        painter.drawArc(-85, -85, 170, 170, int(225 * 16), int(-progress * 270 * 16))

        # 绘制刻度
        painter.setPen(QPen(Qt.lightGray, 1))
        painter.setFont(QFont("Arial", 8))

        for i in range(11):
            # 计算刻度角度和位置
            p = i / 10.0
            a = -p * 270 - 225
            x = 70 * np.cos(np.radians(a))
            y = 70 * np.sin(np.radians(a))

            # 绘制刻度线
            outer_x = 85 * np.cos(np.radians(a))
            outer_y = 85 * np.sin(np.radians(a))
            painter.drawLine(int(x), int(y), int(outer_x), int(outer_y))

            # 绘制主刻度标签
            if i % 2 == 0:
                label_x = 60 * np.cos(np.radians(a))
                label_y = 60 * np.sin(np.radians(a))

                value = self.min_value + p * (self.max_value - self.min_value)
                painter.drawText(
                    int(label_x) - 10, int(label_y) - 10,
                    20, 20,
                    Qt.AlignCenter,
                    str(int(value))
                )

    def _draw_value(self, painter):
        """绘制当前值"""
        # 确定颜色
        is_warning = self.value >= self.warning_threshold
        color = self.warning_color if is_warning else self.color

        # 绘制当前值
        painter.setPen(color)
        painter.setFont(QFont("Arial", 16, QFont.Bold))

        value_text = f"{self.value:.1f}"
        if self.units:
            value_text += f" {self.units}"

        painter.drawText(-90, 20, 180, 30, Qt.AlignCenter, value_text)

    def _draw_title(self, painter):
        """绘制标题"""
        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 12))
        painter.drawText(-90, -30, 180, 30, Qt.AlignCenter, self.title)

    def set_value(self, value):
        """设置当前值"""
        self.value = max(self.min_value, min(value, self.max_value))
        self.update()

    def set_color(self, color):
        """设置仪表颜色"""
        self.color = color
        self.update()

    def set_warning_threshold(self, threshold):
        """设置警告阈值"""
        self.warning_threshold = threshold
        self.update()


class LEDIndicator(QWidget):
    """LED指示灯组件"""

    def __init__(self, label="", parent=None):
        super().__init__(parent)
        self.label = label
        self.state = False
        self.color_on = QColor(46, 204, 113)  # 绿色
        self.color_off = QColor(231, 76, 60)  # 红色
        self.pulse = False
        self.pulse_opacity = 1.0
        self.pulse_increasing = False

        # 脉冲动画
        self.pulse_timer = QTimer(self)
        self.pulse_timer.timeout.connect(self._update_pulse)

        self.setMinimumSize(80, 30)

    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 确定LED颜色
        color = self.color_on if self.state else self.color_off

        # 绘制LED圆形
        led_rect = QRectF(5, 5, 20, 20)

        if self.pulse and self.state:
            # 绘制发光效果
            gradient = QRadialGradient(led_rect.center(), 15)
            gradient.setColorAt(0, color)
            gradient.setColorAt(1, QColor(color.red(), color.green(), color.blue(), 0))

            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(gradient))
            painter.setOpacity(self.pulse_opacity * 0.5)
            painter.drawEllipse(led_rect.center(), 18, 18)
            painter.setOpacity(1.0)

        # 绘制LED本身
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(color))
        painter.drawEllipse(led_rect)

        # 高光效果
        highlight = QColor(255, 255, 255, 120)
        painter.setBrush(QBrush(highlight))
        painter.drawEllipse(led_rect.x() + 5, led_rect.y() + 5, 8, 6)

        # 绘制标签
        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 9))
        painter.drawText(30, 5, self.width() - 35, 20, Qt.AlignLeft | Qt.AlignVCenter, self.label)

    def _update_pulse(self):
        """更新脉冲效果"""
        step = 0.05

        if self.pulse_increasing:
            self.pulse_opacity += step
            if self.pulse_opacity >= 1.0:
                self.pulse_opacity = 1.0
                self.pulse_increasing = False
        else:
            self.pulse_opacity -= step
            if self.pulse_opacity <= 0.3:
                self.pulse_opacity = 0.3
                self.pulse_increasing = True

        self.update()

    def set_state(self, state, pulse=False):
        """设置状态"""
        self.state = state
        self.pulse = pulse

        if pulse and state:
            if not self.pulse_timer.isActive():
                self.pulse_timer.start(50)
        else:
            if self.pulse_timer.isActive():
                self.pulse_timer.stop()
                self.pulse_opacity = 1.0

        self.update()

    def set_colors(self, color_on, color_off):
        """设置颜色"""
        self.color_on = color_on
        self.color_off = color_off
        self.update()


class BatteryIndicator(QWidget):
    """电池指示器组件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.percentage = 100
        self.charging = False
        self.low_threshold = 20
        self.critical_threshold = 10
        self.setMinimumSize(120, 50)

    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 确定电池颜色
        if self.percentage <= self.critical_threshold:
            color = QColor(231, 76, 60)  # 红色
        elif self.percentage <= self.low_threshold:
            color = QColor(243, 156, 18)  # 橙色
        else:
            color = QColor(46, 204, 113)  # 绿色

        # 电池外壳
        shell_rect = QRectF(5, 15, 80, 30)
        terminal_rect = QRectF(85, 22, 5, 16)

        painter.setPen(QPen(Qt.white, 2))
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(shell_rect, 3, 3)
        painter.drawRoundedRect(terminal_rect, 1, 1)

        # 电池填充
        fill_width = (shell_rect.width() - 4) * self.percentage / 100.0

        if fill_width > 0:
            fill_rect = QRectF(shell_rect.x() + 2, shell_rect.y() + 2,
                               fill_width, shell_rect.height() - 4)

            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(color))
            painter.drawRoundedRect(fill_rect, 2, 2)

        # 充电图标
        if self.charging:
            painter.setPen(QPen(Qt.white, 2))
            center_x = shell_rect.center().x()
            center_y = shell_rect.center().y()

            # 绘制闪电图标
            path = QPainterPath()
            path.moveTo(center_x, center_y - 10)
            path.lineTo(center_x - 5, center_y)
            path.lineTo(center_x, center_y)
            path.lineTo(center_x, center_y + 10)
            path.lineTo(center_x + 5, center_y)
            path.lineTo(center_x, center_y)
            path.lineTo(center_x, center_y - 10)

            painter.drawPath(path)

        # 电池百分比
        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 12, QFont.Bold))
        percentage_text = f"{self.percentage}%"

        if self.charging:
            percentage_text += " 充电中"

        painter.drawText(5, 55, 95, 20, Qt.AlignLeft | Qt.AlignVCenter, percentage_text)

    def set_percentage(self, percentage, charging=False):
        """设置电池百分比"""
        self.percentage = max(0, min(percentage, 100))
        self.charging = charging
        self.update()

    def set_thresholds(self, low_threshold, critical_threshold):
        """设置阈值"""
        self.low_threshold = low_threshold
        self.critical_threshold = critical_threshold
        self.update()


class StatusIndicatorsPanel(QWidget):
    """状态指示器面板"""

    def __init__(self, parent=None):
        super().__init__(parent)

        # 初始化UI
        self._init_ui()

    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 传感器数据组
        sensor_group = QGroupBox("传感器数据")
        sensor_layout = QGridLayout(sensor_group)

        # 深度仪表
        self.depth_gauge = CircularGauge("深度", 0, 100)
        self.depth_gauge.units = "m"
        self.depth_gauge.set_color(QColor(52, 152, 219))  # 蓝色
        sensor_layout.addWidget(self.depth_gauge, 0, 0)

        # 温度仪表
        self.temp_gauge = CircularGauge("温度", 0, 50)
        self.temp_gauge.units = "°C"
        self.temp_gauge.set_color(QColor(231, 76, 60))  # 红色
        sensor_layout.addWidget(self.temp_gauge, 0, 1)

        # 压力仪表
        self.pressure_gauge = CircularGauge("压力", 0, 1000)
        self.pressure_gauge.units = "kPa"
        self.pressure_gauge.set_color(QColor(155, 89, 182))  # 紫色
        sensor_layout.addWidget(self.pressure_gauge, 1, 0)

        # 航向仪表
        self.heading_gauge = CircularGauge("航向", 0, 360)
        self.heading_gauge.units = "°"
        self.heading_gauge.set_color(QColor(241, 196, 15))  # 黄色
        sensor_layout.addWidget(self.heading_gauge, 1, 1)

        main_layout.addWidget(sensor_group)

        # 系统状态组
        system_group = QGroupBox("系统状态")
        system_layout = QVBoxLayout(system_group)

        # 电池指示器
        battery_layout = QHBoxLayout()
        battery_layout.addWidget(QLabel("电池状态:"))
        self.battery_indicator = BatteryIndicator()
        battery_layout.addWidget(self.battery_indicator)
        battery_layout.addStretch()
        system_layout.addLayout(battery_layout)

        # LED指示器组
        led_group = QGroupBox("系统指示灯")
        led_layout = QGridLayout(led_group)

        # 连接状态
        self.connection_led = LEDIndicator("通信连接")
        led_layout.addWidget(self.connection_led, 0, 0)

        # GPS状态
        self.gps_led = LEDIndicator("GPS信号")
        led_layout.addWidget(self.gps_led, 0, 1)

        # 漏水检测
        self.leak_led = LEDIndicator("漏水检测")
        self.leak_led.set_colors(QColor(46, 204, 113), QColor(231, 76, 60))
        led_layout.addWidget(self.leak_led, 1, 0)

        # 电机状态
        self.motor_led = LEDIndicator("电机状态")
        led_layout.addWidget(self.motor_led, 1, 1)

        system_layout.addWidget(led_group)

        main_layout.addWidget(system_group)

        # 错误信息
        error_group = QGroupBox("错误信息")
        error_layout = QVBoxLayout(error_group)
        self.error_label = QLabel("系统运行正常，无错误")
        self.error_label.setStyleSheet("color: white;")
        self.error_label.setWordWrap(True)
        error_layout.addWidget(self.error_label)

        main_layout.addWidget(error_group)
        main_layout.addStretch()

    def update_status(self, status):
        """
        更新状态信息

        Args:
            status: 状态数据字典
        """
        # 更新传感器数据
        self.depth_gauge.set_value(status.get('depth', 0.0))
        self.temp_gauge.set_value(status.get('temperature', 0.0))
        self.pressure_gauge.set_value(status.get('pressure', 0.0))
        self.heading_gauge.set_value(status.get('heading', 0.0))

        # 更新电池状态
        self.battery_indicator.set_percentage(status.get('battery', 100.0))

        # 更新LED指示灯
        self.connection_led.set_state(status.get('connected', False))
        self.gps_led.set_state(status.get('gps_lock', False))
        self.leak_led.set_state(not status.get('leak_detected', False), status.get('leak_detected', False))
        self.motor_led.set_state(not any(m < 0 for m in status.get('motor_status', [0, 0, 0, 0, 0, 0])))

        # 更新错误信息
        errors = status.get('errors', [])
        if errors:
            error_text = "系统错误:\n" + "\n".join(f"• {error}" for error in errors)
            self.error_label.setText(error_text)
            self.error_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
        else:
            self.error_label.setText("系统运行正常，无错误")
            self.error_label.setStyleSheet("color: #2ecc71;")