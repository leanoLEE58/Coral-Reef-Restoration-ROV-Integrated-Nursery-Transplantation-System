# ui/status_panel.py
"""
状态监控面板
"""
from PyQt5.QtWidgets import (QHBoxLayout)
import config
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QGridLayout, QGroupBox, QLabel, QProgressBar
from PyQt5.QtCore import Qt, pyqtSlot, pyqtSignal, QPoint
from PyQt5.QtGui import QPainter, QBrush, QColor, QPen
from PyQt5.QtChart import QChart, QChartView, QPieSeries, QLineSeries, QValueAxis
import math
from OpenGL.GLUT import *
import sys
class GaugeWidget(QWidget):
    """圆形仪表盘组件"""

    def __init__(self, title, min_val=0, max_val=100, parent=None):
        super().__init__(parent)
        self.title = title
        self.min_val = min_val
        self.max_val = max_val
        self.value = min_val
        self.units = ""
        self.warning_threshold = max_val * 0.8

        # 创建图表
        self._create_chart()

        # 布局
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.chart_view)

    def _create_chart(self):
        # 创建图表
        self.chart = QChart()
        self.chart.setTitle(self.title)
        self.chart.setAnimationOptions(QChart.SeriesAnimations)
        self.chart.legend().hide()
        self.chart.setBackgroundBrush(QBrush(QColor("#2c3e50")))
        self.chart.setTitleBrush(QBrush(QColor("white")))

        # 创建仪表盘系列
        self.background_series = QPieSeries()
        self.background_series.append("Background", 100)
        self.background_series.setPieSize(0.9)
        self.background_series.setHoleSize(0.7)
        slice = self.background_series.slices()[0]
        slice.setBrush(QBrush(QColor("#34495e")))
        slice.setPen(QPen(QColor("#34495e"), 0))

        self.gauge_series = QPieSeries()
        self.gauge_series.append("Value", 0)
        self.gauge_series.append("Remaining", 100)
        self.gauge_series.setPieSize(0.9)
        self.gauge_series.setHoleSize(0.7)

        self.value_slice = self.gauge_series.slices()[0]
        self.value_slice.setBrush(QBrush(QColor("#2ecc71")))
        self.value_slice.setPen(QPen(QColor("#2ecc71"), 0))

        self.remaining_slice = self.gauge_series.slices()[1]
        self.remaining_slice.setBrush(QBrush(QColor(0, 0, 0, 0)))
        self.remaining_slice.setPen(QPen(QColor(0, 0, 0, 0), 0))

        self.chart.addSeries(self.background_series)
        self.chart.addSeries(self.gauge_series)

        # 创建图表视图
        self.chart_view = QChartView(self.chart)
        self.chart_view.setRenderHint(QPainter.Antialiasing)

    def update_value(self, value):
        """更新仪表盘值"""
        self.value = max(min(value, self.max_val), self.min_val)

        # 计算百分比
        percentage = ((self.value - self.min_val) / (self.max_val - self.min_val)) * 100

        # 更新饼图切片
        self.value_slice.setValue(percentage)
        self.remaining_slice.setValue(100 - percentage)

        # 如果超过警告阈值，改变颜色
        if self.value > self.warning_threshold:
            self.value_slice.setBrush(QBrush(QColor("#e74c3c")))
            self.value_slice.setPen(QPen(QColor("#e74c3c"), 0))
        else:
            self.value_slice.setBrush(QBrush(QColor("#2ecc71")))
            self.value_slice.setPen(QPen(QColor("#2ecc71"), 0))

        # 更新标题
        self.chart.setTitle(f"{self.title}: {self.value:.1f} {self.units}")


class CompassWidget(QWidget):
    """航向指示器组件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.heading = 0
        self.setMinimumSize(150, 150)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        center = self.rect().center()
        radius = min(self.width(), self.height()) / 2 - 10

        # 绘制外圆
        painter.setPen(QPen(QColor("#3498db"), 2))
        painter.drawEllipse(center, radius, radius)

        # 绘制刻度
        painter.setPen(QPen(QColor("white"), 1))
        for i in range(0, 360, 30):
            angle = i - 90  # 调整开始位置
            x1 = center.x() + (radius - 10) * math.cos(math.radians(angle))
            y1 = center.y() + (radius - 10) * math.sin(math.radians(angle))
            x2 = center.x() + radius * math.cos(math.radians(angle))
            y2 = center.y() + radius * math.sin(math.radians(angle))
            painter.drawLine(int(x1), int(y1), int(x2), int(y2))

            # 绘制刻度标签
            if i % 90 == 0:
                label = ["N", "E", "S", "W"][i // 90]
                x = center.x() + (radius - 25) * math.cos(math.radians(angle))
                y = center.y() + (radius - 25) * math.sin(math.radians(angle))
                painter.drawText(int(x) - 5, int(y) + 5, label)

        # 绘制指针
        painter.setPen(QPen(QColor("#e74c3c"), 2))
        angle = self.heading - 90  # 调整指针方向
        x = center.x() + (radius - 15) * math.cos(math.radians(angle))
        y = center.y() + (radius - 15) * math.sin(math.radians(angle))
        painter.drawLine(center, QPoint(int(x), int(y)))

        # 绘制中心点
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor("#e74c3c")))
        painter.drawEllipse(center, 5, 5)

        # 绘制当前角度文本
        painter.setPen(QPen(QColor("white"), 1))
        painter.drawText(self.rect(), Qt.AlignBottom | Qt.AlignHCenter, f"{self.heading}°")

    def update_heading(self, heading):
        """更新航向值"""
        self.heading = heading
        self.update()
class StatusPanel(QWidget):
    """状态监控面板"""

    def __init__(self, parent=None):
        """
        初始化状态面板

        Args:
            parent: 父组件
        """
        super().__init__(parent)

        # 初始化UI
        self._init_ui()

    # 修改 ui/status_panel.py 中的 StatusPanel 类
    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 传感器数据组
        sensor_group = QGroupBox("传感器数据")
        sensor_layout = QGridLayout(sensor_group)

        # 使用仪表盘替换LCD显示
        self.depth_gauge = GaugeWidget("深度", 0, config.MAX_DEPTH)
        self.depth_gauge.units = "m"
        sensor_layout.addWidget(self.depth_gauge, 0, 0)

        self.temp_gauge = GaugeWidget("温度", 0, 50)
        self.temp_gauge.units = "°C"
        sensor_layout.addWidget(self.temp_gauge, 0, 1)

        main_layout.addWidget(sensor_group)

        # 姿态数据组
        attitude_group = QGroupBox("姿态数据")
        attitude_layout = QGridLayout(attitude_group)

        # 添加3D姿态显示
        self.attitude3d = Attitude3DWidget()
        attitude_layout.addWidget(self.attitude3d, 0, 0, 2, 1)

        # 添加航向指示器
        self.compass = CompassWidget()
        attitude_layout.addWidget(self.compass, 0, 1)

        main_layout.addWidget(attitude_group)

        # 系统状态组
        system_group = QGroupBox("系统状态")
        system_layout = QVBoxLayout(system_group)

        # 电池电量
        battery_layout = QHBoxLayout()
        battery_layout.addWidget(QLabel("电池电量:"))
        self.battery_bar = QProgressBar()
        self.battery_bar.setRange(0, 100)
        self.battery_bar.setValue(100)
        self.battery_bar.setTextVisible(True)
        self.battery_bar.setFormat("%v%")
        battery_layout.addWidget(self.battery_bar)
        system_layout.addLayout(battery_layout)

        # 其他状态信息...

        main_layout.addWidget(system_group)

        # 添加实时深度图表
        self.depth_chart = RealTimeChart("深度趋势")
        main_layout.addWidget(self.depth_chart)

    @pyqtSlot(dict)
    def update_status(self, status):
        """更新显示的状态信息"""
        # 更新传感器数据仪表盘
        self.depth_gauge.update_value(status.get('depth', 0.0))
        self.temp_gauge.update_value(status.get('temperature', 0.0))

        # 更新姿态显示
        self.attitude3d.update_attitude(
            status.get('roll', 0.0),
            status.get('pitch', 0.0),
            status.get('heading', 0.0)
        )
        self.compass.update_heading(status.get('heading', 0.0))

        # 更新图表
        self.depth_chart.add_data_point(status.get('depth', 0.0))

        # 更新电池状态
        battery = status.get('battery', 100.0)
        self.battery_bar.setValue(int(battery))

        # 设置电池电量颜色
        if battery < 20:
            self.battery_bar.setStyleSheet("QProgressBar::chunk { background-color: #e74c3c; }")
        elif battery < 50:
            self.battery_bar.setStyleSheet("QProgressBar::chunk { background-color: #f39c12; }")
        else:
            self.battery_bar.setStyleSheet("QProgressBar::chunk { background-color: #2ecc71; }")

    @pyqtSlot(dict)
    def update_joystick_data(self, joystick_data):
        """
        更新手柄数据

        Args:
            joystick_data: 手柄数据字典
        """
        axes = joystick_data.get("axes", {})

        # 提取摇杆值
        lx = axes.get("LX", 0.0)
        ly = axes.get("LY", 0.0)
        rx = axes.get("RX", 0.0)
        ry = axes.get("RY", 0.0)

        # 更新摇杆指示器
        self.left_stick.update_values(lx, ly)
        self.right_stick.update_values(rx, ry)

        # 如果在手动模式下，更新控制滑块
        if self.current_control_mode == "manual":
            # 前进/后退控制 (左摇杆Y轴)
            self.forward_slider.setValue(int(-ly * 100))

            # 左右移动控制 (左摇杆X轴)
            self.lateral_slider.setValue(int(lx * 100))

            # 上浮/下潜控制 (LT和RT)
            vertical = (axes.get("RT", 0.0) - axes.get("LT", 0.0)) / 2.0
            self.vertical_slider.setValue(int(vertical * 100))

            # 偏航控制 (右摇杆X轴)
            self.yaw_slider.setValue(int(rx * 100))


    @pyqtSlot(bool)
    def update_connection_status(self, connected):
        """
        更新连接状态

        Args:
            connected: 是否已连接
        """
        if connected:
            self.connection_status.setText("连接状态: 已连接")
            self.connection_status.setStyleSheet("color: #2ecc71;")
        else:
            self.connection_status.setText("连接状态: 未连接")
            self.connection_status.setStyleSheet("color: #e74c3c;")


# 需要安装 PyOpenGL: pip install PyOpenGL PyOpenGL_accelerate
from OpenGL.GL import *
from OpenGL.GLU import *
from PyQt5.QtOpenGL import QGLWidget


class Attitude3DWidget(QGLWidget):
    """3D姿态可视化组件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw = 0.0

    def initializeGL(self):
        glClearColor(0.2, 0.2, 0.3, 1.0)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)

    def resizeGL(self, width, height):
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(40.0, width / height, 1.0, 100.0)

    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        # 设置观察位置
        gluLookAt(0, 0, 5, 0, 0, 0, 0, 1, 0)

        # 应用旋转
        glRotatef(self.roll, 0, 0, 1)
        glRotatef(self.pitch, 1, 0, 0)
        glRotatef(self.yaw, 0, 1, 0)

        # 绘制ROV模型（简化为长方体）
        glColor3f(0.2, 0.5, 0.8)
        self.draw_cuboid(1.5, 0.5, 0.7)

        # 绘制坐标轴
        self.draw_axes()

    def draw_cuboid(self, length, width, height):
        """绘制长方体"""
        l, w, h = length / 2, width / 2, height / 2

        vertices = [
            # 前面
            (-l, -w, h), (l, -w, h), (l, w, h), (-l, w, h),
            # 后面
            (-l, -w, -h), (l, -w, -h), (l, w, -h), (-l, w, -h)
        ]

        faces = [
            (0, 1, 2, 3),  # 前面
            (4, 5, 6, 7),  # 后面
            (0, 3, 7, 4),  # 左面
            (1, 2, 6, 5),  # 右面
            (3, 2, 6, 7),  # 上面
            (0, 1, 5, 4)  # 下面
        ]

        colors = [
            (0.2, 0.5, 0.8),  # 前面
            (0.2, 0.5, 0.8),  # 后面
            (0.3, 0.6, 0.9),  # 左面
            (0.3, 0.6, 0.9),  # 右面
            (0.4, 0.7, 1.0),  # 上面
            (0.1, 0.4, 0.7)  # 下面
        ]

        # 绘制每个面
        for i, face in enumerate(faces):
            glColor3fv(colors[i])
            glBegin(GL_QUADS)
            for vertex_index in face:
                glVertex3fv(vertices[vertex_index])
            glEnd()

    def draw_axes(self):
        """绘制坐标轴"""
        glBegin(GL_LINES)
        # X轴 (红色)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(2.0, 0.0, 0.0)
        # Y轴 (绿色)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 2.0, 0.0)
        # Z轴 (蓝色)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 2.0)
        glEnd()

    def update_attitude(self, roll, pitch, yaw):
        """更新姿态数据"""
        self.roll = roll
        self.pitch = pitch
        self.yaw = yaw
        self.updateGL()


class VirtualJoystick(QWidget):
    """虚拟摇杆控制器"""
    positionChanged = pyqtSignal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(150, 150)
        self.setMaximumSize(250, 250)
        self.centerPos = QPoint(0, 0)
        self.handlePos = QPoint(0, 0)
        self.dragging = False
        self.handleRadius = 20
        self.baseRadius = 50
        self.deadzone = 0.1

    def resizeEvent(self, event):
        """调整大小时更新中心点"""
        self.centerPos = QPoint(self.width() // 2, self.height() // 2)
        self.handlePos = self.centerPos

    def paintEvent(self, event):
        """绘制摇杆"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 绘制外圆
        painter.setPen(QPen(QColor("#34495e"), 2))
        painter.setBrush(QBrush(QColor(0, 0, 0, 50)))
        painter.drawEllipse(self.centerPos, self.baseRadius, self.baseRadius)

        # 绘制轴线
        painter.setPen(QPen(QColor("#7f8c8d"), 1))
        painter.drawLine(self.centerPos.x() - self.baseRadius, self.centerPos.y(),
                         self.centerPos.x() + self.baseRadius, self.centerPos.y())
        painter.drawLine(self.centerPos.x(), self.centerPos.y() - self.baseRadius,
                         self.centerPos.x(), self.centerPos.y() + self.baseRadius)

        # 绘制手柄
        painter.setPen(QPen(QColor("#3498db"), 2))
        painter.setBrush(QBrush(QColor("#2980b9")))
        painter.drawEllipse(self.handlePos, self.handleRadius, self.handleRadius)

        # 绘制连接线
        if self.handlePos != self.centerPos:
            painter.setPen(QPen(QColor("#bdc3c7"), 2, Qt.DashLine))
            painter.drawLine(self.centerPos, self.handlePos)

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            if self.handlePos.x() - self.handleRadius <= event.pos().x() <= self.handlePos.x() + self.handleRadius and \
                    self.handlePos.y() - self.handleRadius <= event.pos().y() <= self.handlePos.y() + self.handleRadius:
                self.dragging = True

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if self.dragging:
            diff = event.pos() - self.centerPos
            length = min(diff.manhattanLength(), self.baseRadius)

            if length < self.baseRadius * self.deadzone:
                self.handlePos = self.centerPos
            else:
                angle = math.atan2(diff.y(), diff.x())
                self.handlePos = QPoint(
                    int(self.centerPos.x() + length * math.cos(angle)),
                    int(self.centerPos.y() + length * math.sin(angle))
                )

            # 计算并发射相对位置 (-1 到 1 范围)
            x = (self.handlePos.x() - self.centerPos.x()) / self.baseRadius
            y = (self.handlePos.y() - self.centerPos.y()) / self.baseRadius
            self.positionChanged.emit(x, y)
            self.update()

    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        if event.button() == Qt.LeftButton and self.dragging:
            self.dragging = False
            self.handlePos = self.centerPos
            self.positionChanged.emit(0, 0)
            self.update()


class RealTimeChart(QWidget):
    """实时数据图表"""

    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.title = title
        self.data_points = []
        self.max_points = 100
        self.max_y_value = 10
        self.min_y_value = 0

        # 创建图表
        self._setup_chart()

        # 创建布局
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.chart_view)

    def _setup_chart(self):
        # 创建图表
        self.chart = QChart()
        self.chart.setTitle(self.title)
        self.chart.setAnimationOptions(QChart.NoAnimation)
        self.chart.legend().hide()

        # 创建数据系列
        self.series = QLineSeries()
        self.chart.addSeries(self.series)

        # 创建坐标轴
        self.x_axis = QValueAxis()
        self.x_axis.setRange(0, self.max_points)
        self.x_axis.setLabelFormat("%d")
        self.x_axis.setTitleText("时间 (秒)")

        self.y_axis = QValueAxis()
        self.y_axis.setRange(self.min_y_value, self.max_y_value)
        self.y_axis.setLabelFormat("%.1f")
        self.y_axis.setTitleText(self.title)

        self.chart.addAxis(self.x_axis, Qt.AlignBottom)
        self.chart.addAxis(self.y_axis, Qt.AlignLeft)

        self.series.attachAxis(self.x_axis)
        self.series.attachAxis(self.y_axis)

        # 创建图表视图
        self.chart_view = QChartView(self.chart)
        self.chart_view.setRenderHint(QPainter.Antialiasing)

        # 设置样式
        self.chart.setBackgroundBrush(QBrush(QColor("#2c3e50")))
        self.chart.setTitleBrush(QBrush(QColor("white")))
        self.x_axis.setLabelsColor(QColor("white"))
        self.y_axis.setLabelsColor(QColor("white"))
        self.series.setColor(QColor("#3498db"))

    def add_data_point(self, value):
        """添加新的数据点"""
        # 限制数据点数量
        if len(self.data_points) >= self.max_points:
            self.data_points.pop(0)

        self.data_points.append(value)

        # 更新Y轴范围（如果需要）
        if value > self.max_y_value:
            self.max_y_value = value * 1.1
            self.y_axis.setMax(self.max_y_value)
        if value < self.min_y_value:
            self.min_y_value = value * 0.9
            self.y_axis.setMin(self.min_y_value)

        # 更新图表数据
        self.series.clear()
        for i, point in enumerate(self.data_points):
            self.series.append(i, point)

        # 自动滚动X轴
        if len(self.data_points) >= self.max_points:
            self.x_axis.setRange(len(self.data_points) - self.max_points, len(self.data_points))