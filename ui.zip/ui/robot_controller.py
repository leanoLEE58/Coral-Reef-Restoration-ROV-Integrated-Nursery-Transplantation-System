# modules/robot_controller.py
"""
机器人控制逻辑模块 - 增强版
支持状态预测、自适应控制、高级推力分配和故障恢复
"""
import time
import threading
import numpy as np
import json
import os
from datetime import datetime
from collections import deque
from PyQt5.QtCore import QObject, pyqtSignal, QTimer, QMutex, QMutexLocker

import config


class PIDController:
    """增强型PID控制器"""

    def __init__(self, kp=0.0, ki=0.0, kd=0.0, ff=0.0):
        """
        初始化PID控制器

        Args:
            kp: 比例系数
            ki: 积分系数
            kd: 微分系数
            ff: 前馈系数
        """
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.ff = ff  # 前馈系数
        self.target = 0.0
        self.error_sum = 0.0
        self.last_error = 0.0
        self.output_limit = 1.0
        self.integral_limit = 1.0  # 积分限制，防止积分饱和
        self.derivative_filter = 0.2  # 微分项低通滤波系数(0-1)，值越小滤波越强
        self.error_history = deque(maxlen=10)  # 用于记录误差历史
        self.filtered_derivative = 0.0
        self.last_time = time.time()
        self.reset()

    def reset(self):
        """重置PID控制器状态"""
        self.error_sum = 0.0
        self.last_error = 0.0
        self.error_history.clear()
        self.filtered_derivative = 0.0
        self.last_time = time.time()

    def set_parameters(self, kp=None, ki=None, kd=None, ff=None):
        """
        设置PID参数

        Args:
            kp: 比例系数
            ki: 积分系数
            kd: 微分系数
            ff: 前馈系数
        """
        changed = False
        if kp is not None and kp != self.kp:
            self.kp = kp
            changed = True

        if ki is not None and ki != self.ki:
            self.ki = ki
            changed = True

        if kd is not None and kd != self.kd:
            self.kd = kd
            changed = True

        if ff is not None and ff != self.ff:
            self.ff = ff
            changed = True

        # 只有在参数变化时才重置
        if changed:
            self.reset()

        return changed

    def set_target(self, target):
        """
        设置目标值

        Args:
            target: 目标值

        Returns:
            bool: 目标值是否改变
        """
        if target != self.target:
            self.target = target
            return True
        return False

    def compute(self, current_value, dt=None, feed_forward=0.0):
        """
        计算PID输出，支持前馈控制

        Args:
            current_value: 当前值
            dt: 时间间隔(秒)，如果为None则自动计算
            feed_forward: 前馈值，会乘以前馈系数

        Returns:
            控制输出
        """
        # 计算时间间隔
        if dt is None:
            current_time = time.time()
            dt = current_time - self.last_time
            self.last_time = current_time

        # 确保dt有效
        if dt <= 0:
            dt = 0.01  # 默认10ms

        # 计算误差
        error = self.target - current_value

        # 存储误差历史
        self.error_history.append(error)

        # 积分项(带抗饱和)
        # 只有在输出未饱和或积分作用方向与误差相反时才进行积分
        if abs(self.error_sum) < self.integral_limit or (error * self.error_sum) < 0:
            self.error_sum += error * dt
            # 限制积分和
            self.error_sum = max(min(self.error_sum, self.integral_limit), -self.integral_limit)

        # 微分项 (使用低通滤波)
        error_derivative = (error - self.last_error) / dt if dt > 0 else 0
        self.filtered_derivative = self.derivative_filter * error_derivative + \
                                   (1 - self.derivative_filter) * self.filtered_derivative

        # 计算输出 (包括前馈)
        output = (self.kp * error +
                  self.ki * self.error_sum +
                  self.kd * self.filtered_derivative +
                  self.ff * feed_forward)

        # 限制输出范围
        output = max(min(output, self.output_limit), -self.output_limit)

        # 保存最后的误差
        self.last_error = error

        return output

    def get_status(self):
        """
        获取PID状态

        Returns:
            dict: PID状态信息
        """
        return {
            "kp": self.kp,
            "ki": self.ki,
            "kd": self.kd,
            "ff": self.ff,
            "target": self.target,
            "error": self.last_error,
            "error_sum": self.error_sum,
            "derivative": self.filtered_derivative,
            "output_limit": self.output_limit
        }

    def set_output_limit(self, limit):
        """
        设置输出限制

        Args:
            limit: 输出限制值
        """
        self.output_limit = abs(limit)

    def set_integral_limit(self, limit):
        """
        设置积分限制

        Args:
            limit: 积分限制值
        """
        self.integral_limit = abs(limit)
        # 确保当前积分值在新限制范围内
        self.error_sum = max(min(self.error_sum, self.integral_limit), -self.integral_limit)


class ThrustAllocator:
    """推力分配器"""

    def __init__(self, config_matrix=None):
        """
        初始化推力分配器

        Args:
            config_matrix: 配置矩阵，定义推进器方向和作用
        """
        # 默认配置矩阵 (6个推进器，6个自由度)
        # 行: [surge(前后), sway(左右), heave(上下), roll(横滚), pitch(俯仰), yaw(偏航)]
        # 列: 各个推进器
        self.config_matrix = config_matrix if config_matrix is not None else np.array([
            # 推进器1  推进器2  推进器3  推进器4  推进器5  推进器6
            [1.0, 1.0, 0.0, 0.0, 0.0, 0.0],  # 前后
            [0.0, 0.0, 1.0, 1.0, 0.0, 0.0],  # 左右
            [0.0, 0.0, 0.0, 0.0, 1.0, 1.0],  # 上下
            [0.0, 0.0, 0.0, 0.0, -0.5, 0.5],  # 横滚
            [0.0, 0.0, 0.0, 0.0, 0.5, 0.5],  # 俯仰
            [-0.5, 0.5, -0.5, 0.5, 0.0, 0.0]  # 偏航
        ])

        # 推进器限制 (最小和最大推力)
        self.min_thrust = -1.0
        self.max_thrust = 1.0

        # 推力效率曲线
        self.efficiency_curve = None

    def allocate(self, desired_forces):
        """
        根据期望的力和力矩分配推进器推力

        Args:
            desired_forces: 包含6个自由度期望力和力矩的数组或列表
                           [surge, sway, heave, roll, pitch, yaw]

        Returns:
            分配给各个推进器的推力值数组
        """
        # 转换为numpy数组
        forces = np.array(desired_forces)

        # 使用伪逆求解
        # X = B^+ * f, 其中B^+是配置矩阵的伪逆，f是期望力
        try:
            # 计算伪逆
            B_plus = np.linalg.pinv(self.config_matrix)
            # 计算推力分配
            thrusts = np.dot(B_plus, forces)
        except:
            # 如果矩阵求逆失败，使用简化算法
            thrusts = self._simplified_allocation(forces)

        # 应用推力限制
        thrusts = np.clip(thrusts, self.min_thrust, self.max_thrust)

        # 应用效率曲线(如果定义了)
        if self.efficiency_curve is not None:
            thrusts = self._apply_efficiency_curve(thrusts)

        return thrusts

    def _simplified_allocation(self, forces):
        """
        简化的推力分配算法，用于伪逆法失败时

        Args:
            forces: 期望的力和力矩

        Returns:
            推力分配
        """
        # 初始化推力数组
        n_thrusters = self.config_matrix.shape[1]
        thrusts = np.zeros(n_thrusters)

        # 简单直接分配
        # 前后推进器 (推进器1和2)
        thrusts[0] = forces[0] / 2 - forces[5] / 2  # 前后+偏航
        thrusts[1] = forces[0] / 2 + forces[5] / 2  # 前后+偏航

        # 左右推进器 (推进器3和4)
        thrusts[2] = forces[1] / 2 - forces[5] / 2  # 左右+偏航
        thrusts[3] = forces[1] / 2 + forces[5] / 2  # 左右+偏航

        # 垂直推进器 (推进器5和6)
        thrusts[4] = forces[2] / 2 - forces[3] / 2 + forces[4] / 2  # 上下+横滚+俯仰
        thrusts[5] = forces[2] / 2 + forces[3] / 2 + forces[4] / 2  # 上下+横滚+俯仰

        return thrusts

    def _apply_efficiency_curve(self, thrusts):
        """
        应用推力效率曲线

        Args:
            thrusts: 原始推力数组

        Returns:
            调整后的推力数组
        """
        # 这里可以实现推力效率曲线
        # 例如，对推力值进行非线性映射以考虑推进器特性
        return thrusts


class StateEstimator:
    """状态估计器"""

    def __init__(self):
        """初始化状态估计器"""
        # 状态向量 [x, y, z, roll, pitch, yaw, x_vel, y_vel, z_vel, roll_vel, pitch_vel, yaw_vel]
        self.state = np.zeros(12)

        # 上一次状态更新时间
        self.last_update_time = time.time()

        # 过程噪声和测量噪声协方差
        self.process_noise = np.diag([0.01] * 12)
        self.measurement_noise = np.diag([0.1] * 6)  # 只测量位置和姿态

        # 状态协方差矩阵
        self.P = np.diag([1.0] * 12)

        # 预测历史
        self.prediction_history = deque(maxlen=20)

        # 状态历史
        self.state_history = deque(maxlen=100)

    def predict(self, dt, control_inputs=None):
        """
        预测下一状态

        Args:
            dt: 时间间隔
            control_inputs: 控制输入

        Returns:
            预测的状态
        """
        # 简单的运动学模型
        # 位置 = 位置 + 速度 * 时间
        # 姿态 = 姿态 + 角速度 * 时间
        # 速度和角速度保持不变或根据控制输入更新

        # 创建状态转移矩阵F
        F = np.eye(12)

        # 更新位置
        F[0, 6] = dt  # x = x + x_vel * dt
        F[1, 7] = dt  # y = y + y_vel * dt
        F[2, 8] = dt  # z = z + z_vel * dt

        # 更新姿态
        F[3, 9] = dt  # roll = roll + roll_vel * dt
        F[4, 10] = dt  # pitch = pitch + pitch_vel * dt
        F[5, 11] = dt  # yaw = yaw + yaw_vel * dt

        # 预测状态
        new_state = F @ self.state

        # 如果有控制输入，更新速度
        if control_inputs is not None:
            # 控制输入格式: [surge, sway, heave, roll_torque, pitch_torque, yaw_torque]
            # 简化模型，直接更新速度
            acceleration_factor = 0.1  # 加速度系数
            new_state[6] += control_inputs[0] * acceleration_factor  # x_vel
            new_state[7] += control_inputs[1] * acceleration_factor  # y_vel
            new_state[8] += control_inputs[2] * acceleration_factor  # z_vel
            new_state[9] += control_inputs[3] * acceleration_factor  # roll_vel
            new_state[10] += control_inputs[4] * acceleration_factor  # pitch_vel
            new_state[11] += control_inputs[5] * acceleration_factor  # yaw_vel

        # 更新协方差
        self.P = F @ self.P @ F.T + self.process_noise

        # 存储预测结果
        self.prediction_history.append((time.time(), new_state.copy()))

        return new_state

    def update(self, measurements, measurement_time=None):
        """
        使用测量值更新状态

        Args:
            measurements: 测量值 [x, y, z, roll, pitch, yaw]
            measurement_time: 测量时间，用于处理延迟数据

        Returns:
            更新后的状态
        """
        if measurement_time is None:
            measurement_time = time.time()

        # 创建测量矩阵H
        H = np.zeros((6, 12))
        H[0, 0] = 1  # x
        H[1, 1] = 1  # y
        H[2, 2] = 1  # z
        H[3, 3] = 1  # roll
        H[4, 4] = 1  # pitch
        H[5, 5] = 1  # yaw

        # 计算卡尔曼增益
        K = self.P @ H.T @ np.linalg.inv(H @ self.P @ H.T + self.measurement_noise)

        # 测量残差
        if isinstance(measurements, list):
            measurements = np.array(measurements)
        residual = measurements - H @ self.state

        # 标准化角度残差
        for i in range(3, 6):
            while residual[i] > np.pi:
                residual[i] -= 2 * np.pi
            while residual[i] < -np.pi:
                residual[i] += 2 * np.pi

        # 更新状态
        self.state = self.state + K @ residual

        # 更新协方差
        self.P = (np.eye(12) - K @ H) @ self.P

        # 存储状态历史
        self.state_history.append((measurement_time, self.state.copy()))

        # 更新时间
        self.last_update_time = measurement_time

        return self.state

    def get_state(self):
        """
        获取当前状态

        Returns:
            当前状态向量
        """
        return self.state.copy()

    def get_position_attitude(self):
        """
        获取位置和姿态

        Returns:
            位置和姿态数组 [x, y, z, roll, pitch, yaw]
        """
        return self.state[:6].copy()


class ControlModes:
    """控制模式枚举"""
    MANUAL = "manual"
    STABILIZE = "stabilize"
    DEPTH_HOLD = "depth_hold"
    HEADING_HOLD = "heading_hold"
    POSITION_HOLD = "position_hold"
    AUTO = "auto"

    @classmethod
    def is_valid(cls, mode):
        """
        检查模式是否有效

        Args:
            mode: 要检查的模式

        Returns:
            bool: 模式是否有效
        """
        return mode in [cls.MANUAL, cls.STABILIZE, cls.DEPTH_HOLD,
                        cls.HEADING_HOLD, cls.POSITION_HOLD, cls.AUTO]


class DataLogger:
    """数据记录器"""

    def __init__(self, log_dir="logs"):
        """
        初始化数据记录器

        Args:
            log_dir: 日志目录
        """
        self.log_dir = log_dir
        self.log_file = None
        self.is_logging = False
        self.data_buffer = []
        self.buffer_size = 100  # 缓冲区大小
        self.last_flush_time = time.time()
        self.flush_interval = 5.0  # 刷新间隔(秒)

        # 确保日志目录存在
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

    def start_logging(self):
        """开始记录数据"""
        if self.is_logging:
            return

        # 创建日志文件
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = os.path.join(self.log_dir, f"robot_log_{timestamp}.json")

        try:
            self.log_file = open(log_path, 'w')
            self.log_file.write('[\n')  # 开始JSON数组
            self.is_logging = True
            self.data_buffer = []
            self.last_flush_time = time.time()
            return True
        except Exception as e:
            print(f"启动数据记录失败: {str(e)}")
            return False

    def stop_logging(self):
        """停止记录数据"""
        if not self.is_logging:
            return

        try:
            # 刷新缓冲区
            self._flush_buffer()

            # 结束JSON数组
            self.log_file.write('\n]')
            self.log_file.close()
            self.log_file = None
            self.is_logging = False
            return True
        except Exception as e:
            print(f"停止数据记录失败: {str(e)}")
            return False

    def log_data(self, data_type, data):
        """
        记录数据

        Args:
            data_type: 数据类型
            data: 要记录的数据
        """
        if not self.is_logging:
            return

        try:
            # 创建日志条目
            log_entry = {
                "time": time.time(),
                "type": data_type,
                "data": data
            }

            # 添加到缓冲区
            self.data_buffer.append(log_entry)

            # 检查是否需要刷新
            if len(self.data_buffer) >= self.buffer_size or time.time() - self.last_flush_time >= self.flush_interval:
                self._flush_buffer()

        except Exception as e:
            print(f"记录数据失败: {str(e)}")

    def _flush_buffer(self):
        """刷新缓冲区到文件"""
        if not self.is_logging or not self.data_buffer:
            return

        try:
            # 写入每个日志条目
            for i, entry in enumerate(self.data_buffer):
                # 添加逗号，除了第一个条目和最后一个条目
                if i > 0 or self.log_file.tell() > 2:  # 2 是 '[\n' 的长度
                    self.log_file.write(',\n')

                # 写入JSON格式的日志条目
                json.dump(entry, self.log_file)

            # 清空缓冲区
            self.data_buffer = []

            # 刷新文件
            self.log_file.flush()

            # 更新最后刷新时间
            self.last_flush_time = time.time()

        except Exception as e:
            print(f"刷新数据缓冲区失败: {str(e)}")


class RobotController(QObject):
    """增强型机器人控制器"""
    # 定义信号
    status_updated = pyqtSignal(dict)
    control_updated = pyqtSignal(dict)
    pid_updated = pyqtSignal(dict)
    mode_changed = pyqtSignal(str)
    error = pyqtSignal(str)
    telemetry_updated = pyqtSignal(dict)

    def __init__(self, communication_manager):
        """
        初始化机器人控制器

        Args:
            communication_manager: 通信管理器实例
        """
        super().__init__()
        self.comm = communication_manager
        self.running = False
        self.mutex = QMutex()

        # 线程和定时器
        self.control_thread = None
        self.telemetry_timer = None
        self.status_timer = None

        # 控制模式
        self.control_mode = ControlModes.MANUAL
        self.prev_control_mode = None

        # 机器人状态
        self.robot_status = {
            "depth": 0.0,
            "heading": 0.0,
            "pitch": 0.0,
            "roll": 0.0,
            "temperature": 0.0,
            "pressure": 0.0,
            "battery": 100.0,
            "motor_status": [0, 0, 0, 0, 0, 0],
            "leak_detected": False,
            "system_time": 0,
            "errors": []
        }

        # 上次收到状态数据的时间
        self.last_status_time = 0

        # 手动控制输入
        self.manual_control = {
            "forward": 0.0,
            "lateral": 0.0,
            "vertical": 0.0,
            "yaw": 0.0,
            "pitch": 0.0,
            "roll": 0.0
        }

        # 控制命令历史
        self.control_history = deque(maxlen=50)

        # PID控制器
        self.pid_controllers = {
            "depth": PIDController(),
            "heading": PIDController(),
            "pitch": PIDController(),
            "roll": PIDController(),
            "x": PIDController(),
            "y": PIDController()
        }

        # 推力分配器
        self.thrust_allocator = ThrustAllocator()

        # 状态估计器
        self.state_estimator = StateEstimator()

        # 数据记录器
        self.data_logger = DataLogger()

        # 电机输出
        self.motor_outputs = np.zeros(6)

        # 故障标志和计数器
        self.connection_loss_count = 0
        self.error_condition = False
        self.recovery_mode = False

        # 初始化PID参数
        self._init_pid_parameters()

        # 连接信号
        self.comm.data_received.connect(self._handle_received_data)
        self.comm.connection_status.connect(self._handle_connection_status)

        # 预热状态估计器
        self._warm_up_estimator()

    def _init_pid_parameters(self):
        """初始化PID参数"""
        for name, controller in self.pid_controllers.items():
            params = config.PID_DEFAULTS.get(name, {})
            controller.set_parameters(
                params.get("kp", 0.0),
                params.get("ki", 0.0),
                params.get("kd", 0.0),
                params.get("ff", 0.0)
            )
            controller.set_target(params.get("target", 0.0))
            controller.set_output_limit(1.0)
            controller.set_integral_limit(0.5)

    def _warm_up_estimator(self):
        """预热状态估计器"""
        # 使用当前状态初始化估计器
        init_state = np.zeros(12)
        init_state[2] = self.robot_status["depth"]
        init_state[3] = self.robot_status["roll"]
        init_state[4] = self.robot_status["pitch"]
        init_state[5] = self.robot_status["heading"]

        self.state_estimator.state = init_state

        # 模拟几个预测和更新步骤
        for _ in range(10):
            self.state_estimator.predict(0.1)
            self.state_estimator.update(init_state[:6])

    def start(self):
        """启动控制系统"""
        if self.running:
            return True

        with QMutexLocker(self.mutex):
            self.running = True

            # 启动控制线程
            self.control_thread = threading.Thread(target=self._control_loop)
            self.control_thread.daemon = True
            self.control_thread.start()

            # 启动遥测定时器
            if self.telemetry_timer is None:
                self.telemetry_timer = QTimer()
                self.telemetry_timer.timeout.connect(self._update_telemetry)
                self.telemetry_timer.start(200)  # 5Hz遥测更新



            # 启动状态定时器
            if self.status_timer is None:
                self.status_timer = QTimer()
                self.status_timer.timeout.connect(self._update_status)
                self.status_timer.start(100)  # 10Hz状态更新

            # 开始数据记录
            if not self.data_logger.is_logging:
                self.data_logger.start_logging()

            return True

    def stop(self):
        """停止控制系统"""
        with QMutexLocker(self.mutex):
            self.running = False

            # 停止电机
            self.emergency_stop()

            # 等待控制线程结束
            if self.control_thread:
                self.control_thread.join(timeout=1.0)

            # 停止定时器
            if self.telemetry_timer:
                self.telemetry_timer.stop()

            if self.status_timer:
                self.status_timer.stop()

            # 停止数据记录
            if self.data_logger.is_logging:
                self.data_logger.stop_logging()

    def set_manual_control(self, control_data):
        """
        设置手动控制输入

        Args:
            control_data: 控制数据字典
        """
        with QMutexLocker(self.mutex):
            # 更新手动控制值
            self.manual_control.update(control_data)

            # 记录数据
            if self.data_logger.is_logging:
                self.data_logger.log_data("manual_control", self.manual_control.copy())

    def set_control_mode(self, mode):
        """
        设置控制模式

        Args:
            mode: 控制模式

        Returns:
            bool: 是否成功设置模式
        """
        if not ControlModes.is_valid(mode):
            self.error.emit(f"无效的控制模式: {mode}")
            return False

        with QMutexLocker(self.mutex):
            if mode != self.control_mode:
                self.prev_control_mode = self.control_mode
                self.control_mode = mode

                # 控制模式变化时重置PID控制器
                for controller in self.pid_controllers.values():
                    controller.reset()

                # 根据当前状态设置PID目标
                if mode in [ControlModes.DEPTH_HOLD, ControlModes.STABILIZE, ControlModes.POSITION_HOLD]:
                    self.pid_controllers["depth"].set_target(self.robot_status["depth"])

                if mode in [ControlModes.HEADING_HOLD, ControlModes.STABILIZE, ControlModes.POSITION_HOLD]:
                    self.pid_controllers["heading"].set_target(self.robot_status["heading"])

                if mode in [ControlModes.STABILIZE, ControlModes.POSITION_HOLD]:
                    self.pid_controllers["pitch"].set_target(0.0)  # 通常目标是保持水平
                    self.pid_controllers["roll"].set_target(0.0)  # 通常目标是保持水平

                if mode == ControlModes.POSITION_HOLD:
                    # 获取当前估计位置
                    position = self.state_estimator.get_position_attitude()[:2]  # x, y
                    self.pid_controllers["x"].set_target(position[0])
                    self.pid_controllers["y"].set_target(position[1])

                # 发送模式变化信号
                self.mode_changed.emit(mode)

                # 记录模式变化
                if self.data_logger.is_logging:
                    self.data_logger.log_data("mode_change", {"new_mode": mode, "prev_mode": self.prev_control_mode})

                return True
        return False

    def set_pid_parameters(self, controller_name, kp=None, ki=None, kd=None, ff=None, target=None):
        """
        设置PID参数

        Args:
            controller_name: 控制器名称
            kp: 比例系数
            ki: 积分系数
            kd: 微分系数
            ff: 前馈系数
            target: 目标值

        Returns:
            bool: 是否成功设置参数
        """
        if controller_name not in self.pid_controllers:
            self.error.emit(f"无效的PID控制器名称: {controller_name}")
            return False

        with QMutexLocker(self.mutex):
            controller = self.pid_controllers[controller_name]
            params_changed = controller.set_parameters(kp, ki, kd, ff)
            target_changed = False

            if target is not None:
                target_changed = controller.set_target(target)

            # 如果参数有变化，发送更新信号
            if params_changed or target_changed:
                self._send_pid_update()

                # 记录PID参数变化
                if self.data_logger.is_logging:
                    self.data_logger.log_data("pid_change", {
                        "controller": controller_name,
                        "parameters": controller.get_status()
                    })

            return params_changed or target_changed

    def _control_loop(self):
        """控制循环线程"""
        last_time = time.time()
        control_interval = 1.0 / config.CONTROL_UPDATE_RATE

        while self.running:
            try:
                # 计算时间间隔
                current_time = time.time()
                dt = current_time - last_time

                # 控制频率
                if dt < control_interval:
                    time.sleep(0.001)  # 短暂休眠，减少CPU使用
                    continue

                last_time = current_time

                with QMutexLocker(self.mutex):
                    # 更新状态估计
                    control_input = self._convert_to_force_vector(self.manual_control)
                    self.state_estimator.predict(dt, control_input)

                    # 根据控制模式计算期望的力和力矩
                    desired_forces = self._compute_desired_forces(dt)

                    # 分配推力到各个推进器
                    self.motor_outputs = self.thrust_allocator.allocate(desired_forces)

                    # 保存控制命令历史
                    self.control_history.append({
                        "time": current_time,
                        "desired_forces": desired_forces.tolist(),
                        "motor_outputs": self.motor_outputs.tolist()
                    })

                    # 发送控制命令
                    if self.comm.is_connected() and not self.error_condition:
                        control_command = {
                            "type": "control",
                            "motors": self.motor_outputs.tolist(),
                            "mode": self.control_mode
                        }
                        self.comm.send_data(control_command)

                        # 记录发送的控制命令
                        if self.data_logger.is_logging:
                            self.data_logger.log_data("control_command", control_command)

            except Exception as e:
                self.error.emit(f"控制循环错误: {str(e)}")
                time.sleep(0.1)

    def _compute_desired_forces(self, dt):
        """
        根据控制模式计算期望的力和力矩

        Args:
            dt: 时间间隔

        Returns:
            np.array: 期望的力和力矩向量 [surge, sway, heave, roll, pitch, yaw]
        """
        # 初始化期望的力和力矩
        desired_forces = np.zeros(6)

        # 根据控制模式计算
        if self.control_mode == ControlModes.MANUAL:
            # 手动模式直接使用手动控制输入
            desired_forces = self._convert_to_force_vector(self.manual_control)

        elif self.control_mode == ControlModes.DEPTH_HOLD:
            # 深度保持模式
            # 垂直方向使用PID控制
            depth_output = self.pid_controllers["depth"].compute(self.robot_status["depth"], dt)

            # 其他方向使用手动控制
            desired_forces = self._convert_to_force_vector(self.manual_control)
            desired_forces[2] = depth_output  # 使用PID输出控制垂直推力

        elif self.control_mode == ControlModes.HEADING_HOLD:
            # 航向保持模式
            # 偏航使用PID控制
            heading_output = self.pid_controllers["heading"].compute(self.robot_status["heading"], dt)

            # 其他方向使用手动控制
            desired_forces = self._convert_to_force_vector(self.manual_control)
            desired_forces[5] = heading_output  # 使用PID输出控制偏航力矩

        elif self.control_mode == ControlModes.STABILIZE:
            # 稳定模式
            # 深度、航向、俯仰和横滚使用PID控制
            depth_output = self.pid_controllers["depth"].compute(self.robot_status["depth"], dt)
            heading_output = self.pid_controllers["heading"].compute(self.robot_status["heading"], dt)
            pitch_output = self.pid_controllers["pitch"].compute(self.robot_status["pitch"], dt)
            roll_output = self.pid_controllers["roll"].compute(self.robot_status["roll"], dt)

            # 前后和左右使用手动控制
            desired_forces[0] = self.manual_control["forward"]  # 前后
            desired_forces[1] = self.manual_control["lateral"]  # 左右
            desired_forces[2] = depth_output  # 垂直
            desired_forces[3] = roll_output  # 横滚力矩
            desired_forces[4] = pitch_output  # 俯仰力矩
            desired_forces[5] = heading_output  # 偏航力矩

        elif self.control_mode == ControlModes.POSITION_HOLD:
            # 位置保持模式
            # 需要地理位置信息，此处简化为保持深度、航向、俯仰和横滚
            depth_output = self.pid_controllers["depth"].compute(self.robot_status["depth"], dt)
            heading_output = self.pid_controllers["heading"].compute(self.robot_status["heading"], dt)
            pitch_output = self.pid_controllers["pitch"].compute(self.robot_status["pitch"], dt)
            roll_output = self.pid_controllers["roll"].compute(self.robot_status["roll"], dt)

            # 提取估计的位置
            position = self.state_estimator.get_position_attitude()[:2]  # x, y

            # 计算位置控制输出
            x_output = self.pid_controllers["x"].compute(position[0], dt)
            y_output = self.pid_controllers["y"].compute(position[1], dt)

            # 将位置控制输出转换为前进和横移推力
            # 考虑航向角将局部坐标系的力转换到全局坐标系
            heading_rad = np.radians(self.robot_status["heading"])
            surge = x_output * np.cos(heading_rad) + y_output * np.sin(heading_rad)
            sway = -x_output * np.sin(heading_rad) + y_output * np.cos(heading_rad)

            desired_forces[0] = surge  # 前后
            desired_forces[1] = sway  # 左右
            desired_forces[2] = depth_output  # 垂直
            desired_forces[3] = roll_output  # 横滚力矩
            desired_forces[4] = pitch_output  # 俯仰力矩
            desired_forces[5] = heading_output  # 偏航力矩

        elif self.control_mode == ControlModes.AUTO:
            # 自动模式
            # 此处可以实现任务规划和路径跟踪
            # 简化为稳定模式的逻辑
            self._compute_desired_forces_for_auto(dt, desired_forces)

        return desired_forces

    def _compute_desired_forces_for_auto(self, dt, desired_forces):
        """
        计算自动模式下的期望力和力矩

        Args:
            dt: 时间间隔
            desired_forces: 输出参数，期望的力和力矩数组
        """
        # 自动模式需要实现特定任务的逻辑
        # 这里简化为与稳定模式相同的逻辑
        depth_output = self.pid_controllers["depth"].compute(self.robot_status["depth"], dt)
        heading_output = self.pid_controllers["heading"].compute(self.robot_status["heading"], dt)
        pitch_output = self.pid_controllers["pitch"].compute(self.robot_status["pitch"], dt)
        roll_output = self.pid_controllers["roll"].compute(self.robot_status["roll"], dt)

        # 在自动模式下，前进推力和横移推力也可以由控制算法生成
        # 这里简化为使用固定的前进推力
        desired_forces[0] = 0.2  # 较小的前进推力
        desired_forces[1] = 0.0  # 无横移
        desired_forces[2] = depth_output  # 垂直
        desired_forces[3] = roll_output  # 横滚力矩
        desired_forces[4] = pitch_output  # 俯仰力矩
        desired_forces[5] = heading_output  # 偏航力矩

    def _convert_to_force_vector(self, manual_control):
        """
        将手动控制输入转换为力和力矩向量

        Args:
            manual_control: 手动控制输入字典

        Returns:
            np.array: 力和力矩向量 [surge, sway, heave, roll, pitch, yaw]
        """
        # 初始化力向量
        forces = np.zeros(6)

        # 转换手动控制输入到力和力矩
        forces[0] = manual_control["forward"]  # 前后推力(surge)
        forces[1] = manual_control["lateral"]  # 左右推力(sway)
        forces[2] = manual_control["vertical"]  # 上下推力(heave)
        forces[3] = manual_control["roll"]  # 横滚力矩
        forces[4] = manual_control["pitch"]  # 俯仰力矩
        forces[5] = manual_control["yaw"]  # 偏航力矩

        return forces

    def _handle_received_data(self, data):
        """
        处理接收到的数据

        Args:
            data: 接收到的数据字典
        """
        try:
            # 重置连接丢失计数
            self.connection_loss_count = 0

            # 更新机器人状态
            if data.get("type") == "status":
                with QMutexLocker(self.mutex):
                    status_data = data.get("status", {})
                    measurement_time = data.get("timestamp", time.time())

                    # 更新状态
                    self.robot_status.update(status_data)
                    self.last_status_time = measurement_time

                    # 提取位置和姿态测量
                    measurements = np.array([
                        0.0,  # x 位置通常未知
                        0.0,  # y 位置通常未知
                        status_data.get("depth", self.robot_status["depth"]),
                        status_data.get("roll", self.robot_status["roll"]),
                        status_data.get("pitch", self.robot_status["pitch"]),
                        status_data.get("heading", self.robot_status["heading"])
                    ])

                    # 更新状态估计
                    self.state_estimator.update(measurements, measurement_time)

                    # 记录状态数据
                    if self.data_logger.is_logging:
                        self.data_logger.log_data("robot_status", status_data)

            # 处理其他类型的数据
            elif data.get("type") == "echo":
                # 回声请求，用于测试通信延迟
                echo_data = {
                    "type": "echo_response",
                    "original_timestamp": data.get("timestamp", 0)
                }
                self.comm.send_data(echo_data)

            elif data.get("type") == "error":
                # 机器人报告错误
                error_msg = data.get("message", "未知错误")
                self.error.emit(f"机器人错误: {error_msg}")

                # 记录错误
                if self.data_logger.is_logging:
                    self.data_logger.log_data("robot_error", data)

            elif data.get("type") == "config":
                # 配置数据
                if self.data_logger.is_logging:
                    self.data_logger.log_data("config", data)

        except Exception as e:
            self.error.emit(f"处理接收数据错误: {str(e)}")

    def _handle_connection_status(self, connected):
        """
        处理连接状态变化

        Args:
            connected: 是否已连接
        """
        if connected:
            # 连接成功
            self.connection_loss_count = 0
            self.error_condition = False

            # 如果之前在恢复模式，切换回之前的控制模式
            if self.recovery_mode:
                self.recovery_mode = False
                if self.prev_control_mode:
                    self.set_control_mode(self.prev_control_mode)

            # 记录连接事件
            if self.data_logger.is_logging:
                self.data_logger.log_data("connection", {"status": "connected"})

        else:
            # 连接断开
            self.connection_loss_count += 1

            # 如果连续多次失败，进入恢复模式
            if self.connection_loss_count > 3 and not self.recovery_mode:
                self.error_condition = True
                self.recovery_mode = True
                self.prev_control_mode = self.control_mode
                self.emergency_stop()

            # 记录断连事件
            if self.data_logger.is_logging:
                self.data_logger.log_data("connection", {
                    "status": "disconnected",
                    "count": self.connection_loss_count
                })

    def _update_telemetry(self):
        """更新遥测数据"""
        if not self.running:
            return

        with QMutexLocker(self.mutex):
            # 获取所有PID控制器状态
            pid_status = {}
            for name, controller in self.pid_controllers.items():
                pid_status[name] = controller.get_status()

            # 获取状态估计
            estimated_state = self.state_estimator.get_state()
            position_attitude = estimated_state[:6]
            velocities = estimated_state[6:12]

            # 创建遥测数据
            telemetry = {
                "time": time.time(),
                "control_mode": self.control_mode,
                "manual_input": self.manual_control.copy(),
                "pid_status": pid_status,
                "estimated_position": position_attitude.tolist(),
                "estimated_velocity": velocities.tolist(),
                "motor_outputs": self.motor_outputs.tolist(),
                "connection_status": {
                    "connected": self.comm.is_connected(),
                    "loss_count": self.connection_loss_count,
                    "error_condition": self.error_condition,
                    "recovery_mode": self.recovery_mode
                }
            }

            # 记录遥测数据
            if self.data_logger.is_logging:
                self.data_logger.log_data("telemetry", telemetry)

            # 发送遥测信号
            self.telemetry_updated.emit(telemetry)

    def _update_status(self):
        """更新并发送状态信号"""
        if not self.running:
            return

        # 状态数据
        with QMutexLocker(self.mutex):
            # 扩展状态数据
            status = self.robot_status.copy()

            # 添加估计的状态
            estimated_state = self.state_estimator.get_state()
            status.update({
                "estimated_x": estimated_state[0],
                "estimated_y": estimated_state[1],
                "estimated_depth": estimated_state[2],
                "estimated_roll": estimated_state[3],
                "estimated_pitch": estimated_state[4],
                "estimated_heading": estimated_state[5],
                "estimated_velocities": estimated_state[6:12].tolist()
            })

            # 检查是否长时间未收到状态更新
            time_since_last_update = time.time() - self.last_status_time
            status["time_since_update"] = time_since_last_update
            status["stale_data"] = time_since_last_update > 2.0  # 2秒为阈值

            self.status_updated.emit(status)

            # 发送控制信号
            control_info = {
                "mode": self.control_mode,
                "manual": self.manual_control.copy(),
                "motors": self.motor_outputs.tolist(),
                "recovery_mode": self.recovery_mode
            }
            self.control_updated.emit(control_info)

    def _send_pid_update(self):
        """发送PID更新信号"""
        # 获取所有PID控制器状态
        pid_params = {}
        for name, controller in self.pid_controllers.items():
            pid_params[name] = controller.get_status()

        # 发送更新信号
        self.pid_updated.emit(pid_params)

    def get_pid_parameters(self):
        """
        获取PID参数

        Returns:
            PID参数字典
        """
        params = {}
        with QMutexLocker(self.mutex):
            for name, controller in self.pid_controllers.items():
                params[name] = controller.get_status()
        return params

    def get_status(self):
        """
        获取机器人状态

        Returns:
            机器人状态字典
        """
        with QMutexLocker(self.mutex):
            return self.robot_status.copy()

    def emergency_stop(self):
        """紧急停止"""
        with QMutexLocker(self.mutex):
            # 重置所有控制输入
            for key in self.manual_control:
                self.manual_control[key] = 0.0

            # 重置所有电机输出
            self.motor_outputs = np.zeros(6)

            # 发送紧急停止命令
            if self.comm.is_connected():
                stop_command = {
                    "type": "emergency_stop"
                }
                self.comm.send_data(stop_command, priority=0)  # 高优先级发送

                # 记录紧急停止
                if self.data_logger.is_logging:
                    self.data_logger.log_data("emergency_stop", {"time": time.time()})