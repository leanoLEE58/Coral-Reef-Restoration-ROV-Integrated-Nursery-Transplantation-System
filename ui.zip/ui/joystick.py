# modules/joystick.py
"""
手柄控制模块 - 增强版
支持多手柄、自适应死区、热插拔检测、Xbox按键映射及多模式操作
"""
import time
import threading
import json
import pygame
from PyQt5.QtCore import QObject, pyqtSignal, QTimer
import numpy as np

import config


class JoystickManager(QObject):
    """增强型手柄管理器"""
    # 定义信号
    joystick_data = pyqtSignal(dict)  # 手柄数据
    button_pressed = pyqtSignal(int, int)  # 按钮按下(手柄ID, 按钮ID)
    button_released = pyqtSignal(int, int)  # 按钮释放(手柄ID, 按钮ID)
    joystick_connected = pyqtSignal(int, str)  # 手柄连接(手柄ID, 手柄名称)
    joystick_disconnected = pyqtSignal(int)  # 手柄断开(手柄ID)
    error = pyqtSignal(str)  # 错误信号
    mode_changed = pyqtSignal(str)  # 模式改变信号
    action_triggered = pyqtSignal(str, object)  # 动作触发信号（动作名，参数）

    def __init__(self):
        """初始化手柄管理器"""
        super().__init__()
        # 添加线程锁
        self.lock = threading.RLock()

        self.running = False
        self.joysticks = {}  # {joystick_id: joystick_object}
        self.active_joystick = None  # 当前活动手柄ID
        self.thread = None
        self.scan_timer = None

        # 手柄状态
        self.axes_states = {}  # {joystick_id: {axis_name: value}}
        self.button_states = {}  # {joystick_id: {button_name: state}}
        self.hat_states = {}  # {joystick_id: {hat_id: (x, y)}}

        # Xbox按钮映射
        self.button_map = {
            0: "A",
            1: "B",
            2: "X",
            3: "Y",
            4: "LB",
            5: "RB",
            6: "Back",
            7: "Start",
            8: "Home",
            9: "L3",  # 左摇杆按下
            10: "R3",  # 右摇杆按下
            # 方向键映射
            12: "DPad_Up",
            13: "DPad_Down",
            14: "DPad_Left",
            15: "DPad_Right"
        }

        # 轴映射
        self.axis_map = {
            0: "LX",  # 左摇杆水平
            1: "LY",  # 左摇杆垂直
            2: "LT",  # 左扳机
            3: "RX",  # 右摇杆水平
            4: "RY",  # 右摇杆垂直
            5: "RT"  # 右扳机
        }

        # 模式管理
        self.modes = {
            "water": {
                "name": "水中运动模式",
                "description": "全方位操控水下机器人"
            },
            "walk": {
                "name": "行走模式",
                "description": "使用履带进行陆地行走"
            },
            "seedling": {
                "name": "育苗模式",
                "description": "精确控制上下移动"
            },
            "transplant": {
                "name": "移植模式",
                "description": "控制移植机构"
            }
        }
        self.current_mode = "water"  # 默认为水中运动模式

        # 特技模式
        self.special_mode_active = False
        self.current_stunt = 0
        self.stunts = [
            {"name": "特技动作1", "description": "快速旋转"},
            {"name": "特技动作2", "description": "前后摇摆"},
            {"name": "特技动作3", "description": "左右摇摆"},
            {"name": "特技动作4", "description": "Z字形移动"}
        ]

        # 功能绑定
        self.function_bindings = {
            # 模式切换
            "Y": {"action": "change_mode", "params": "water"},
            "B": {"action": "change_mode", "params": "transplant"},
            "X": {"action": "change_mode", "params": "walk"},
            "A": {"action": "change_mode", "params": "seedling"},

            # 方向键功能
            "DPad_Up": {"action": "gel_injection", "params": None},
            "DPad_Down": {"action": "toggle_stunt_mode", "params": None},
            "DPad_Left": {"action": "rotate_key", "params": "cw"},
            "DPad_Right": {"action": "rotate_key", "params": "ccw"},

            # 组合键功能
            "LB+DPad_Up": {"action": "preset_position", "params": 1},
            "LB+DPad_Down": {"action": "preset_position", "params": 2},
            "LB+DPad_Left": {"action": "preset_position", "params": 3},
            "LB+DPad_Right": {"action": "preset_position", "params": 4},

            "RB+DPad_Up": {"action": "custom_action", "params": 1},
            "RB+DPad_Down": {"action": "custom_action", "params": 2},
            "RB+DPad_Left": {"action": "custom_action", "params": 3},
            "RB+DPad_Right": {"action": "custom_action", "params": 4},

            # 特殊功能键
            "L3": {"action": "toggle_auto_depth", "params": None},
            "R3": {"action": "toggle_precision", "params": None},
            "Back": {"action": "switch_camera", "params": None},
            "Start": {"action": "system_menu", "params": None},
            "LB+RB": {"action": "emergency_stop", "params": None}
        }

        # 自适应死区
        self.dead_zones = {}  # {joystick_id: {axis_name: dead_zone}}
        self.calibration_samples = {}  # {joystick_id: {axis_name: [samples]}}
        self.calibration_mode = False

        # 控制状态
        self.auto_depth_enabled = False
        self.auto_heading_enabled = False
        self.precision_mode = False
        self.last_pressed_buttons = []  # 用于检测组合键

        # 初始化pygame
        try:
            pygame.init()
            pygame.joystick.init()
        except Exception as e:
            self.error.emit(f"初始化手柄控制失败: {str(e)}")

    def start(self):
        """启动手柄管理"""
        if self.running:
            return True

        self.running = True

        # 创建并启动手柄处理线程
        self.thread = threading.Thread(target=self._joystick_thread)
        self.thread.daemon = True
        self.thread.start()

        # 创建定时器，用于定期扫描手柄
        self.scan_timer = QTimer()
        self.scan_timer.timeout.connect(self._scan_joysticks)
        self.scan_timer.start(2000)  # 每2秒扫描一次

        # 立即扫描一次手柄
        self._scan_joysticks()

        return True

    def stop(self):
        """停止手柄管理"""
        self.running = False

        # 停止扫描定时器
        if self.scan_timer:
            self.scan_timer.stop()

        # 等待线程结束
        if self.thread:
            self.thread.join(timeout=1.0)

        # 清理所有手柄
        with self.lock:
            for joy_id in list(self.joysticks.keys()):
                self._remove_joystick(joy_id)

            # 清理pygame
            try:
                pygame.joystick.quit()
                pygame.quit()
            except:
                pass

    def set_active_joystick(self, joystick_id):
        """设置当前活动手柄"""
        with self.lock:
            if joystick_id in self.joysticks:
                self.active_joystick = joystick_id
                return True
            return False

    def start_calibration(self):
        """开始死区校准"""
        with self.lock:
            self.calibration_mode = True
            self.calibration_samples = {}

            # 为每个手柄的每个轴初始化校准样本数组
            for joy_id in self.joysticks:
                self.calibration_samples[joy_id] = {}
                for axis_name in self.axes_states.get(joy_id, {}):
                    self.calibration_samples[joy_id][axis_name] = []

        return True

    def stop_calibration(self):
        """结束死区校准并计算新的死区值"""
        if not self.calibration_mode:
            return False

        with self.lock:
            self.calibration_mode = False

            # 计算每个手柄每个轴的死区
            for joy_id in self.calibration_samples:
                if joy_id not in self.dead_zones:
                    self.dead_zones[joy_id] = {}

                for axis_name, samples in self.calibration_samples[joy_id].items():
                    if samples:
                        # 计算静止状态下的最大偏移
                        max_offset = max([abs(s) for s in samples])
                        # 设置死区为最大偏移的1.2倍，确保有足够余量
                        self.dead_zones[joy_id][axis_name] = min(max_offset * 1.2, 0.25)

            # 清空校准样本
            self.calibration_samples = {}

        return True

    def get_joystick_list(self):
        """获取已连接的手柄列表"""
        with self.lock:
            joystick_list = []
            for joy_id, joy in self.joysticks.items():
                joystick_list.append({
                    "id": joy_id,
                    "name": joy.get_name(),
                    "num_axes": joy.get_numaxes(),
                    "num_buttons": joy.get_numbuttons(),
                    "num_hats": joy.get_numhats(),
                    "active": joy_id == self.active_joystick
                })
            return joystick_list

    def change_mode(self, mode):
        """切换操作模式"""
        if mode in self.modes:
            self.current_mode = mode
            self.mode_changed.emit(mode)
            return True
        return False

    def execute_action(self, action_name, params=None):
        """执行指定动作"""
        self.action_triggered.emit(action_name, params)

        # 处理内部状态变化的动作
        if action_name == "toggle_auto_depth":
            self.auto_depth_enabled = not self.auto_depth_enabled
        elif action_name == "toggle_auto_heading":
            self.auto_heading_enabled = not self.auto_heading_enabled
        elif action_name == "toggle_precision":
            self.precision_mode = not self.precision_mode
        elif action_name == "toggle_stunt_mode":
            self.special_mode_active = not self.special_mode_active

        return True

    def save_configuration(self, filename="joystick_config.json"):
        """保存当前手柄配置"""
        with self.lock:
            config_data = {
                "dead_zones": self.dead_zones,
                "button_map": self.button_map,
                "axis_map": self.axis_map,
                "function_bindings": self.function_bindings
            }

            try:
                with open(filename, 'w') as f:
                    json.dump(config_data, f, indent=2)
                return True
            except Exception as e:
                self.error.emit(f"保存配置失败: {str(e)}")
                return False

    def load_configuration(self, filename="joystick_config.json"):
        """加载手柄配置"""
        try:
            with open(filename, 'r') as f:
                config_data = json.load(f)

            with self.lock:
                if "dead_zones" in config_data:
                    self.dead_zones = config_data["dead_zones"]
                if "button_map" in config_data:
                    self.button_map = config_data["button_map"]
                if "axis_map" in config_data:
                    self.axis_map = config_data["axis_map"]
                if "function_bindings" in config_data:
                    self.function_bindings = config_data["function_bindings"]
            return True
        except FileNotFoundError:
            return False
        except Exception as e:
            self.error.emit(f"加载配置失败: {str(e)}")
            return False

    def debug_joystick_info(self):
        """打印手柄调试信息"""
        print("\n===== 手柄调试信息 =====")
        print(f"Pygame版本: {pygame.version.ver}")
        print(f"检测到手柄数量: {pygame.joystick.get_count()}")
        print(f"活动手柄ID: {self.active_joystick}")
        print(f"当前操作模式: {self.current_mode}")
        print(f"当前死区配置: {self.dead_zones}")
        print(f"校准模式: {self.calibration_mode}")
        print(f"特技模式: {'开启' if self.special_mode_active else '关闭'}")

        if self.joysticks:
            for joy_id, joy in self.joysticks.items():
                print(f"\n手柄 #{joy_id}:")
                print(f"  名称: {joy.get_name()}")
                print(f"  轴数量: {joy.get_numaxes()}")
                print(f"  按钮数量: {joy.get_numbuttons()}")
                print(f"  摇杆帽数量: {joy.get_numhats()}")

                # 显示当前值
                if joy_id in self.axes_states:
                    print("\n  当前轴值:")
                    for axis_name, value in self.axes_states[joy_id].items():
                        print(f"    {axis_name}: {value:.3f}")

                if joy_id in self.button_states:
                    print("\n  当前按钮状态:")
                    for button_name, state in self.button_states[joy_id].items():
                        print(f"    {button_name}: {state}")
        else:
            print("未检测到手柄设备")

        print("=======================")

    def _scan_joysticks(self):
        """扫描并更新已连接的手柄"""
        try:
            # 检查当前连接的手柄数量
            current_count = pygame.joystick.get_count()

            # 只有在手柄数量变化时才重新初始化
            if current_count != len(self.joysticks):
                with self.lock:
                    # 重新扫描手柄设备
                    pygame.joystick.quit()
                    pygame.joystick.init()

                    # 获取当前连接的手柄数量
                    joystick_count = pygame.joystick.get_count()

                    # 检查新连接的手柄
                    for i in range(joystick_count):
                        if i not in self.joysticks:
                            self._add_joystick(i)

                    # 检查已断开的手柄
                    for joy_id in list(self.joysticks.keys()):
                        if joy_id >= joystick_count:
                            self._remove_joystick(joy_id)

                    # 如果没有活动手柄但有可用手柄，则设置第一个为活动
                    if self.active_joystick is None and self.joysticks:
                        self.active_joystick = next(iter(self.joysticks.keys()))

        except Exception as e:
            self.error.emit(f"扫描手柄设备出错: {str(e)}")

    def _add_joystick(self, joy_id):
        """添加新手柄"""
        try:
            joy = pygame.joystick.Joystick(joy_id)
            joy.init()

            # 存储手柄对象
            self.joysticks[joy_id] = joy

            # 初始化状态字典
            self.axes_states[joy_id] = {}
            self.button_states[joy_id] = {}
            self.hat_states[joy_id] = {}

            # 初始化轴状态
            for i in range(joy.get_numaxes()):
                axis_name = self.axis_map.get(i, f"Axis{i}")
                self.axes_states[joy_id][axis_name] = 0.0

            # 初始化按钮状态
            for i in range(joy.get_numbuttons()):
                button_name = self.button_map.get(i, f"Button{i}")
                self.button_states[joy_id][button_name] = False

            # 初始化摇杆帽状态
            for i in range(joy.get_numhats()):
                self.hat_states[joy_id][i] = (0, 0)

            # 初始化死区
            if joy_id not in self.dead_zones:
                self.dead_zones[joy_id] = {}
                for axis_name in self.axes_states[joy_id]:
                    self.dead_zones[joy_id][axis_name] = config.JOYSTICK_DEADZONE

            # 发出连接信号
            self.joystick_connected.emit(joy_id, joy.get_name())

            # 如果这是第一个手柄，设为活动
            if self.active_joystick is None:
                self.active_joystick = joy_id

        except Exception as e:
            self.error.emit(f"添加手柄 {joy_id} 失败: {str(e)}")

    def _remove_joystick(self, joy_id):
        """移除断开的手柄"""
        if joy_id in self.joysticks:
            try:
                # 清理手柄对象
                self.joysticks[joy_id].quit()
            except:
                pass

            # 移除手柄数据
            del self.joysticks[joy_id]

            if joy_id in self.axes_states:
                del self.axes_states[joy_id]
            if joy_id in self.button_states:
                del self.button_states[joy_id]
            if joy_id in self.hat_states:
                del self.hat_states[joy_id]

            # 发出断开信号
            self.joystick_disconnected.emit(joy_id)

            # 如果当前活动手柄被移除，选择新的活动手柄
            if joy_id == self.active_joystick:
                if self.joysticks:
                    self.active_joystick = next(iter(self.joysticks.keys()))
                else:
                    self.active_joystick = None

    def _joystick_thread(self):
        """手柄控制线程"""
        last_update_time = time.time()
        update_interval = 1.0 / config.CONTROL_UPDATE_RATE
        max_operation_time = 0.5  # 最大操作时间（秒）

        failure_count = 0  # 失败计数

        while self.running:
            try:
                # 处理所有pygame事件
                operation_start = time.time()
                pygame.event.pump()

                # 检查操作是否超时
                if time.time() - operation_start > max_operation_time:
                    self.error.emit("手柄事件处理超时")
                    failure_count += 1
                    if failure_count > 5:
                        self._recover_from_failure()
                        failure_count = 0
                    continue

                # 当前时间
                current_time = time.time()

                # 控制更新频率
                if current_time - last_update_time < update_interval:
                    time.sleep(0.001)
                    continue

                last_update_time = current_time

                # 处理所有已连接的手柄
                for joy_id, joy in list(self.joysticks.items()):
                    try:
                        # 检查手柄是否仍然有效
                        if not self._is_joystick_valid(joy):
                            with self.lock:
                                self._remove_joystick(joy_id)
                            continue

                        # 读取轴数据
                        for i in range(joy.get_numaxes()):
                            axis_name = self.axis_map.get(i, f"Axis{i}")
                            value = joy.get_axis(i)

                            # 如果在校准模式下，收集样本
                            if self.calibration_mode:
                                if joy_id in self.calibration_samples and axis_name in self.calibration_samples[joy_id]:
                                    # 只收集接近零的值作为校准样本
                                    if abs(value) < 0.3:
                                        self.calibration_samples[joy_id][axis_name].append(value)
                                        # 限制样本数量
                                        if len(self.calibration_samples[joy_id][axis_name]) > 100:
                                            self.calibration_samples[joy_id][axis_name].pop(0)

                            # 应用死区
                            dead_zone = self.dead_zones.get(joy_id, {}).get(axis_name, config.JOYSTICK_DEADZONE)
                            if abs(value) < dead_zone:
                                value = 0.0

                            # 更新状态
                            self.axes_states[joy_id][axis_name] = value

                        # 读取按钮数据
                        for i in range(joy.get_numbuttons()):
                            button_name = self.button_map.get(i, f"Button{i}")
                            value = bool(joy.get_button(i))

                            # 检测按钮状态变化
                            if value != self.button_states[joy_id].get(button_name, False):
                                if value:
                                    self.button_pressed.emit(joy_id, i)
                                    self._handle_button_press(joy_id, i, button_name)
                                else:
                                    self.button_released.emit(joy_id, i)
                                    self._handle_button_release(joy_id, i, button_name)

                            # 更新状态
                            self.button_states[joy_id][button_name] = value

                        # 读取摇杆帽数据
                        for i in range(joy.get_numhats()):
                            hat_value = joy.get_hat(i)
                            self.hat_states[joy_id][i] = hat_value

                    except Exception as e:
                        self.error.emit(f"读取手柄 {joy_id} 数据出错: {str(e)}")
                        failure_count += 1

                # 发送当前活动手柄的数据
                if self.active_joystick is not None and self.active_joystick in self.axes_states:
                    joystick_data = {
                        "joystick_id": self.active_joystick,
                        "axes": self.axes_states[self.active_joystick],
                        "buttons": self.button_states[self.active_joystick],
                        "hats": self.hat_states.get(self.active_joystick, {}),
                        "movement": self.get_movement_vector(self.active_joystick),
                        "mode": self.current_mode,
                        "special_mode": self.special_mode_active,
                        "auto_depth": self.auto_depth_enabled,
                        "auto_heading": self.auto_heading_enabled,
                        "precision": self.precision_mode
                    }
                    self.joystick_data.emit(joystick_data)

                # 重置失败计数
                failure_count = 0

            except Exception as e:
                self.error.emit(f"手柄线程错误: {str(e)}")
                failure_count += 1
                if failure_count > 10:
                    self._recover_from_failure()
                    failure_count = 0
                time.sleep(0.1)

    def _recover_from_failure(self):
        """尝试从失败状态恢复"""
        with self.lock:
            try:
                self.error.emit("尝试恢复手柄功能...")
                # 完全重新初始化
                pygame.joystick.quit()
                pygame.quit()
                time.sleep(0.5)
                pygame.init()
                pygame.joystick.init()

                # 重新扫描手柄
                self._scan_joysticks()
                return True
            except Exception as e:
                self.error.emit(f"恢复失败: {str(e)}")
                return False

    def _is_joystick_valid(self, joystick):
        """检查手柄是否仍然有效"""
        try:
            # 简单地尝试获取名称作为有效性检查
            _ = joystick.get_name()
            return True
        except:
            return False

    def _handle_button_press(self, joy_id, button_id, button_name):
        """处理按钮按下事件"""
        # 只处理活动手柄的按钮
        if joy_id != self.active_joystick:
            return

        # 记录按下的按钮，用于检测组合键
        self.last_pressed_buttons.append(button_name)

        # 检查是否是组合键
        if "LB" in self.last_pressed_buttons and button_name.startswith("DPad_"):
            key = f"LB+{button_name}"
            if key in self.function_bindings:
                action = self.function_bindings[key]["action"]
                params = self.function_bindings[key]["params"]
                self.execute_action(action, params)
                return

        elif "RB" in self.last_pressed_buttons and button_name.startswith("DPad_"):
            key = f"RB+{button_name}"
            if key in self.function_bindings:
                action = self.function_bindings[key]["action"]
                params = self.function_bindings[key]["params"]
                self.execute_action(action, params)
                return

        elif "LB" in self.last_pressed_buttons and "RB" in self.last_pressed_buttons:
            key = "LB+RB"
            if key in self.function_bindings:
                action = self.function_bindings[key]["action"]
                params = self.function_bindings[key]["params"]
                self.execute_action(action, params)
                return

        # 特技模式下的按钮处理
        if self.special_mode_active:
            if button_name == "A":
                # 执行当前选中的特技动作
                self.execute_action("execute_stunt", self.current_stunt)
                return
            elif button_name == "B":
                # 退出特技模式
                self.special_mode_active = False
                self.execute_action("toggle_stunt_mode", False)
                return
            elif button_name == "DPad_Up":
                # 选择上一个特技
                self.current_stunt = (self.current_stunt - 1) % len(self.stunts)
                self.execute_action("select_stunt", self.current_stunt)
                return
            elif button_name == "DPad_Down":
                # 选择下一个特技
                self.current_stunt = (self.current_stunt + 1) % len(self.stunts)
                self.execute_action("select_stunt", self.current_stunt)
                return

        # 单键处理
        if button_name in self.function_bindings:
            action = self.function_bindings[button_name]["action"]
            params = self.function_bindings[button_name]["params"]

            # 模式切换按钮
            if action == "change_mode":
                self.change_mode(params)
            else:
                self.execute_action(action, params)

    def _handle_button_release(self, joy_id, button_id, button_name):
        """处理按钮释放事件"""
        # 只处理活动手柄的按钮
        if joy_id != self.active_joystick:
            return

        # 从按下列表中移除
        if button_name in self.last_pressed_buttons:
            self.last_pressed_buttons.remove(button_name)

    def get_movement_vector(self, joystick_id=None):
        """
        获取移动向量，根据当前模式调整控制逻辑

        Args:
            joystick_id: 指定手柄ID，默认使用活动手柄

        Returns:
            dict: 包含forward, lateral, vertical, yaw, pitch, roll的字典
        """
        # 获取指定或活动手柄的状态
        if joystick_id is None:
            joystick_id = self.active_joystick

        if joystick_id is None or joystick_id not in self.axes_states:
            return {
                "forward": 0.0,
                "lateral": 0.0,
                "vertical": 0.0,
                "yaw": 0.0,
                "pitch": 0.0,
                "roll": 0.0
            }

        axes = self.axes_states[joystick_id]

        # 基础移动向量
        movement = {
            "forward": 0.0,
            "lateral": 0.0,
            "vertical": 0.0,
            "yaw": 0.0,
            "pitch": 0.0,
            "roll": 0.0
        }

        # 根据当前模式调整控制逻辑
        if self.current_mode == "water":
            # 水中模式: 全方位控制
            movement["forward"] = -axes.get("LY", 0.0)  # 前后移动(左摇杆上下)
            movement["lateral"] = axes.get("LX", 0.0)  # 左右移动(左摇杆左右)
            movement["yaw"] = axes.get("RX", 0.0)  # 偏航/转向(右摇杆左右)
            movement["pitch"] = -axes.get("RY", 0.0)  # 俯仰(右摇杆上下)

            # 使用扳机控制垂直移动
            if "LT" in axes and "RT" in axes:
                # 映射扳机从-1到1到0到1范围
                left_trigger = (axes.get("LT", 0.0) + 1.0) / 2.0
                right_trigger = (axes.get("RT", 0.0) + 1.0) / 2.0
                movement["vertical"] = right_trigger - left_trigger  # 上升(RT) - 下降(LT)

        elif self.current_mode == "walk":
            # 行走模式: 履带控制，垂直固定
            movement["forward"] = -axes.get("LY", 0.0)  # 前后移动(左摇杆上下)
            movement["lateral"] = 0.0  # 锁定左右移动
            movement["vertical"] = 0.0  # 锁定垂直移动
            movement["yaw"] = axes.get("LX", 0.0)  # 使用左摇杆左右控制转向
            movement["pitch"] = 0.0  # 锁定俯仰
            movement["roll"] = 0.0  # 锁定翻滚

            # 可以使用右摇杆控制工具/机械臂

        elif self.current_mode == "seedling":
            # 育苗模式: 精确上下移动，水平固定
            movement["forward"] = -axes.get("LY", 0.0) * 0.3  # 微小前后调整
            movement["lateral"] = axes.get("LX", 0.0) * 0.3  # 微小左右调整
            movement["yaw"] = axes.get("RX", 0.0) * 0.3  # 微小偏航调整
            movement["pitch"] = -axes.get("RY", 0.0) * 0.3  # 微小俯仰调整

            # 垂直移动使用扳机，但更加精确
            if "LT" in axes and "RT" in axes:
                left_trigger = (axes.get("LT", 0.0) + 1.0) / 2.0
                right_trigger = (axes.get("RT", 0.0) + 1.0) / 2.0
                # 较低的灵敏度用于精确控制
                movement["vertical"] = (right_trigger - left_trigger) * 0.7

        elif self.current_mode == "transplant":
            # 移植模式: 控制移植机构
            movement["forward"] = -axes.get("LY", 0.0) * 0.5  # 控制采集/移植机构前后
            movement["lateral"] = axes.get("LX", 0.0) * 0.5  # 控制采集/移植机构左右
            movement["vertical"] = 0.0  # 不直接控制垂直

            # 使用右摇杆控制机构姿态
            movement["yaw"] = axes.get("RX", 0.0) * 0.5  # 控制机构旋转
            movement["pitch"] = -axes.get("RY", 0.0) * 0.5  # 控制机构俯仰

            # 使用扳机控制机构垂直移动或其他功能
            if "LT" in axes and "RT" in axes:
                left_trigger = (axes.get("LT", 0.0) + 1.0) / 2.0
                right_trigger = (axes.get("RT", 0.0) + 1.0) / 2.0
                movement["vertical"] = (right_trigger - left_trigger) * 0.5

        # 精细模式调整
        if self.precision_mode:
            # 降低所有控制输入的灵敏度
            for key in movement:
                movement[key] *= 0.5

        # 应用灵敏度曲线(可选)
        if hasattr(config, 'JOYSTICK_CURVE') and config.JOYSTICK_CURVE != 1.0:
            # 应用指数曲线以提供更精细的控制
            def apply_curve(value):
                sign = 1 if value >= 0 else -1
                return sign * (abs(value) ** config.JOYSTICK_CURVE)

            for key in movement:
                movement[key] = apply_curve(movement[key])

        return movement


# 向后兼容性别名，保持与原有代码的兼容
JoystickController = JoystickManager