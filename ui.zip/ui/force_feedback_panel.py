"""
力反馈控制面板 - 用于控制和显示视觉力反馈
"""
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel,
                             QSlider, QCheckBox, QComboBox, QPushButton, QGridLayout,
                             QSpinBox, QDoubleSpinBox, QTabWidget, QSplitter)
from PyQt5.QtCore import Qt, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QPixmap, QImage

from force.force_visualizer import ForceVisualizerWidget


class ForceFeedbackPanel(QWidget):
    """力反馈控制面板"""
    # 定义信号
    paramsChanged = pyqtSignal(dict)
    modeChanged = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)

        # 初始化参数
        self.params = {
            "enabled": True,
            "edge_detection": True,
            "threshold1": 50,
            "threshold2": 150,
            "blur_size": 5,
            "min_area": 500,
            "max_area": 50000,
            "force_multiplier": 1.0,
            "feedback_mode": "visual"
        }

        # 初始化UI
        self._init_ui()

    def _init_ui(self):
        """初始化用户界面"""
        main_layout = QVBoxLayout(self)

        # 创建标签页
        tab_widget = QTabWidget(self)

        # 力反馈参数标签页
        params_tab = QWidget()
        params_layout = QVBoxLayout(params_tab)

        # 启用开关
        enable_layout = QHBoxLayout()
        self.enable_check = QCheckBox("启用力反馈")
        self.enable_check.setChecked(self.params["enabled"])
        self.enable_check.toggled.connect(self._on_param_changed)
        enable_layout.addWidget(self.enable_check)

        # 力反馈模式
        enable_layout.addWidget(QLabel("模式:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["视觉力反馈", "传感器力反馈", "混合模式"])

        # 设置当前模式
        mode_map = {"visual": 0, "sensor": 1, "hybrid": 2}
        self.mode_combo.setCurrentIndex(mode_map.get(self.params["feedback_mode"], 0))
        self.mode_combo.currentIndexChanged.connect(self._on_mode_changed)
        enable_layout.addWidget(self.mode_combo)

        params_layout.addLayout(enable_layout)

        # 边缘检测参数组
        edge_group = QGroupBox("边缘检测参数")
        edge_layout = QGridLayout(edge_group)

        # 启用边缘检测
        self.edge_detection_check = QCheckBox("启用边缘检测")
        self.edge_detection_check.setChecked(self.params["edge_detection"])
        self.edge_detection_check.toggled.connect(self._on_param_changed)
        edge_layout.addWidget(self.edge_detection_check, 0, 0, 1, 2)

        # 边缘阈值1
        edge_layout.addWidget(QLabel("阈值1:"), 1, 0)
        self.threshold1_spin = QSpinBox()
        self.threshold1_spin.setRange(0, 255)
        self.threshold1_spin.setValue(self.params["threshold1"])
        self.threshold1_spin.valueChanged.connect(self._on_param_changed)
        edge_layout.addWidget(self.threshold1_spin, 1, 1)

        # 边缘阈值2
        edge_layout.addWidget(QLabel("阈值2:"), 2, 0)
        self.threshold2_spin = QSpinBox()
        self.threshold2_spin.setRange(0, 255)
        self.threshold2_spin.setValue(self.params["threshold2"])
        self.threshold2_spin.valueChanged.connect(self._on_param_changed)
        edge_layout.addWidget(self.threshold2_spin, 2, 1)

        # 模糊核大小
        edge_layout.addWidget(QLabel("模糊核大小:"), 3, 0)
        self.blur_spin = QSpinBox()
        self.blur_spin.setRange(1, 15)
        self.blur_spin.setSingleStep(2)  # 只允许奇数
        self.blur_spin.setValue(self.params["blur_size"])
        self.blur_spin.valueChanged.connect(self._ensure_odd)
        edge_layout.addWidget(self.blur_spin, 3, 1)

        params_layout.addWidget(edge_group)

        # 轮廓过滤组
        filter_group = QGroupBox("轮廓过滤")
        filter_layout = QGridLayout(filter_group)

        # 最小面积
        filter_layout.addWidget(QLabel("最小面积:"), 0, 0)
        self.min_area_spin = QSpinBox()
        self.min_area_spin.setRange(0, 100000)
        self.min_area_spin.setSingleStep(100)
        self.min_area_spin.setValue(self.params["min_area"])
        self.min_area_spin.valueChanged.connect(self._on_param_changed)
        filter_layout.addWidget(self.min_area_spin, 0, 1)

        # 最大面积
        filter_layout.addWidget(QLabel("最大面积:"), 1, 0)
        self.max_area_spin = QSpinBox()
        self.max_area_spin.setRange(1000, 1000000)
        self.max_area_spin.setSingleStep(1000)
        self.max_area_spin.setValue(self.params["max_area"])
        self.max_area_spin.valueChanged.connect(self._on_param_changed)
        filter_layout.addWidget(self.max_area_spin, 1, 1)

        params_layout.addWidget(filter_group)

        # 力参数组
        force_group = QGroupBox("力反馈参数")
        force_layout = QGridLayout(force_group)

        # 力倍率
        force_layout.addWidget(QLabel("力反馈倍率:"), 0, 0)
        self.force_multiplier_spin = QDoubleSpinBox()
        self.force_multiplier_spin.setRange(0.1, 10.0)
        self.force_multiplier_spin.setSingleStep(0.1)
        self.force_multiplier_spin.setValue(self.params["force_multiplier"])
        self.force_multiplier_spin.valueChanged.connect(self._on_param_changed)
        force_layout.addWidget(self.force_multiplier_spin, 0, 1)

        params_layout.addWidget(force_group)

        # 添加按钮
        button_layout = QHBoxLayout()

        # 应用按钮
        apply_btn = QPushButton("应用参数")
        apply_btn.clicked.connect(self._on_apply)
        button_layout.addWidget(apply_btn)

        # 重置按钮
        reset_btn = QPushButton("重置默认")
        reset_btn.clicked.connect(self._on_reset)
        button_layout.addWidget(reset_btn)

        params_layout.addLayout(button_layout)
        params_layout.addStretch()

        # 将参数标签页添加到标签页组
        tab_widget.addTab(params_tab, "参数设置")

        # 力可视化标签页
        vis_tab = QWidget()
        vis_layout = QVBoxLayout(vis_tab)

        # 添加力可视化组件
        self.force_visualizer = ForceVisualizerWidget()
        vis_layout.addWidget(self.force_visualizer)

        # 将可视化标签页添加到标签页组
        tab_widget.addTab(vis_tab, "力可视化")

        # 将标签页组添加到主布局
        main_layout.addWidget(tab_widget)

    def _ensure_odd(self, value):
        """确保模糊核大小为奇数"""
        if value % 2 == 0:
            self.blur_spin.setValue(value + 1)
        else:
            self._on_param_changed()

    def _on_param_changed(self):
        """参数变更处理"""
        # 更新参数
        self.params["enabled"] = self.enable_check.isChecked()
        self.params["edge_detection"] = self.edge_detection_check.isChecked()
        self.params["threshold1"] = self.threshold1_spin.value()
        self.params["threshold2"] = self.threshold2_spin.value()
        self.params["blur_size"] = self.blur_spin.value()
        self.params["min_area"] = self.min_area_spin.value()
        self.params["max_area"] = self.max_area_spin.value()
        self.params["force_multiplier"] = self.force_multiplier_spin.value()

    def _on_mode_changed(self, index):
        """模式变更处理"""
        mode_map = {0: "visual", 1: "sensor", 2: "hybrid"}
        mode = mode_map.get(index, "visual")
        self.params["feedback_mode"] = mode
        self.modeChanged.emit(mode)

    def _on_apply(self):
        """应用参数"""
        self.paramsChanged.emit(self.params.copy())

    def _on_reset(self):
        """重置参数"""
        # 设置默认参数
        self.enable_check.setChecked(True)
        self.edge_detection_check.setChecked(True)
        self.threshold1_spin.setValue(50)
        self.threshold2_spin.setValue(150)
        self.blur_spin.setValue(5)
        self.min_area_spin.setValue(500)
        self.max_area_spin.setValue(50000)
        self.force_multiplier_spin.setValue(1.0)
        self.mode_combo.setCurrentIndex(0)

        # 更新参数
        self._on_param_changed()
        self._on_mode_changed(0)

    def update_force_visualization(self, force_data):
        """更新力可视化"""
        if hasattr(self, 'force_visualizer'):
            self.force_visualizer.update_force_data(force_data)

    def update_edge_image(self, image):
        """更新边缘图像"""
        # 如果需要显示边缘图像，可在此实现
        pass

    def get_params(self):
        """获取当前参数"""
        return self.params.copy()