# ui/control_panel.py
"""
手柄控制和手动控制面板
"""
import math
from PyQt5.QtWidgets import (QWidget, QLabel, QVBoxLayout, QHBoxLayout, QPushButton,
                             QSlider, QGroupBox, QRadioButton, QButtonGroup, QGridLayout,
                             QProgressBar)
from PyQt5.QtCore import Qt, pyqtSignal, pyqtSlot, QTimer, QPoint
from PyQt5.QtGui import QPainter, QBrush, QColor, QPen


class VirtualJoystick(QWidget):
    """虚拟摇杆控制器"""
    positionChanged = pyqtSignal(float, float)

    def __init__(self, parent=None):
        """初始化虚拟摇杆"""
        super().__init__(parent)
        self.setMinimumSize(150, 150)
        self.setMaximumSize(250, 250)
        self.centerPos = QPoint(0, 0)
        self.handlePos = QPoint(0, 0)
        self.dragging = False
        self.handleRadius = 20
        self.baseRadius = 50
        self.deadzone = 0.1

    def resizeEvent(self, event):
        """调整大小时更新中心点"""
        self.centerPos = QPoint(self.width() // 2, self.height() // 2)
        self.handlePos = self.centerPos

    def paintEvent(self, event):
        """绘制摇杆"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 绘制外圆
        painter.setPen(QPen(QColor("#34495e"), 2))
        painter.setBrush(QBrush(QColor(0, 0, 0, 50)))
        painter.drawEllipse(self.centerPos, self.baseRadius, self.baseRadius)

        # 绘制轴线
        painter.setPen(QPen(QColor("#7f8c8d"), 1))
        painter.drawLine(self.centerPos.x() - self.baseRadius, self.centerPos.y(),
                         self.centerPos.x() + self.baseRadius, self.centerPos.y())
        painter.drawLine(self.centerPos.x(), self.centerPos.y() - self.baseRadius,
                         self.centerPos.x(), self.centerPos.y() + self.baseRadius)

        # 绘制手柄
        painter.setPen(QPen(QColor("#3498db"), 2))
        painter.setBrush(QBrush(QColor("#2980b9")))
        painter.drawEllipse(self.handlePos, self.handleRadius, self.handleRadius)

        # 绘制连接线
        if self.handlePos != self.centerPos:
            painter.setPen(QPen(QColor("#bdc3c7"), 2, Qt.DashLine))
            painter.drawLine(self.centerPos, self.handlePos)

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            if self.handlePos.x() - self.handleRadius <= event.pos().x() <= self.handlePos.x() + self.handleRadius and \
                    self.handlePos.y() - self.handleRadius <= event.pos().y() <= self.handlePos.y() + self.handleRadius:
                self.dragging = True

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if self.dragging:
            diff = event.pos() - self.centerPos
            length = min(diff.manhattanLength(), self.baseRadius)

            if length < self.baseRadius * self.deadzone:
                self.handlePos = self.centerPos
            else:
                angle = math.atan2(diff.y(), diff.x())
                self.handlePos = QPoint(
                    int(self.centerPos.x() + length * math.cos(angle)),
                    int(self.centerPos.y() + length * math.sin(angle))
                )

            # 计算并发射相对位置 (-1 到 1 范围)
            x = (self.handlePos.x() - self.centerPos.x()) / self.baseRadius
            y = (self.handlePos.y() - self.centerPos.y()) / self.baseRadius
            self.positionChanged.emit(x, y)
            self.update()

    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        if event.button() == Qt.LeftButton and self.dragging:
            self.dragging = False
            self.handlePos = self.centerPos
            self.positionChanged.emit(0, 0)
            self.update()


class JoystickIndicator(QWidget):
    """摇杆指示器组件"""

    def __init__(self, title, parent=None):
        """
        初始化摇杆指示器

        Args:
            title: 指示器标题
            parent: 父组件
        """
        super().__init__(parent)
        self.title = title
        self.x_value = 0.0
        self.y_value = 0.0

        # 初始化UI
        self._init_ui()

    def _init_ui(self):
        """初始化UI"""
        layout = QVBoxLayout(self)

        # 标题
        title_label = QLabel(self.title)
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)

        # X轴标签和滑块
        x_layout = QHBoxLayout()
        x_layout.addWidget(QLabel("X:"))
        self.x_slider = QSlider(Qt.Horizontal)
        self.x_slider.setRange(-100, 100)
        self.x_slider.setValue(0)
        self.x_slider.setEnabled(False)  # 只读
        x_layout.addWidget(self.x_slider)
        self.x_value_label = QLabel("0.00")
        self.x_value_label.setMinimumWidth(50)
        x_layout.addWidget(self.x_value_label)
        layout.addLayout(x_layout)

        # Y轴标签和滑块
        y_layout = QHBoxLayout()
        y_layout.addWidget(QLabel("Y:"))
        self.y_slider = QSlider(Qt.Horizontal)
        self.y_slider.setRange(-100, 100)
        self.y_slider.setValue(0)
        self.y_slider.setEnabled(False)  # 只读
        y_layout.addWidget(self.y_slider)
        self.y_value_label = QLabel("0.00")
        self.y_value_label.setMinimumWidth(50)
        y_layout.addWidget(self.y_value_label)
        layout.addLayout(y_layout)

    def update_values(self, x, y):
        """
        更新摇杆值

        Args:
            x: X轴值 (-1.0到1.0)
            y: Y轴值 (-1.0到1.0)
        """
        self.x_value = x
        self.y_value = y

        # 更新滑块位置
        self.x_slider.setValue(int(x * 100))
        self.y_slider.setValue(int(y * 100))

        # 更新文本标签
        self.x_value_label.setText(f"{x:.2f}")
        self.y_value_label.setText(f"{y:.2f}")


class ControlPanel(QWidget):
    """控制面板组件"""
    # 定义信号
    control_mode_changed = pyqtSignal(str)
    manual_control_updated = pyqtSignal(dict)
    emergency_stop = pyqtSignal()

    def __init__(self, robot_controller, joystick, parent=None):
        """
        初始化控制面板

        Args:
            robot_controller: 机器人控制器对象
            joystick: 手柄控制器对象
            parent: 父组件
        """
        super().__init__(parent)
        self.robot = robot_controller
        self.joystick = joystick
        self.current_control_mode = "manual"

        # 手动控制输入
        self.manual_controls = {
            "forward": 0.0,
            "lateral": 0.0,
            "vertical": 0.0,
            "yaw": 0.0,
            "pitch": 0.0,
            "roll": 0.0
        }

        # 初始化UI
        self._init_ui()

        # 更新定时器(用于模拟摇杆更新)
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self._update_indicators)
        self.update_timer.start(100)  # 10Hz

    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 创建控制模式组
        mode_group = QGroupBox("控制模式")
        mode_layout = QHBoxLayout(mode_group)

        # 控制模式单选按钮
        self.mode_group = QButtonGroup(self)

        self.manual_radio = QRadioButton("手动控制")
        self.manual_radio.setChecked(True)
        self.mode_group.addButton(self.manual_radio)
        mode_layout.addWidget(self.manual_radio)

        self.stabilize_radio = QRadioButton("稳定模式")
        self.mode_group.addButton(self.stabilize_radio)
        mode_layout.addWidget(self.stabilize_radio)

        self.auto_radio = QRadioButton("自动模式")
        self.mode_group.addButton(self.auto_radio)
        mode_layout.addWidget(self.auto_radio)

        main_layout.addWidget(mode_group)

        # 连接模式变更信号
        self.manual_radio.toggled.connect(self._on_mode_changed)
        self.stabilize_radio.toggled.connect(self._on_mode_changed)
        self.auto_radio.toggled.connect(self._on_mode_changed)

        # 添加虚拟摇杆
        joystick_group = QGroupBox("手动控制")
        joystick_layout = QGridLayout(joystick_group)

        # 左摇杆控制前进/左右
        self.left_joystick = VirtualJoystick()
        self.left_joystick.positionChanged.connect(self.handle_left_joystick)
        joystick_layout.addWidget(QLabel("前进/转向"), 0, 0, Qt.AlignCenter)
        joystick_layout.addWidget(self.left_joystick, 1, 0)

        # 右摇杆控制垂直/俯仰
        self.right_joystick = VirtualJoystick()
        self.right_joystick.positionChanged.connect(self.handle_right_joystick)
        joystick_layout.addWidget(QLabel("上浮/俯仰"), 0, 1, Qt.AlignCenter)
        joystick_layout.addWidget(self.right_joystick, 1, 1)

        main_layout.addWidget(joystick_group)

        # 在control_panel.py的_init_ui方法末尾添加
        # 手柄状态组
        joystick_status_group = QGroupBox("手柄状态")
        joystick_status_layout = QVBoxLayout(joystick_status_group)

        self.joystick_status_label = QLabel("等待手柄数据...")
        joystick_status_layout.addWidget(self.joystick_status_label)

        main_layout.addWidget(joystick_status_group)

        # 紧急停止按钮
        self.stop_btn = QPushButton("紧急停止")
        self.stop_btn.setStyleSheet("background-color: #e74c3c; font-weight: bold; height: 40px;")
        self.stop_btn.clicked.connect(self._on_emergency_stop)
        main_layout.addWidget(self.stop_btn)

        # 当前控制输出显示
        output_group = QGroupBox("控制输出")
        output_layout = QGridLayout(output_group)

        output_layout.addWidget(QLabel("前进:"), 0, 0)
        self.forward_bar = QProgressBar()
        self.forward_bar.setRange(-100, 100)
        self.forward_bar.setValue(0)
        output_layout.addWidget(self.forward_bar, 0, 1)

        output_layout.addWidget(QLabel("左右:"), 1, 0)
        self.lateral_bar = QProgressBar()
        self.lateral_bar.setRange(-100, 100)
        self.lateral_bar.setValue(0)
        output_layout.addWidget(self.lateral_bar, 1, 1)

        output_layout.addWidget(QLabel("垂直:"), 2, 0)
        self.vertical_bar = QProgressBar()
        self.vertical_bar.setRange(-100, 100)
        self.vertical_bar.setValue(0)
        output_layout.addWidget(self.vertical_bar, 2, 1)

        output_layout.addWidget(QLabel("偏航:"), 3, 0)
        self.yaw_bar = QProgressBar()
        self.yaw_bar.setRange(-100, 100)
        self.yaw_bar.setValue(0)
        output_layout.addWidget(self.yaw_bar, 3, 1)

        main_layout.addWidget(output_group)

        # 设置进度条样式
        self._setup_progress_bar_style()

        # 设置样式
        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #3498db;
                border-radius: 5px;
                margin-top: 1ex;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 3px;
            }
            QPushButton {
                background-color: #2c3e50;
                color: white;
                border: none;
                padding: 5px 10px;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #34495e;
            }
            QLabel {
                color: #ecf0f1;
            }
            QRadioButton {
                color: #ecf0f1;
            }
        """)

    def _setup_progress_bar_style(self):
        """设置进度条样式"""
        # 创建样式字符串
        style = """
            QProgressBar {
                border: 1px solid #bdc3c7;
                border-radius: 3px;
                text-align: center;
                background-color: #34495e;
            }
            QProgressBar::chunk {
                background-color: #3498db;
                width: 1px;
            }
        """

        # 应用样式
        self.forward_bar.setStyleSheet(style)
        self.lateral_bar.setStyleSheet(style)
        self.vertical_bar.setStyleSheet(style)
        self.yaw_bar.setStyleSheet(style)

        # 设置文本格式
        self.forward_bar.setFormat("%v%%")
        self.lateral_bar.setFormat("%v%%")
        self.vertical_bar.setFormat("%v%%")
        self.yaw_bar.setFormat("%v%%")

    def _on_mode_changed(self):
        """控制模式变更处理"""
        if self.manual_radio.isChecked():
            self.current_control_mode = "manual"
        elif self.stabilize_radio.isChecked():
            self.current_control_mode = "stabilize"
        elif self.auto_radio.isChecked():
            self.current_control_mode = "auto"

        # 发送模式变更信号
        self.control_mode_changed.emit(self.current_control_mode)

    def handle_left_joystick(self, x, y):
        """
        处理左侧虚拟摇杆移动

        Args:
            x: 横向位置 (-1.0到1.0)
            y: 纵向位置 (-1.0到1.0)
        """
        # 更新控制值
        self.manual_controls["lateral"] = x
        self.manual_controls["forward"] = -y  # 上为前进，所以使用负值

        # 更新显示
        self.lateral_bar.setValue(int(x * 100))
        self.forward_bar.setValue(int(-y * 100))

        # 发送控制更新信号
        self.manual_control_updated.emit(self.manual_controls.copy())

    def handle_right_joystick(self, x, y):
        """
        处理右侧虚拟摇杆移动

        Args:
            x: 横向位置 (-1.0到1.0)
            y: 纵向位置 (-1.0到1.0)
        """
        # 更新控制值
        self.manual_controls["yaw"] = x
        self.manual_controls["vertical"] = -y  # 上为上升，所以使用负值

        # 更新显示
        self.yaw_bar.setValue(int(x * 100))
        self.vertical_bar.setValue(int(-y * 100))

        # 发送控制更新信号
        self.manual_control_updated.emit(self.manual_controls.copy())

    def _on_emergency_stop(self):
        """紧急停止按钮处理"""
        # 重置所有进度条
        self.forward_bar.setValue(0)
        self.lateral_bar.setValue(0)
        self.vertical_bar.setValue(0)
        self.yaw_bar.setValue(0)

        # 重置控制值
        for key in self.manual_controls:
            self.manual_controls[key] = 0.0

        # 发送紧急停止信号
        self.emergency_stop.emit()

    def _update_indicators(self):
        """更新指示器(当使用真实手柄时，此方法可能不需要)"""
        # 此方法在定时器触发时调用，用于模拟更新
        # 实际使用时，可通过update_joystick_data方法更新
        pass

    @pyqtSlot(dict)
    def update_joystick_data(self, joystick_data):

            """
            更新手柄数据

            Args:
                joystick_data: 手柄数据字典
            """
            axes = joystick_data.get("axes", {})
            buttons = joystick_data.get("buttons", {})

            # 更新状态标签
            status_text = "手柄数据已接收:\n"
            for name, value in axes.items():
                status_text += f"{name}: {value:.2f}\n"

            for name, pressed in buttons.items():
                if pressed:
                    status_text += f"{name}: 按下\n"

            self.joystick_status_label.setText(status_text)

            # 提取摇杆值
            lx = axes.get("LX", 0.0)
            ly = axes.get("LY", 0.0)
            rx = axes.get("RX", 0.0)
            ry = axes.get("RY", 0.0)

            # 更新虚拟摇杆位置
            if hasattr(self, 'left_joystick'):
                # 在这里添加更新虚拟摇杆位置的代码
                pass

            # 如果在手动模式下，更新控制值
            if self.current_control_mode == "manual":
                # 前进/后退控制 (左摇杆Y轴)
                self.manual_controls["forward"] = -ly
                self.forward_bar.setValue(int(-ly * 100))

                # 左右移动控制 (左摇杆X轴)
                self.manual_controls["lateral"] = lx
                self.lateral_bar.setValue(int(lx * 100))

                # 上浮/下潜控制 (LT和RT)
                vertical = (axes.get("RT", 0.0) - axes.get("LT", 0.0)) / 2.0
                self.manual_controls["vertical"] = vertical
                self.vertical_bar.setValue(int(vertical * 100))

                # 偏航控制 (右摇杆X轴)
                self.manual_controls["yaw"] = rx
                self.yaw_bar.setValue(int(rx * 100))

                # 发送控制更新信号
                self.manual_control_updated.emit(self.manual_controls.copy())