# ui/__init__.py
"""
UI模块初始化
"""