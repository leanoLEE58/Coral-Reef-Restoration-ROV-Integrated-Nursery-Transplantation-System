# modules/camera_manager.py
import cv2
import time
import threading
import numpy as np
from queue import Queue
import logging
import socket
from PyQt5.QtCore import QObject, pyqtSignal, QTimer


class CameraInfo:
    """摄像头信息类"""

    def __init__(self, id, name, is_usb=True, ip="", port=0):
        self.id = id  # 摄像头ID或索引
        self.name = name  # 摄像头名称
        self.is_usb = is_usb  # 是否为USB摄像头
        self.ip = ip  # 网络摄像头IP
        self.port = port  # 网络摄像头端口
        self.resolution = (640, 480)  # 默认分辨率
        self.fps = 30  # 默认帧率

    def __str__(self):
        if self.is_usb:
            return f"{self.name} (USB)"
        else:
            return f"{self.name} ({self.ip}:{self.port})"


class CameraManager(QObject):
    """摄像头管理器类"""
    # 定义信号
    frame_ready = pyqtSignal(np.ndarray)
    error_occurred = pyqtSignal(str)
    camera_connected = pyqtSignal(bool)
    camera_stats_updated = pyqtSignal(dict)

    def __init__(self, parent=None):
        """初始化摄像头管理器"""
        super().__init__(parent)
        self.logger = logging.getLogger("CameraManager")

        # 摄像头变量
        self.available_cameras = []  # 可用摄像头列表
        self.current_camera = None  # 当前选择的摄像头信息
        self.cap = None  # OpenCV摄像头捕获对象

        # 控制变量
        self.running = False  # 是否正在运行
        self.thread = None  # 捕获线程
        self.frame_queue = Queue(maxsize=5)  # 帧队列
        self.lock = threading.Lock()  # 线程锁

        # 统计信息
        self.stats = {
            "fps": 0,
            "frame_count": 0,
            "dropped_frames": 0,
            "resolution": (0, 0),
            "timestamp": 0
        }
        self.frame_count = 0
        self.start_time = time.time()

        # 最近一帧
        self.latest_frame = None

        # 初始化，扫描摄像头
        self.scan_cameras()

        # 启动统计更新定时器
        self.stats_timer = QTimer(self)
        self.stats_timer.timeout.connect(self._update_stats)
        self.stats_timer.start(1000)  # 每秒更新一次统计信息

    def scan_cameras(self):
        """扫描可用的USB摄像头"""
        self.logger.info("扫描可用摄像头...")
        self.available_cameras = []

        # 扫描USB摄像头
        for i in range(10):  # 尝试前10个摄像头索引
            cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)  # 使用DirectShow后端以加快检测速度
            if cap.isOpened():
                # 尝试读取一帧以确认摄像头可用
                ret, _ = cap.read()
                if ret:
                    # 获取摄像头信息
                    name = f"USB摄像头 #{i}"
                    camera = CameraInfo(i, name, is_usb=True)

                    # 获取分辨率和帧率
                    camera.resolution = (
                        int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                        int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                    )
                    camera.fps = int(cap.get(cv2.CAP_PROP_FPS))

                    self.available_cameras.append(camera)
                    self.logger.info(f"发现USB摄像头: {name}, 分辨率: {camera.resolution}")
                cap.release()

        # 添加默认IP摄像头选项（如果需要）
        ip_camera = CameraInfo(-1, "IP摄像头", is_usb=False, ip="192.168.1.100", port=8080)
        self.available_cameras.append(ip_camera)

        return self.available_cameras

    def connect_camera(self, camera_info=None):
        """
        连接到指定摄像头

        Args:
            camera_info: 摄像头信息对象，如果为None则使用第一个可用摄像头

        Returns:
            bool: 连接是否成功
        """
        # 如果正在运行，先停止
        if self.running:
            self.stop()

        # 如果没有指定摄像头，且有可用摄像头，使用第一个
        if camera_info is None and self.available_cameras:
            camera_info = self.available_cameras[0]
        elif camera_info is None:
            self.logger.error("没有可用摄像头")
            self.error_occurred.emit("没有可用摄像头")
            return False

        try:
            # 根据摄像头类型建立连接
            if camera_info.is_usb:
                # USB摄像头
                self.logger.info(f"连接到USB摄像头: {camera_info.name}")
                self.cap = cv2.VideoCapture(camera_info.id, cv2.CAP_DSHOW)
            else:
                # 网络摄像头
                self.logger.info(f"连接到网络摄像头: {camera_info.ip}:{camera_info.port}")
                # 构建RTSP或HTTP URL
                url = f"http://{camera_info.ip}:{camera_info.port}/video"
                # 也可以使用RTSP协议：f"rtsp://{camera_info.ip}:{camera_info.port}/live"
                self.cap = cv2.VideoCapture(url)

            # 检查连接是否成功
            if not self.cap.isOpened():
                self.logger.error(f"无法打开摄像头: {camera_info.name}")
                self.error_occurred.emit(f"无法打开摄像头: {camera_info.name}")
                return False

            # 设置分辨率和帧率
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, camera_info.resolution[0])
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, camera_info.resolution[1])
            self.cap.set(cv2.CAP_PROP_FPS, camera_info.fps)

            # 更新当前摄像头
            self.current_camera = camera_info

            # 读取一帧以确认设置成功
            ret, frame = self.cap.read()
            if not ret:
                self.logger.error("摄像头连接成功但无法读取帧")
                self.error_occurred.emit("摄像头连接成功但无法读取帧")
                self.cap.release()
                self.cap = None
                return False

            # 更新分辨率信息
            actual_width = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            actual_height = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            actual_fps = self.cap.get(cv2.CAP_PROP_FPS)

            self.logger.info(f"摄像头连接成功，分辨率: {actual_width}x{actual_height}, FPS: {actual_fps}")

            # 更新统计信息
            self.stats["resolution"] = (int(actual_width), int(actual_height))

            # 发送连接成功信号
            self.camera_connected.emit(True)

            return True

        except Exception as e:
            self.logger.error(f"连接摄像头时出错: {str(e)}")
            self.error_occurred.emit(f"连接摄像头时出错: {str(e)}")

            if self.cap:
                self.cap.release()
                self.cap = None

            return False

    def start(self):
        """启动摄像头捕获"""
        if self.running:
            return True

        if not self.cap or not self.cap.isOpened():
            self.logger.error("无法启动：摄像头未连接")
            self.error_occurred.emit("无法启动：摄像头未连接")
            return False

        # 重置统计信息
        self.frame_count = 0
        self.start_time = time.time()

        # 清空帧队列
        while not self.frame_queue.empty():
            self.frame_queue.get()

        # 启动捕获线程
        self.running = True
        self.thread = threading.Thread(target=self._capture_loop)
        self.thread.daemon = True
        self.thread.start()

        self.logger.info("摄像头捕获已启动")
        return True

    def stop(self):
        """停止摄像头捕获"""
        self.running = False

        if self.thread:
            self.thread.join(timeout=1.0)
            self.thread = None

        self.logger.info("摄像头捕获已停止")

    def disconnect(self):
        """断开摄像头连接"""
        self.stop()

        if self.cap:
            self.cap.release()
            self.cap = None

        self.camera_connected.emit(False)
        self.logger.info("摄像头已断开连接")

    def get_frame(self, wait=False):
        """
        获取一帧图像

        Args:
            wait: 是否等待新的一帧

        Returns:
            numpy.ndarray: 图像帧或None
        """
        if not self.running or not self.cap:
            return None

        try:
            if wait:
                frame = self.frame_queue.get(timeout=1.0)
            else:
                if self.frame_queue.empty():
                    with self.lock:
                        return self.latest_frame.copy() if self.latest_frame is not None else None
                frame = self.frame_queue.get_nowait()

            return frame
        except Exception as e:
            self.logger.error(f"获取帧时出错: {str(e)}")
            return None

    def _capture_loop(self):
        """摄像头捕获循环"""
        while self.running and self.cap and self.cap.isOpened():
            try:
                # 读取一帧
                ret, frame = self.cap.read()

                if not ret:
                    self.logger.warning("帧读取失败")
                    time.sleep(0.01)  # 短暂延迟避免CPU占用过高
                    continue

                # 更新帧计数和统计信息
                self.frame_count += 1

                # 保存最新帧
                with self.lock:
                    self.latest_frame = frame.copy()

                # 如果队列已满，丢弃最旧的帧
                if self.frame_queue.full():
                    try:
                        self.frame_queue.get_nowait()
                        self.stats["dropped_frames"] += 1
                    except:
                        pass

                # 将帧放入队列
                self.frame_queue.put(frame)

                # 发送帧就绪信号
                self.frame_ready.emit(frame)

            except Exception as e:
                self.logger.error(f"捕获循环错误: {str(e)}")
                time.sleep(0.1)  # 错误后短暂延迟

    def _update_stats(self):
        """更新统计信息"""
        if not self.running or not self.cap:
            return

        # 计算FPS
        elapsed = time.time() - self.start_time
        if elapsed > 0:
            fps = self.frame_count / elapsed
            self.stats["fps"] = fps

            # 重置计数器（每秒重置一次）
            self.frame_count = 0
            self.start_time = time.time()

        # 更新时间戳
        self.stats["timestamp"] = time.time()

        # 发送统计信息更新信号
        self.camera_stats_updated.emit(self.stats)

    def get_camera_properties(self):
        """获取当前摄像头属性"""
        if not self.cap or not self.cap.isOpened():
            return {}

        properties = {
            "width": int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
            "height": int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
            "fps": self.cap.get(cv2.CAP_PROP_FPS),
            "brightness": self.cap.get(cv2.CAP_PROP_BRIGHTNESS),
            "contrast": self.cap.get(cv2.CAP_PROP_CONTRAST),
            "saturation": self.cap.get(cv2.CAP_PROP_SATURATION),
            "hue": self.cap.get(cv2.CAP_PROP_HUE),
            "gain": self.cap.get(cv2.CAP_PROP_GAIN),
            "exposure": self.cap.get(cv2.CAP_PROP_EXPOSURE)
        }

        return properties

    def set_camera_property(self, property_name, value):
        """
        设置摄像头属性

        Args:
            property_name: 属性名称 (brightness, contrast, etc.)
            value: 属性值

        Returns:
            bool: 是否设置成功
        """
        if not self.cap or not self.cap.isOpened():
            return False

        property_map = {
            "brightness": cv2.CAP_PROP_BRIGHTNESS,
            "contrast": cv2.CAP_PROP_CONTRAST,
            "saturation": cv2.CAP_PROP_SATURATION,
            "hue": cv2.CAP_PROP_HUE,
            "gain": cv2.CAP_PROP_GAIN,
            "exposure": cv2.CAP_PROP_EXPOSURE,
            "width": cv2.CAP_PROP_FRAME_WIDTH,
            "height": cv2.CAP_PROP_FRAME_HEIGHT,
            "fps": cv2.CAP_PROP_FPS
        }

        if property_name not in property_map:
            self.logger.error(f"未知的摄像头属性: {property_name}")
            return False

        return self.cap.set(property_map[property_name], value)

    def set_resolution(self, width, height):
        """
        设置摄像头分辨率

        Args:
            width: 宽度
            height: 高度

        Returns:
            bool: 是否设置成功
        """
        if not self.cap or not self.cap.isOpened():
            return False

        # 设置分辨率
        width_success = self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        height_success = self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

        # 更新分辨率信息
        if width_success and height_success:
            actual_width = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            actual_height = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            self.stats["resolution"] = (int(actual_width), int(actual_height))

            if self.current_camera:
                self.current_camera.resolution = (int(actual_width), int(actual_height))

            self.logger.info(f"分辨率已设置为: {actual_width}x{actual_height}")
            return True
        else:
            self.logger.error(f"设置分辨率失败")
            return False