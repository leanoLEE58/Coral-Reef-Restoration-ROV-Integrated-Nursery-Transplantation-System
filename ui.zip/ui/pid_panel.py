# ui/pid_panel.py
"""
PID参数调节面板
"""
from PyQt5.QtWidgets import (QWidget, QLabel, QGridLayout, QDoubleSpinBox,
                             QPushButton, QComboBox, QGroupBox, QVBoxLayout, QHBoxLayout)
from PyQt5.QtCore import pyqtSignal

import config


class PIDPanel(QWidget):
    """PID参数调节面板"""
    # 定义信号
    pid_params_changed = pyqtSignal(str, float, float, float, float)

    def __init__(self, parent=None):
        """
        初始化PID参数面板

        Args:
            parent: 父组件
        """
        super().__init__(parent)
        self.controllers = ["depth", "heading", "pitch"]
        self.spinboxes = {}

        # 初始化UI
        self._init_ui()

        # 加载默认PID参数
        self._load_default_params()

    def _init_ui(self):
        """初始化UI"""
        # 主布局
        main_layout = QVBoxLayout(self)

        # 控制器选择
        controller_layout = QHBoxLayout()
        controller_layout.addWidget(QLabel("控制器:"))
        self.controller_combo = QComboBox()
        self.controller_combo.addItems(["深度控制", "航向控制", "俯仰控制"])
        self.controller_combo.currentIndexChanged.connect(self._on_controller_changed)
        controller_layout.addWidget(self.controller_combo)
        main_layout.addLayout(controller_layout)

        # PID参数组
        pid_group = QGroupBox("PID 参数")
        grid_layout = QGridLayout(pid_group)

        # 标签
        grid_layout.addWidget(QLabel("参数"), 0, 0)
        grid_layout.addWidget(QLabel("数值"), 0, 1)

        # Kp - 比例系数
        grid_layout.addWidget(QLabel("Kp (比例系数):"), 1, 0)
        self.spinboxes["kp"] = QDoubleSpinBox()
        self.spinboxes["kp"].setRange(0.0, 100.0)
        self.spinboxes["kp"].setSingleStep(0.1)
        self.spinboxes["kp"].setDecimals(3)
        grid_layout.addWidget(self.spinboxes["kp"], 1, 1)

        # Ki - 积分系数
        grid_layout.addWidget(QLabel("Ki (积分系数):"), 2, 0)
        self.spinboxes["ki"] = QDoubleSpinBox()
        self.spinboxes["ki"].setRange(0.0, 100.0)
        self.spinboxes["ki"].setSingleStep(0.01)
        self.spinboxes["ki"].setDecimals(3)
        grid_layout.addWidget(self.spinboxes["ki"], 2, 1)

        # Kd - 微分系数
        grid_layout.addWidget(QLabel("Kd (微分系数):"), 3, 0)
        self.spinboxes["kd"] = QDoubleSpinBox()
        self.spinboxes["kd"].setRange(0.0, 100.0)
        self.spinboxes["kd"].setSingleStep(0.01)
        self.spinboxes["kd"].setDecimals(3)
        grid_layout.addWidget(self.spinboxes["kd"], 3, 1)

        # 目标值
        grid_layout.addWidget(QLabel("目标值:"), 4, 0)
        self.spinboxes["target"] = QDoubleSpinBox()
        self.spinboxes["target"].setRange(-100.0, 100.0)
        self.spinboxes["target"].setSingleStep(0.1)
        self.spinboxes["target"].setDecimals(2)
        grid_layout.addWidget(self.spinboxes["target"], 4, 1)

        main_layout.addWidget(pid_group)

        # 按钮布局
        button_layout = QHBoxLayout()

        # 应用按钮
        self.apply_btn = QPushButton("应用参数")
        self.apply_btn.clicked.connect(self._on_apply_clicked)
        button_layout.addWidget(self.apply_btn)

        # 重置按钮
        self.reset_btn = QPushButton("重置为默认")
        self.reset_btn.clicked.connect(self._on_reset_clicked)
        button_layout.addWidget(self.reset_btn)

        main_layout.addLayout(button_layout)
        main_layout.addStretch()

        # 连接参数变更信号
        for param, spinbox in self.spinboxes.items():
            spinbox.valueChanged.connect(lambda: self._on_param_changed())

        # 设置样式
        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #3498db;
                border-radius: 5px;
                margin-top: 1ex;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 3px;
            }
            QPushButton {
                background-color: #2c3e50;
                color: white;
                border: none;
                padding: 5px 10px;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #34495e;
            }
            QLabel {
                color: #ecf0f1;
            }
            QSpinBox, QDoubleSpinBox {
                background-color: #34495e;
                color: white;
                border: 1px solid #3498db;
                border-radius: 3px;
            }
        """)

    def _on_controller_changed(self, index):
        """
        控制器选择改变时的处理

        Args:
            index: 下拉框索引
        """
        controller = self.controllers[index]
        self._load_controller_params(controller)

    def _on_apply_clicked(self):
        """应用按钮点击处理"""
        index = self.controller_combo.currentIndex()
        controller = self.controllers[index]

        # 获取参数值
        kp = self.spinboxes["kp"].value()
        ki = self.spinboxes["ki"].value()
        kd = self.spinboxes["kd"].value()
        target = self.spinboxes["target"].value()

        # 发送参数变更信号
        self.pid_params_changed.emit(controller, kp, ki, kd, target)

    def _on_reset_clicked(self):
        """重置按钮点击处理"""
        index = self.controller_combo.currentIndex()
        controller = self.controllers[index]

        # 从配置中加载默认参数
        params = config.PID_DEFAULTS.get(controller, {})

        # 设置默认值
        self.spinboxes["kp"].setValue(params.get("kp", 0.0))
        self.spinboxes["ki"].setValue(params.get("ki", 0.0))
        self.spinboxes["kd"].setValue(params.get("kd", 0.0))
        self.spinboxes["target"].setValue(params.get("target", 0.0))

    def _on_param_changed(self):
        """参数值改变处理"""
        # 可以在这里处理参数变化事件
        pass

    def _load_default_params(self):
        """加载默认参数"""
        # 默认选择第一个控制器
        self.controller_combo.setCurrentIndex(0)
        self._load_controller_params(self.controllers[0])

    def _load_controller_params(self, controller):
        """
        加载指定控制器的参数

        Args:
            controller: 控制器名称
        """
        params = config.PID_DEFAULTS.get(controller, {})

        # 设置默认值
        self.spinboxes["kp"].setValue(params.get("kp", 0.0))
        self.spinboxes["ki"].setValue(params.get("ki", 0.0))
        self.spinboxes["kd"].setValue(params.get("kd", 0.0))
        self.spinboxes["target"].setValue(params.get("target", 0.0))

    def set_params(self, controller, params):
        """
        设置控制器参数

        Args:
            controller: 控制器名称
            params: 参数字典
        """
        if controller in self.controllers:
            # 选择对应的控制器
            index = self.controllers.index(controller)
            self.controller_combo.setCurrentIndex(index)

            # 设置参数值
            if "kp" in params:
                self.spinboxes["kp"].setValue(params["kp"])
            if "ki" in params:
                self.spinboxes["ki"].setValue(params["ki"])
            if "kd" in params:
                self.spinboxes["kd"].setValue(params["kd"])
            if "target" in params:
                self.spinboxes["target"].setValue(params["target"])