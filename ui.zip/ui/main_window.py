# ui/main_window.py
"""
主窗口
"""
import cv2
from PyQt5.QtWidgets import (QMainWindow, QWidget, QDockWidget, QAction, QToolBar,
                             QStatusBar, QMessageBox, QVBoxLayout, QHBoxLayout, QLabel, QDialog, QComboBox,
                             QLineEdit, QDialogButtonBox, QFormLayout, QSlider,
                             QToolButton, QMenu)
from PyQt5.QtCore import Qt, QTimer

import pygame
import qdarkstyle
import config

from video_widget import VideoWidget
from pid_panel import PIDPanel
from video_stream import VideoStreamThread, VideoProcessor
from joystick import JoystickController
from communication import CommunicationManager
from robot_controller import RobotController
from chart_widget import RealtimeChartWidget
from model3d_widget import Model3DControlWidget
from advanced_control_panel import AdvancedControlPanel
from status_indicators import StatusIndicatorsPanel
from arm_control_widget import AdvancedArmControlPanel
from OpenGL.GLUT import *
import sys
# 导入摄像头选择对话框
from camera_dialog import CameraDialog



class MainWindow(QMainWindow):
    """主窗口类"""

    def __init__(self):
        """初始化主窗口"""
        super().__init__()

        # 初始化状态变量
        self.running = False

        # 初始化模块
        self._init_modules()

        # 初始化UI
        self._init_ui()

        # 连接信号
        self._connect_signals()

        # 启动模块
        self._start_modules()

       ## self.init_vision_force_system()



    def _init_modules(self):
        """初始化功能模块"""
        # 视频流处理
        self.video_thread = VideoStreamThread()

        # 手柄控制
        self.joystick = JoystickController()

        # 通信管理
        self.comm = CommunicationManager()

        # 机器人控制
        self.robot = RobotController(self.comm)

    def _init_ui(self):
        """初始化UI"""
        # 窗口基本设置
        self.setWindowTitle(f"{config.ROBOT_NAME} - 控制系统")
        self.setMinimumSize(1200, 800)

        # 中央部件
        central_widget = QWidget()
        main_layout = QVBoxLayout(central_widget)

        # 视频显示组件
        self.video_widget = VideoWidget()
        main_layout.addWidget(self.video_widget, 1)

        self.setCentralWidget(central_widget)

        # 创建停靠组件
        self._create_docks()

        # 创建菜单
        self._create_menus()

        # 创建工具栏
        self._create_toolbar()

        # 创建状态栏
        self._create_status_bar()

        # 加载样式
        if config.UI_THEME == "dark":
            self.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())

    def _create_docks(self):
        """创建停靠组件"""
        # 高级控制面板(左侧停靠)
        self.control_dock = QDockWidget("控制面板", self)
        self.control_dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.control_panel = AdvancedControlPanel()
        self.control_dock.setWidget(self.control_panel)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.control_dock)

        # 状态面板(右侧停靠)
        self.status_dock = QDockWidget("状态监控", self)
        self.status_dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.status_panel = StatusIndicatorsPanel()
        self.status_dock.setWidget(self.status_panel)
        self.addDockWidget(Qt.RightDockWidgetArea, self.status_dock)

        # 3D模型面板(右侧停靠)
        self.model3d_dock = QDockWidget("3D姿态", self)
        self.model3d_dock.setAllowedAreas(Qt.RightDockWidgetArea | Qt.BottomDockWidgetArea)
        self.model3d_panel = Model3DControlWidget()
        self.model3d_dock.setWidget(self.model3d_panel)
        self.addDockWidget(Qt.RightDockWidgetArea, self.model3d_dock)

        # 实时图表面板(底部停靠)
        self.chart_dock = QDockWidget("实时数据", self)
        self.chart_dock.setAllowedAreas(Qt.BottomDockWidgetArea | Qt.TopDockWidgetArea)
        self.chart_panel = RealtimeChartWidget("深度趋势")
        self.chart_dock.setWidget(self.chart_panel)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.chart_dock)

        # PID面板(底部停靠)
        self.pid_dock = QDockWidget("PID参数调节", self)
        self.pid_dock.setAllowedAreas(Qt.BottomDockWidgetArea | Qt.TopDockWidgetArea)
        self.pid_panel = PIDPanel()
        self.pid_dock.setWidget(self.pid_panel)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.pid_dock)

        # 机械臂控制面板
        self.arm_dock = QDockWidget("机械臂控制", self)
        self.arm_dock.setAllowedAreas(Qt.AllDockWidgetAreas)
        self.arm_control_panel = AdvancedArmControlPanel()
        self.arm_dock.setWidget(self.arm_control_panel)
        self.addDockWidget(Qt.RightDockWidgetArea, self.arm_dock)

        # 连接信号
        self.arm_control_panel.jointAngleChanged.connect(self._on_joint_angle_changed)
        self.arm_control_panel.visionParamsChanged.connect(self._on_vision_params_changed)
        self.arm_control_panel.emergencyStop.connect(self._on_arm_emergency_stop)

        # 调整面板大小比例
        self.splitDockWidget(self.chart_dock, self.pid_dock, Qt.Horizontal)

    def _create_menus(self):
        # 文件菜单
        file_menu = self.menuBar().addMenu("文件")

        connect_action = QAction("连接设备", self)
        connect_action.triggered.connect(self._on_connect)
        file_menu.addAction(connect_action)

        disconnect_action = QAction("断开连接", self)
        disconnect_action.triggered.connect(self._on_disconnect)
        file_menu.addAction(disconnect_action)

        file_menu.addSeparator()

        # 摄像头菜单
        camera_menu = file_menu.addMenu("摄像头")

        select_camera_action = QAction("选择摄像头", self)
        select_camera_action.triggered.connect(self._on_select_camera)
        camera_menu.addAction(select_camera_action)

        camera_settings_action = QAction("摄像头设置", self)
        camera_settings_action.triggered.connect(self._on_camera_settings)
        camera_menu.addAction(camera_settings_action)

        camera_info_action = QAction("摄像头信息", self)
        camera_info_action.triggered.connect(self._on_camera_info)
        camera_menu.addAction(camera_info_action)

        file_menu.addSeparator()

        # 手柄菜单
        joystick_menu = file_menu.addMenu("手柄")

        detect_joystick_action = QAction("检测手柄", self)
        detect_joystick_action.triggered.connect(self._detect_joystick)
        joystick_menu.addAction(detect_joystick_action)

        file_menu.addSeparator()

        exit_action = QAction("退出", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # 视图菜单
        view_menu = self.menuBar().addMenu("视图")

        view_menu.addAction(self.control_dock.toggleViewAction())
        view_menu.addAction(self.status_dock.toggleViewAction())
        view_menu.addAction(self.pid_dock.toggleViewAction())

        # 控制菜单
        control_menu = self.menuBar().addMenu("控制")

        emergency_stop_action = QAction("紧急停止", self)
        emergency_stop_action.triggered.connect(self._on_emergency_stop)
        control_menu.addAction(emergency_stop_action)

        # 帮助菜单
        help_menu = self.menuBar().addMenu("帮助")

        about_action = QAction("关于", self)
        about_action.triggered.connect(self._on_about)
        help_menu.addAction(about_action)

    # 在主窗口中
    def setup_joystick_connection(self):
        # 将手柄数据连接到UI更新
        self.joystick_manager.joystick_data.connect(self.control_panel.update_joystick_data)

        # 处理手柄连接/断开
        self.joystick_manager.joystick_connected.connect(
            lambda joy_id, name: self.control_panel.set_joystick_connected(True, name))
        self.joystick_manager.joystick_disconnected.connect(
            lambda _: self.control_panel.set_joystick_connected(False))

        # 控制面板模式变化通知手柄管理器
        self.control_panel.control_mode_changed.connect(self.joystick_manager.change_mode)

    def _create_toolbar(self):
        """创建工具栏"""
        # 主工具栏
        main_toolbar = QToolBar("主工具栏", self)
        main_toolbar.setMovable(False)
        self.addToolBar(main_toolbar)

        # 连接按钮
        connect_action = QAction("连接", self)
        connect_action.triggered.connect(self._on_connect)
        main_toolbar.addAction(connect_action)

        # 断开按钮
        disconnect_action = QAction("断开", self)
        disconnect_action.triggered.connect(self._on_disconnect)
        main_toolbar.addAction(disconnect_action)

        main_toolbar.addSeparator()

        # 摄像头控制
        camera_menu = QMenu("摄像头", self)
        select_camera_action = QAction("选择摄像头", self)
        select_camera_action.triggered.connect(self._select_camera)
        camera_menu.addAction(select_camera_action)

        # 摄像头按钮
        select_camera_action = QAction("选择摄像头", self)
        select_camera_action.triggered.connect(self._on_select_camera)
        main_toolbar.addAction(select_camera_action)

        camera_info_action = QAction("摄像头信息", self)
        camera_info_action.triggered.connect(self._show_camera_info)
        camera_menu.addAction(camera_info_action)

        camera_button = QToolButton(self)
        camera_button.setText("摄像头")
        camera_button.setMenu(camera_menu)
        camera_button.setPopupMode(QToolButton.InstantPopup)
        main_toolbar.addWidget(camera_button)

        # 手柄检测按钮
        detect_joystick_action = QAction("检测手柄", self)
        detect_joystick_action.triggered.connect(self._detect_joystick)
        main_toolbar.addAction(detect_joystick_action)

        main_toolbar.addSeparator()

        # 紧急停止按钮
        stop_action = QAction("紧急停止", self)
        stop_action.triggered.connect(self._on_emergency_stop)
        main_toolbar.addAction(stop_action)

    def _create_status_bar(self):
        """创建状态栏"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        # 连接状态标签
        self.conn_status_label = QLabel("未连接")
        self.conn_status_label.setStyleSheet("color: #e74c3c;")
        self.status_bar.addWidget(self.conn_status_label)

        # 摄像头状态标签
        self.camera_status_label = QLabel("摄像头: 未连接")
        self.camera_status_label.setStyleSheet("color: #e74c3c;")
        self.status_bar.addWidget(self.camera_status_label)

        # 错误信息标签
        self.error_label = QLabel("")
        self.status_bar.addWidget(self.error_label, 1)

        # 手柄状态标签
        self.joystick_status_label = QLabel("手柄: 未检测")
        self.joystick_status_label.setStyleSheet("color: #e74c3c;")
        self.status_bar.addPermanentWidget(self.joystick_status_label)

    def _connect_signals(self):
        """连接信号"""
        # 视频流信号
        self.video_thread.frame_ready.connect(self.video_widget.update_image)
        self.video_thread.error.connect(self._on_error)

        # 手柄信号
        self.joystick.joystick_data.connect(self.control_panel.update_joystick_data)
        self.joystick.error.connect(self._on_error)

        # 通信信号
        self.comm.connection_status.connect(self._on_connection_status_changed)
        self.comm.error.connect(self._on_error)

        # 机器人控制信号
        self.robot.status_updated.connect(self.status_panel.update_status)
        self.robot.error.connect(self._on_error)

        # 控制面板信号
        self.control_panel.control_mode_changed.connect(self.robot.set_control_mode)
        self.control_panel.manual_control_updated.connect(self.robot.set_manual_control)
        self.control_panel.emergency_stop.connect(self._on_emergency_stop)

        # PID面板信号
        self.pid_panel.pid_params_changed.connect(self.robot.set_pid_parameters)

    def _start_modules(self):
        """启动功能模块"""
        # 启动视频流
        self.video_thread.start()

        # 设置帧处理器
        def process_frame(frame):
            # 应用选中的滤镜
            filter_name = self.video_widget.get_selected_filter()
            if filter_name:
                frame = VideoProcessor.apply_filters(frame, [filter_name])
            return frame

        self.video_thread.set_frame_processor(process_frame)

        # 启动手柄控制
        self.joystick.start()

        # 标记正在运行
        self.running = True

    def _on_connect(self):
        """连接设备处理"""
        if not self.comm.is_connected():
            # 尝试连接
            if self.comm.connect():
                # 如果连接成功，启动机器人控制
                self.robot.start()
            else:
                QMessageBox.warning(self, "连接失败", "无法连接到机器人。请检查连接设置。")

    def _on_disconnect(self):
        """断开连接处理"""
        if self.comm.is_connected():
            # 停止机器人控制
            self.robot.stop()

            # 断开连接
            self.comm.disconnect()

    def _on_emergency_stop(self):
        """紧急停止处理"""
        # 执行紧急停止
        self.robot.emergency_stop()

    def _on_about(self):
        """关于对话框"""
        QMessageBox.about(self, "关于",
                          f"<h3>{config.ROBOT_NAME} 控制系统</h3>"
                          "<p>水下机器人上位机控制软件</p>"
                          "<p>版本: 1.0</p>")

    def _on_error(self, error_msg):
        """
        错误处理

        Args:
            error_msg: 错误信息
        """
        # 显示错误信息
        self.error_label.setText(error_msg)
        self.error_label.setStyleSheet("color: #e74c3c;")

        # 3秒后清除错误信息
        QTimer.singleShot(3000, self._clear_error)

    def _clear_error(self):
        """清除错误信息"""
        self.error_label.setText("")
        self.error_label.setStyleSheet("")

    def _on_connection_status_changed(self, connected):
        """
        连接状态变更处理

        Args:
            connected: 是否已连接
        """
        # 更新状态栏
        if connected:
            self.conn_status_label.setText("已连接")
            self.conn_status_label.setStyleSheet("color: #2ecc71;")
        else:
            self.conn_status_label.setText("未连接")
            self.conn_status_label.setStyleSheet("color: #e74c3c;")

        # 更新状态面板
        self.status_panel.update_connection_status(connected)

    def _detect_joystick(self):
        """检测手柄设备"""
        self.joystick.debug_joystick_info()

        # 显示检测结果到状态栏
        joystick_count = pygame.joystick.get_count()
        if joystick_count > 0:
            self.joystick_status_label.setText(f"手柄: 已检测 ({joystick_count}个)")
            self.joystick_status_label.setStyleSheet("color: #2ecc71;")
            QMessageBox.information(self, "手柄检测", f"检测到{joystick_count}个手柄设备。详细信息已打印到控制台。")
        else:
            self.joystick_status_label.setText("手柄: 未检测")
            self.joystick_status_label.setStyleSheet("color: #e74c3c;")
            QMessageBox.warning(self, "手柄检测", "未检测到手柄设备。请检查连接并重试。")

    def _select_camera(self):
        """选择摄像头"""
        # 获取可用摄像头
        available_cameras = self._list_available_cameras()

        if not available_cameras and available_cameras != []:
            QMessageBox.warning(self, "摄像头选择", "未检测到摄像头设备！")
            return

        # 创建选择对话框
        camera_dialog = QDialog(self)
        camera_dialog.setWindowTitle("选择摄像头")
        layout = QVBoxLayout(camera_dialog)

        # 添加摄像头选择列表
        camera_combo = QComboBox()
        for idx in available_cameras:
            camera_combo.addItem(f"摄像头 #{idx}", idx)

        # 添加IP摄像头选项
        camera_combo.addItem("IP摄像头 (RTSP/HTTP流)", "ip")
        layout.addWidget(camera_combo)

        # 添加IP摄像头输入框
        ip_input = QLineEdit()
        ip_input.setPlaceholderText("rtsp://用户名:密码@IP地址:端口/stream")
        ip_input.setVisible(False)
        layout.addWidget(ip_input)

        # 连接选择变化事件
        def on_selection_changed(index):
            ip_input.setVisible(camera_combo.currentData() == "ip")

        camera_combo.currentIndexChanged.connect(on_selection_changed)

        # 添加按钮
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(camera_dialog.accept)
        button_box.rejected.connect(camera_dialog.reject)
        layout.addWidget(button_box)

        # 显示对话框
        if camera_dialog.exec_() == QDialog.Accepted:
            # 停止当前视频流
            self.video_thread.stop()

            # 获取选择的摄像头
            selected = camera_combo.currentData()
            if selected == "ip":
                rtsp_url = ip_input.text().strip()
                if rtsp_url:
                    # 设置IP摄像头
                    self.video_thread = VideoStreamThread(rtsp_url)
                    # 更新状态栏
                    self.camera_status_label.setText(f"摄像头: IP流")
                    self.camera_status_label.setStyleSheet("color: #2ecc71;")
                else:
                    QMessageBox.warning(self, "错误", "请输入有效的RTSP URL!")
                    # 重新启动原来的视频流
                    self.video_thread.start()
                    return
            else:
                # 设置USB摄像头
                self.video_thread = VideoStreamThread(selected)
                # 更新状态栏
                self.camera_status_label.setText(f"摄像头: #{selected}")
                self.camera_status_label.setStyleSheet("color: #2ecc71;")

            # 重新连接信号
            self.video_thread.frame_ready.connect(self.video_widget.update_image)
            self.video_thread.error.connect(self._on_error)

            # 启动新视频流
            self.video_thread.start()

    def _list_available_cameras(self):
        """列出可用的摄像头"""
        available_cameras = []
        for i in range(10):  # 尝试10个索引
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                ret, frame = cap.read()
                if ret:
                    available_cameras.append(i)
                cap.release()
        return available_cameras

    def _show_camera_info(self):
        """显示摄像头信息"""
        if not hasattr(self.video_thread, 'cap') or not self.video_thread.cap or not self.video_thread.cap.isOpened():
            QMessageBox.warning(self, "摄像头信息", "摄像头未连接或未正确初始化")
            return

        # 获取摄像头信息
        width = self.video_thread.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
        height = self.video_thread.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
        fps = self.video_thread.cap.get(cv2.CAP_PROP_FPS)

        info_text = f"""
        状态: 已连接
        分辨率: {int(width)}x{int(height)}
        帧率: {fps:.1f}
        """

        QMessageBox.information(self, "摄像头信息", info_text)

    def _configure_camera(self):
        """配置摄像头参数"""
        if not hasattr(self.video_thread, 'cap') or not self.video_thread.cap or not self.video_thread.cap.isOpened():
            QMessageBox.warning(self, "错误", "摄像头未连接！")
            return

        # 创建配置对话框
        dialog = QDialog(self)
        dialog.setWindowTitle("摄像头设置")
        layout = QVBoxLayout(dialog)

        # 创建参数调整控件
        form_layout = QFormLayout()

        # 分辨率选择
        resolution_combo = QComboBox()
        common_resolutions = [
            "640x480", "800x600", "1280x720", "1920x1080"
        ]
        for res in common_resolutions:
            resolution_combo.addItem(res)

        # 当前分辨率
        width = int(self.video_thread.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(self.video_thread.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        current_res = f"{width}x{height}"

        # 如果当前分辨率不在列表中，添加它
        if current_res not in common_resolutions:
            resolution_combo.addItem(current_res)

        # 设置当前值
        resolution_combo.setCurrentText(current_res)
        form_layout.addRow("分辨率:", resolution_combo)

        # 帧率调整
        fps_slider = QSlider(Qt.Horizontal)
        fps_slider.setRange(1, 60)
        fps_slider.setValue(int(self.video_thread.cap.get(cv2.CAP_PROP_FPS)))
        fps_label = QLabel(f"{fps_slider.value()} FPS")
        fps_slider.valueChanged.connect(lambda v: fps_label.setText(f"{v} FPS"))

        fps_layout = QHBoxLayout()
        fps_layout.addWidget(fps_slider)
        fps_layout.addWidget(fps_label)
        form_layout.addRow("帧率:", fps_layout)

        # 亮度调整
        brightness_slider = QSlider(Qt.Horizontal)
        brightness_slider.setRange(-100, 100)
        brightness_slider.setValue(0)
        brightness_label = QLabel("0")
        brightness_slider.valueChanged.connect(lambda v: brightness_label.setText(str(v)))

        brightness_layout = QHBoxLayout()
        brightness_layout.addWidget(brightness_slider)
        brightness_layout.addWidget(brightness_label)
        form_layout.addRow("亮度:", brightness_layout)

        # 对比度调整
        contrast_slider = QSlider(Qt.Horizontal)
        contrast_slider.setRange(-100, 100)
        contrast_slider.setValue(0)
        contrast_label = QLabel("0")
        contrast_slider.valueChanged.connect(lambda v: contrast_label.setText(str(v)))

        contrast_layout = QHBoxLayout()
        contrast_layout.addWidget(contrast_slider)
        contrast_layout.addWidget(contrast_label)
        form_layout.addRow("对比度:", contrast_layout)

        layout.addLayout(form_layout)

        # 按钮
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        # 显示对话框
        if dialog.exec_() == QDialog.Accepted:
            # 应用设置
            try:
                # 设置分辨率
                res = resolution_combo.currentText().split('x')
                new_width = int(res[0])
                new_height = int(res[1])
                self.video_thread.cap.set(cv2.CAP_PROP_FRAME_WIDTH, new_width)
                self.video_thread.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, new_height)

                # 设置帧率
                self.video_thread.cap.set(cv2.CAP_PROP_FPS, fps_slider.value())

                # 注意：亮度和对比度通常需要在帧处理阶段应用
                # 将亮度和对比度值保存起来
                self.video_widget.brightness_adjustment = brightness_slider.value() / 100.0
                self.video_widget.contrast_adjustment = 1.0 + contrast_slider.value() / 100.0

                # 更新状态栏
                self.status_bar.showMessage(f"已更新摄像头设置: {new_width}x{new_height}, {fps_slider.value()} FPS",
                                            3000)
            except Exception as e:
                QMessageBox.warning(self, "设置错误", f"应用摄像头设置时出错: {str(e)}")

    def closeEvent(self, event):
        """
        窗口关闭事件处理

        Args:
            event: 事件对象
        """
        if self.running:
            # 停止所有模块
            self.running = False

            # 停止视频流
            self.video_thread.stop()

            # 停止手柄控制
            self.joystick.stop()

            # 停止机器人控制
            self.robot.stop()

            # 断开连接
            self.comm.disconnect()

        # 接受关闭事件
        event.accept()

    # 添加处理方法
    def _on_joint_angle_changed(self, joint_idx, angle):
        """处理关节角度变化"""
        # 向机器人发送关节控制命令
        print(f"关节 {joint_idx + 1} 角度变更为 {angle:.1f}°")

        if self.comm.is_connected():
            command = {
                "type": "joint_control",
                "joint": joint_idx,
                "angle": angle
            }
            self.comm.send_data(command)

    def _on_vision_params_changed(self, params):
        """处理视觉参数变化"""
        print(f"视觉参数已更新: {params}")

        if self.comm.is_connected():
            command = {
                "type": "vision_params",
                "params": params
            }
            self.comm.send_data(command)

    def _on_arm_emergency_stop(self):
        """处理机械臂紧急停止"""
        print("机械臂紧急停止")

        if self.comm.is_connected():
            command = {
                "type": "arm_emergency_stop"
            }
            self.comm.send_data(command)

    # 在视频帧接收处理中添加向机械臂控制面板传送视频帧的代码
    def _on_frame_received(self, frame):
        # 正常的视频处理...

        # 将视频帧传送到机械臂控制面板用于视觉处理
        if hasattr(self, 'arm_control_panel'):
            self.arm_control_panel.set_camera_frame(frame)

    # 添加摄像头选择方法
    def _on_select_camera(self):
        """打开摄像头选择对话框"""
        # 创建摄像头管理器
        from camera_manager import CameraManager
        camera_manager = CameraManager()

        # 创建并显示摄像头选择对话框
        dialog = CameraDialog(camera_manager, self)
        dialog.camera_selected.connect(self._on_camera_selected)
        dialog.exec_()

    # 添加摄像头选择回调方法
    def _on_camera_selected(self, camera_info):
        """
        处理摄像头选择

        Args:
            camera_info: 选择的摄像头信息
        """
        # 停止当前视频流
        if hasattr(self, 'video_thread') and self.video_thread is not None:
            self.video_thread.stop()

        # 创建新的视频流线程
        self.video_thread = VideoStreamThread(camera_info)

        # 连接信号
        self.video_thread.frame_ready.connect(self.video_widget.update_image)
        self.video_thread.error.connect(self._on_error)

        # 设置帧处理器
        def process_frame(frame):
            # 应用选中的滤镜
            filter_name = self.video_widget.get_selected_filter()
            if filter_name:
                frame = VideoProcessor.apply_filters(frame, [filter_name])
            return frame

        self.video_thread.set_frame_processor(process_frame)

        # 启动视频流
        self.video_thread.start()

        # 更新状态栏
        self.status_bar.showMessage(f"已连接到摄像头: {camera_info.name}")

    # 添加摄像头设置方法
    def _on_camera_settings(self):
        """打开摄像头设置对话框"""
        # 检查视频流是否运行
        if not hasattr(self, 'video_thread') or self.video_thread is None or not self.video_thread.isRunning():
            QMessageBox.warning(self, "错误", "请先选择并启动摄像头")
            return

        # 获取摄像头属性
        props = self.video_thread.get_camera_properties()
        if not props:
            QMessageBox.warning(self, "错误", "无法获取摄像头属性")
            return

        # 创建设置对话框
        dialog = QDialog(self)
        dialog.setWindowTitle("摄像头设置")
        layout = QVBoxLayout(dialog)

        # 添加设置控件
        form_layout = QFormLayout()

        # 亮度
        if "brightness" in props:
            brightness_slider = QSlider(Qt.Horizontal)
            brightness_slider.setRange(-100, 100)
            brightness_slider.setValue(int(props["brightness"]))
            form_layout.addRow("亮度:", brightness_slider)

        # 对比度
        if "contrast" in props:
            contrast_slider = QSlider(Qt.Horizontal)
            contrast_slider.setRange(-100, 100)
            contrast_slider.setValue(int(props["contrast"]))
            form_layout.addRow("对比度:", contrast_slider)

        # 饱和度
        if "saturation" in props:
            saturation_slider = QSlider(Qt.Horizontal)
            saturation_slider.setRange(-100, 100)
            saturation_slider.setValue(int(props["saturation"]))
            form_layout.addRow("饱和度:", saturation_slider)

        # 曝光
        if "exposure" in props:
            exposure_slider = QSlider(Qt.Horizontal)
            exposure_slider.setRange(-13, 0)
            exposure_slider.setValue(int(props["exposure"]))
            form_layout.addRow("曝光:", exposure_slider)

        layout.addLayout(form_layout)

        # 添加按钮
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        # 显示对话框
        if dialog.exec_() == QDialog.Accepted:
            # 应用设置
            if "brightness" in props:
                self.video_thread.set_camera_property("brightness", brightness_slider.value())

            if "contrast" in props:
                self.video_thread.set_camera_property("contrast", contrast_slider.value())

            if "saturation" in props:
                self.video_thread.set_camera_property("saturation", saturation_slider.value())

            if "exposure" in props:
                self.video_thread.set_camera_property("exposure", exposure_slider.value())

            QMessageBox.information(self, "成功", "摄像头设置已应用")

    # 添加摄像头信息方法
    def _on_camera_info(self):
        """显示摄像头信息"""
        # 检查视频流是否运行
        if not hasattr(self, 'video_thread') or self.video_thread is None or not self.video_thread.isRunning():
            QMessageBox.warning(self, "错误", "请先选择并启动摄像头")
            return

        # 获取摄像头属性和统计信息
        props = self.video_thread.get_camera_properties()
        stats = self.video_thread.get_stats()

        if not props:
            QMessageBox.warning(self, "错误", "无法获取摄像头信息")
            return

        # 构建信息文本
        info_text = "摄像头信息:\n\n"

        if "width" in props and "height" in props:
            info_text += f"分辨率: {int(props['width'])}x{int(props['height'])}\n"

        if "fps" in props:
            info_text += f"帧率: {props['fps']:.1f}\n"

        if "fps" in stats:
            info_text += f"实际帧率: {stats['fps']:.1f}\n"

        if "processing_time" in stats:
            info_text += f"处理时间: {stats['processing_time'] * 1000:.1f} ms\n"

        # 显示信息
        QMessageBox.information(self, "摄像头信息", info_text)