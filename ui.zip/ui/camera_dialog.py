# ui/camera_dialog.py
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                             QComboBox, QGroupBox, QGridLayout, QSpinBox, QTabWidget,
                             QRadioButton, QButtonGroup, QLineEdit, QMessageBox, QSplitter)
from PyQt5.QtCore import Qt, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QPixmap, QImage
import cv2
import numpy as np
import time


class CameraDialog(QDialog):
    """摄像头选择和配置对话框"""
    # 定义信号
    camera_selected = pyqtSignal(object)  # 发送选择的摄像头

    def __init__(self, camera_manager, parent=None):
        """
        初始化摄像头对话框

        Args:
            camera_manager: 摄像头管理器实例
            parent: 父窗口
        """
        super().__init__(parent)
        self.camera_manager = camera_manager
        self.available_cameras = []
        self.preview_running = False
        self.preview_frame = None

        # 初始化UI
        self._init_ui()

        # 扫描可用摄像头
        self._refresh_camera_list()

        # 设置对话框属性
        self.setWindowTitle("摄像头选择")
        self.setMinimumSize(800, 500)

    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 创建标签页
        tab_widget = QTabWidget()

        # USB摄像头标签页
        usb_tab = QWidget()
        usb_layout = QVBoxLayout(usb_tab)

        # 摄像头选择和预览区域
        selection_preview = QSplitter(Qt.Horizontal)

        # 左侧选择区域
        selection_widget = QWidget()
        selection_layout = QVBoxLayout(selection_widget)

        # 摄像头列表
        selection_layout.addWidget(QLabel("可用摄像头:"))
        self.camera_combo = QComboBox()
        self.camera_combo.currentIndexChanged.connect(self._on_camera_selected)
        selection_layout.addWidget(self.camera_combo)

        # 刷新按钮
        refresh_btn = QPushButton("刷新列表")
        refresh_btn.clicked.connect(self._refresh_camera_list)
        selection_layout.addWidget(refresh_btn)

        # 摄像头信息
        info_group = QGroupBox("摄像头信息")
        info_layout = QGridLayout(info_group)

        info_layout.addWidget(QLabel("名称:"), 0, 0)
        self.name_label = QLabel()
        info_layout.addWidget(self.name_label, 0, 1)

        info_layout.addWidget(QLabel("分辨率:"), 1, 0)
        self.resolution_label = QLabel()
        info_layout.addWidget(self.resolution_label, 1, 1)

        info_layout.addWidget(QLabel("帧率:"), 2, 0)
        self.fps_label = QLabel()
        info_layout.addWidget(self.fps_label, 2, 1)

        selection_layout.addWidget(info_group)

        # 分辨率设置
        resolution_group = QGroupBox("分辨率设置")
        resolution_layout = QGridLayout(resolution_group)

        resolution_layout.addWidget(QLabel("宽度:"), 0, 0)
        self.width_spin = QSpinBox()
        self.width_spin.setRange(320, 3840)
        self.width_spin.setSingleStep(8)
        self.width_spin.setValue(640)
        resolution_layout.addWidget(self.width_spin, 0, 1)

        resolution_layout.addWidget(QLabel("高度:"), 1, 0)
        self.height_spin = QSpinBox()
        self.height_spin.setRange(240, 2160)
        self.height_spin.setSingleStep(8)
        self.height_spin.setValue(480)
        resolution_layout.addWidget(self.height_spin, 1, 1)

        apply_resolution_btn = QPushButton("应用分辨率")
        apply_resolution_btn.clicked.connect(self._apply_resolution)
        resolution_layout.addWidget(apply_resolution_btn, 2, 0, 1, 2)

        selection_layout.addWidget(resolution_group)

        # 添加伸缩空间
        selection_layout.addStretch()

        # 将选择区域添加到分割器
        selection_preview.addWidget(selection_widget)

        # 右侧预览区域
        preview_widget = QWidget()
        preview_layout = QVBoxLayout(preview_widget)

        preview_layout.addWidget(QLabel("摄像头预览:"))

        # 预览标签
        self.preview_label = QLabel()
        self.preview_label.setMinimumSize(320, 240)
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setStyleSheet("background-color: black;")
        preview_layout.addWidget(self.preview_label)

        # 预览控制
        preview_controls = QHBoxLayout()

        self.preview_btn = QPushButton("开始预览")
        self.preview_btn.clicked.connect(self._toggle_preview)
        preview_controls.addWidget(self.preview_btn)

        preview_controls.addStretch()

        preview_layout.addLayout(preview_controls)

        # 将预览区域添加到分割器
        selection_preview.addWidget(preview_widget)

        # 设置分割比例
        selection_preview.setSizes([300, 500])

        # 添加分割器到布局
        usb_layout.addWidget(selection_preview)

        # 添加USB标签页
        tab_widget.addTab(usb_tab, "USB摄像头")

        # 网络摄像头标签页
        network_tab = QWidget()
        network_layout = QVBoxLayout(network_tab)

        # 网络摄像头设置
        network_group = QGroupBox("网络摄像头设置")
        network_form = QGridLayout(network_group)

        network_form.addWidget(QLabel("名称:"), 0, 0)
        self.network_name_edit = QLineEdit("网络摄像头")
        network_form.addWidget(self.network_name_edit, 0, 1)

        network_form.addWidget(QLabel("IP地址:"), 1, 0)
        self.ip_edit = QLineEdit("192.168.1.100")
        network_form.addWidget(self.ip_edit, 1, 1)

        network_form.addWidget(QLabel("端口:"), 2, 0)
        self.port_edit = QLineEdit("8080")
        network_form.addWidget(self.port_edit, 2, 1)

        network_form.addWidget(QLabel("协议:"), 3, 0)
        self.protocol_combo = QComboBox()
        self.protocol_combo.addItems(["HTTP", "RTSP"])
        network_form.addWidget(self.protocol_combo, 3, 1)

        network_form.addWidget(QLabel("路径:"), 4, 0)
        self.path_edit = QLineEdit("/video")
        network_form.addWidget(self.path_edit, 4, 1)

        network_layout.addWidget(network_group)

        # 生成URL按钮
        generate_btn = QPushButton("生成URL")
        generate_btn.clicked.connect(self._generate_network_url)
        network_layout.addWidget(generate_btn)

        # URL显示
        network_layout.addWidget(QLabel("URL:"))
        self.url_edit = QLineEdit()
        self.url_edit.setReadOnly(True)
        network_layout.addWidget(self.url_edit)

        # 连接按钮
        connect_network_btn = QPushButton("连接网络摄像头")
        connect_network_btn.clicked.connect(self._connect_network_camera)
        network_layout.addWidget(connect_network_btn)

        network_layout.addStretch()

        # 添加网络标签页
        tab_widget.addTab(network_tab, "网络摄像头")

        # 添加标签页到主布局
        main_layout.addWidget(tab_widget)

        # 底部按钮
        button_layout = QHBoxLayout()

        # 确认按钮
        self.ok_btn = QPushButton("确认使用选中摄像头")
        self.ok_btn.clicked.connect(self._on_ok_clicked)
        button_layout.addWidget(self.ok_btn)

        # 取消按钮
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)

        main_layout.addLayout(button_layout)

        # 预览定时器
        self.preview_timer = None

    def _refresh_camera_list(self):
        """刷新摄像头列表"""
        # 停止预览
        self._stop_preview()

        # 断开当前摄像头
        self.camera_manager.disconnect()

        # 扫描摄像头
        self.available_cameras = self.camera_manager.scan_cameras()

        # 清空下拉框
        self.camera_combo.clear()

        # 添加摄像头到下拉框
        for camera in self.available_cameras:
            if camera.is_usb:
                self.camera_combo.addItem(str(camera), camera)

    def _on_camera_selected(self, index):
        """摄像头选择处理"""
        if index < 0 or index >= len(self.available_cameras):
            return

        # 获取选中的摄像头
        camera = self.available_cameras[index]

        # 更新信息显示
        self.name_label.setText(camera.name)
        self.resolution_label.setText(f"{camera.resolution[0]}x{camera.resolution[1]}")
        self.fps_label.setText(f"{camera.fps}")

        # 更新分辨率设置
        self.width_spin.setValue(camera.resolution[0])
        self.height_spin.setValue(camera.resolution[1])

        # 如果在预览中，停止预览
        if self.preview_running:
            self._stop_preview()

    def _toggle_preview(self):
        """切换预览状态"""
        if self.preview_running:
            self._stop_preview()
        else:
            self._start_preview()

    def _start_preview(self):
        """开始预览"""
        if self.preview_running:
            return

        # 获取选中的摄像头
        index = self.camera_combo.currentIndex()
        if index < 0 or index >= len(self.available_cameras):
            QMessageBox.warning(self, "错误", "请先选择摄像头")
            return

        camera = self.available_cameras[index]

        # 连接摄像头
        if not self.camera_manager.connect_camera(camera):
            QMessageBox.warning(self, "错误", "无法连接摄像头")
            return

        # 应用分辨率
        width = self.width_spin.value()
        height = self.height_spin.value()
        self.camera_manager.set_resolution(width, height)

        # 启动摄像头
        if not self.camera_manager.start():
            QMessageBox.warning(self, "错误", "无法启动摄像头")
            return

        # 创建预览定时器
        self.preview_timer = self.startTimer(33)  # 约30fps

        # 更新UI
        self.preview_running = True
        self.preview_btn.setText("停止预览")

    def _stop_preview(self):
        """停止预览"""
        if not self.preview_running:
            return

        # 停止定时器
        if self.preview_timer:
            self.killTimer(self.preview_timer)
            self.preview_timer = None

        # 断开摄像头
        self.camera_manager.stop()

        # 清空预览
        self.preview_label.clear()
        self.preview_label.setText("预览已停止")

        # 更新UI
        self.preview_running = False
        self.preview_btn.setText("开始预览")

    def timerEvent(self, event):
        """定时器事件，更新预览"""
        if event.timerId() == self.preview_timer:
            # 获取帧
            frame = self.camera_manager.get_frame()
            if frame is not None:
                # 转换为Qt图像
                height, width, channel = frame.shape
                bytes_per_line = 3 * width
                img = QImage(frame.data, width, height, bytes_per_line, QImage.Format_BGR888)

                # 缩放图像以适应预览区域
                pixmap = QPixmap.fromImage(img)
                pixmap = pixmap.scaled(self.preview_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)

                # 显示图像
                self.preview_label.setPixmap(pixmap)

    def _apply_resolution(self):
        """应用分辨率设置"""
        if not self.camera_manager.cap:
            QMessageBox.warning(self, "错误", "请先启动预览")
            return

        # 获取分辨率设置
        width = self.width_spin.value()
        height = self.height_spin.value()

        # 设置分辨率
        success = self.camera_manager.set_resolution(width, height)

        if success:
            # 更新分辨率标签
            actual_width = self.camera_manager.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            actual_height = self.camera_manager.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            self.resolution_label.setText(f"{int(actual_width)}x{int(actual_height)}")

            QMessageBox.information(self, "成功", f"分辨率已设置为: {int(actual_width)}x{int(actual_height)}")
        else:
            QMessageBox.warning(self, "错误", "设置分辨率失败")

    def _generate_network_url(self):
        """生成网络摄像头URL"""
        ip = self.ip_edit.text()
        port = self.port_edit.text()
        protocol = self.protocol_combo.currentText().lower()
        path = self.path_edit.text()

        # 确保路径以/开头
        if not path.startswith('/'):
            path = '/' + path

        # 生成URL
        url = f"{protocol}://{ip}:{port}{path}"

        # 显示URL
        self.url_edit.setText(url)

    def _connect_network_camera(self):
        """连接网络摄像头"""
        # 停止预览
        self._stop_preview()

        # 获取网络摄像头信息
        name = self.network_name_edit.text()
        ip = self.ip_edit.text()
        port = self.port_edit.text()

        try:
            port = int(port)
        except ValueError:
            QMessageBox.warning(self, "错误", "端口必须是数字")
            return

        # 创建网络摄像头信息
        from modules.camera_manager import CameraInfo
        network_camera = CameraInfo(-1, name, is_usb=False, ip=ip, port=port)

        # 添加到摄像头列表
        found = False
        for i, camera in enumerate(self.available_cameras):
            if not camera.is_usb and camera.ip == ip and camera.port == port:
                self.available_cameras[i] = network_camera
                found = True
                break

        if not found:
            self.available_cameras.append(network_camera)
            self.camera_combo.addItem(str(network_camera), network_camera)

        # 选择新添加的摄像头
        for i in range(self.camera_combo.count()):
            camera = self.camera_combo.itemData(i)
            if not camera.is_usb and camera.ip == ip and camera.port == port:
                self.camera_combo.setCurrentIndex(i)
                break

        # 尝试连接
        self._start_preview()

    def _on_ok_clicked(self):
        """确认按钮点击处理"""
        # 获取选择的摄像头
        index = self.camera_combo.currentIndex()
        if index < 0 or index >= len(self.available_cameras):
            QMessageBox.warning(self, "错误", "请先选择摄像头")
            return

        camera = self.available_cameras[index]

        # 停止预览
        self._stop_preview()

        # 发送信号
        self.camera_selected.emit(camera)

        # 关闭对话框
        self.accept()

    def closeEvent(self, event):
        """关闭事件处理"""
        self._stop_preview()
        event.accept()