# main.py
"""
珊瑚守望水下机器人上位机主程序
"""
import sys
import argparse
from PyQt5.QtWidgets import QApplication

from main_window import MainWindow
import config
from OpenGL.GLUT import *
import sys

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="珊瑚守望水下机器人上位机")
    parser.add_argument("--camera", type=str, help="摄像头索引或IP地址 (例如: 0 或 192.168.1.100:8080)")
    return parser.parse_args()


def main():
    """主函数"""
    # 解析命令行参数
    args = parse_args()

    # 如果指定了摄像头，更新配置
    if args.camera:
        try:
            # 尝试将参数解析为整数(USB摄像头索引)
            camera_index = int(args.camera)
            config.VIDEO_SOURCE = camera_index
        except ValueError:
            # 不是整数，认为是IP摄像头地址
            config.VIDEO_SOURCE = args.camera

    # 创建应用
    app = QApplication(sys.argv)
    app.setApplicationName(f"{config.ROBOT_NAME}控制系统")

    # 创建主窗口
    main_window = MainWindow()
    main_window.show()

    # 运行应用
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()