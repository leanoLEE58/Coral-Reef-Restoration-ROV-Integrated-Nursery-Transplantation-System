# ui/arm_control_widget.py
# ui/arm_control_widget.py
import os
import math
import time

import numpy as np
import cv2
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                            QLabel, QPushButton, QSlider, QGroupBox, QComboBox,
                            QSpinBox, QDoubleSpinBox, QTabWidget, QCheckBox,
                            QRadioButton, QButtonGroup, QFileDialog, QSplitter,
                            QFrame, QDial, QScrollArea, QSizePolicy, QProgressBar)
from PyQt5.QtCore import Qt, pyqtSignal, pyqtSlot, QTimer, QRectF, QPointF
from PyQt5.QtGui import QPainter, QColor, QPen, QBrush, QFont, QImage, QPixmap
from PyQt5.QtChart import QChart, QChartView, QLineSeries, QValueAxis
import pyqtgraph as pg
from OpenGL.GL import *
from OpenGL.GLU import *
from PyQt5.QtOpenGL import QGLWidget
from OpenGL.GLUT import *
import sys
class ArcSlider(QWidget):
    """弧形滑块控件"""
    valueChanged = pyqtSignal(float)

    def __init__(self, min_value=-90, max_value=90, value=0, parent=None):
        """初始化弧形滑块"""
        super().__init__(parent)
        self.min_value = min_value
        self.max_value = max_value
        self.value = value
        self.hover = False
        self.pressed = False

        # 样式设置
        self.track_width = 15
        self.handle_size = 20
        self.start_angle = 220
        self.span_angle = 280

        # 颜色设置
        self.track_color = QColor(60, 60, 60)
        self.fill_color = QColor(41, 128, 185)
        self.handle_color = QColor(52, 152, 219)
        self.text_color = QColor(255, 255, 255)

        # 设置尺寸
        self.setMinimumSize(120, 120)
        self.setMouseTracking(True)

    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 计算中心点和半径
        center_x = self.width() / 2
        center_y = self.height() / 2
        radius = min(center_x, center_y) - self.track_width / 2 - 5

        # 绘制轨道
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(self.track_color))

        # 绘制背景轨道
        track_rect = QRectF(
            center_x - radius,
            center_y - radius,
            radius * 2,
            radius * 2
        )

        # 绘制轨道背景
        painter.drawArc(track_rect, self.start_angle * 16, -self.span_angle * 16)

        # 计算当前值的角度比例
        angle_per_unit = self.span_angle / (self.max_value - self.min_value)
        current_angle = self.start_angle - (self.value - self.min_value) * angle_per_unit

        # 绘制填充部分
        painter.setBrush(QBrush(self.fill_color))
        painter.drawArc(track_rect, self.start_angle * 16, -(self.start_angle - current_angle) * 16)

        # 计算手柄位置
        angle_rad = math.radians(current_angle)
        handle_x = center_x + radius * math.cos(angle_rad)
        handle_y = center_y - radius * math.sin(angle_rad)

        # 绘制手柄
        painter.setBrush(QBrush(self.handle_color))
        painter.drawEllipse(QPointF(handle_x, handle_y), self.handle_size / 2, self.handle_size / 2)

        # 绘制值文本
        painter.setPen(self.text_color)
        painter.setFont(QFont("Arial", 14, QFont.Bold))
        text_rect = QRectF(center_x - 50, center_y - 15, 100, 30)
        painter.drawText(text_rect, Qt.AlignCenter, f"{self.value:.1f}°")

        # 绘制最小值和最大值
        painter.setFont(QFont("Arial", 8))

        # 最小值
        min_angle_rad = math.radians(self.start_angle)
        min_x = center_x + (radius + 15) * math.cos(min_angle_rad)
        min_y = center_y - (radius + 15) * math.sin(min_angle_rad)
        painter.drawText(QRectF(min_x - 20, min_y - 10, 40, 20), Qt.AlignCenter, f"{self.min_value}°")

        # 最大值
        max_angle_rad = math.radians(self.start_angle - self.span_angle)
        max_x = center_x + (radius + 15) * math.cos(max_angle_rad)
        max_y = center_y - (radius + 15) * math.sin(max_angle_rad)
        painter.drawText(QRectF(max_x - 20, max_y - 10, 40, 20), Qt.AlignCenter, f"{self.max_value}°")

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            self.pressed = True
            self._update_value_from_pos(event.pos())

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if self.pressed:
            self._update_value_from_pos(event.pos())

    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        if event.button() == Qt.LeftButton:
            self.pressed = False

    def _update_value_from_pos(self, pos):
        """根据鼠标位置更新值"""
        # 计算中心点和半径
        center_x = self.width() / 2
        center_y = self.height() / 2

        # 计算鼠标位置相对于中心的角度
        dx = pos.x() - center_x
        dy = center_y - pos.y()  # 反转Y轴，使顺时针方向角度增加

        # 计算角度
        angle_rad = math.atan2(dy, dx)
        angle_deg = math.degrees(angle_rad)

        # 确保角度在[0, 360)范围内
        if angle_deg < 0:
            angle_deg += 360

        # 将角度映射到值
        if self.start_angle > angle_deg:
            value_angle = self.start_angle - angle_deg
        else:
            value_angle = self.start_angle + 360 - angle_deg

        # 限制在有效弧度范围内
        value_angle = min(self.span_angle, max(0, value_angle))

        # 计算值
        value = self.min_value + (value_angle / self.span_angle) * (self.max_value - self.min_value)

        # 更新值
        if value != self.value:
            self.value = value
            self.update()
            self.valueChanged.emit(value)

    def set_value(self, value):
        """设置值"""
        value = max(self.min_value, min(self.max_value, value))
        if value != self.value:
            self.value = value
            self.update()
            self.valueChanged.emit(value)

    def set_range(self, min_value, max_value):
        """设置范围"""
        if min_value >= max_value:
            return
        self.min_value = min_value
        self.max_value = max_value
        self.value = max(min_value, min(self.value, max_value))
        self.update()


class RobotArmGL(QGLWidget):
    """机械臂3D可视化组件"""

    def __init__(self, parent=None):
        """初始化3D可视化组件"""
        super().__init__(parent)
        self.setMinimumSize(300, 300)

        # 视图参数
        self.xRot = 0
        self.yRot = 0
        self.zRot = 0
        self.zoom = -30

        # 机械臂关节角度（示例：5个关节）
        self.joint_angles = [0.0, 0.0, 0.0, 0.0, 0.0]

        # 机械臂尺寸参数
        self.link_lengths = [5.0, 8.0, 8.0, 5.0, 3.0]
        self.link_diameters = [1.5, 1.2, 1.0, 0.8, 0.5]

        # 鼠标位置
        self.lastPos = None

    def initializeGL(self):
        """初始化OpenGL"""
        self.qglClearColor(QColor(40, 40, 40))
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)
        glEnable(GL_NORMALIZE)

        # 设置光照
        light_position = [5.0, 5.0, 10.0, 1.0]
        light_ambient = [0.2, 0.2, 0.2, 1.0]
        light_diffuse = [0.8, 0.8, 0.8, 1.0]
        light_specular = [1.0, 1.0, 1.0, 1.0]

        glLightfv(GL_LIGHT0, GL_POSITION, light_position)
        glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient)
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse)
        glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular)

    def resizeGL(self, width, height):
        """调整视口"""
        side = min(width, height)
        if side < 0:
            return

        glViewport((width - side) // 2, (height - side) // 2, side, side)

        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()

        # 透视投影
        gluPerspective(45.0, width / float(height), 0.1, 100.0)

        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):
        """绘制场景"""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()

        # 设置相机位置
        glTranslated(0.0, 0.0, self.zoom)
        glRotated(self.xRot / 16.0, 1.0, 0.0, 0.0)
        glRotated(self.yRot / 16.0, 0.0, 1.0, 0.0)
        glRotated(self.zRot / 16.0, 0.0, 0.0, 1.0)

        # 绘制坐标轴
        self._draw_axes(10.0)

        # 绘制地面网格
        self._draw_grid(20.0, 20)

        # 绘制机械臂
        self._draw_robot_arm()

    def _draw_axes(self, length):
        """绘制坐标轴"""
        glDisable(GL_LIGHTING)

        glLineWidth(3.0)
        glBegin(GL_LINES)

        # X轴 (红色)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(length, 0.0, 0.0)

        # Y轴 (绿色)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, length, 0.0)

        # Z轴 (蓝色)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, length)

        glEnd()

        glEnable(GL_LIGHTING)

    def _draw_grid(self, size, steps):
        """绘制地面网格"""
        glDisable(GL_LIGHTING)

        glLineWidth(1.0)
        glColor3f(0.5, 0.5, 0.5)

        step_size = size / steps

        glBegin(GL_LINES)

        for i in range(steps + 1):
            x = -size / 2 + i * step_size

            # X方向线
            glVertex3f(x, -size / 2, 0.0)
            glVertex3f(x, size / 2, 0.0)

            # Y方向线
            glVertex3f(-size / 2, x, 0.0)
            glVertex3f(size / 2, x, 0.0)

        glEnd()

        glEnable(GL_LIGHTING)

    def _draw_robot_arm(self):
        """绘制机械臂"""
        glPushMatrix()

        # 绘制基座
        glColor3f(0.5, 0.5, 0.5)
        self._draw_cylinder(2.0, 2.0, 1.0)

        # 当前位置和方向
        x, y, z = 0.0, 0.0, 1.0
        current_direction = [0.0, 0.0, 1.0]

        # 绘制机械臂各个关节
        for i in range(len(self.joint_angles)):
            # 移动到关节位置
            glTranslatef(0.0, 0.0, 0.5)

            # 绘制关节
            glColor3f(0.2, 0.3, 0.8)
            self._draw_sphere(self.link_diameters[i] * 0.7)

            # 应用关节角度
            glRotatef(self.joint_angles[i], 1.0, 0.0, 0.0)

            # 绘制连杆
            glColor3f(0.8, 0.3, 0.2)
            self._draw_cylinder(self.link_diameters[i] / 2, self.link_diameters[i] / 2, self.link_lengths[i])

            # 移动到连杆末端
            glTranslatef(0.0, 0.0, self.link_lengths[i])

            # 如果是最后一个关节，绘制末端执行器
            if i == len(self.joint_angles) - 1:
                glColor3f(0.2, 0.8, 0.2)
                self._draw_gripper()

        glPopMatrix()

    def _draw_cylinder(self, base_radius, top_radius, height, slices=16, stacks=5):
        """绘制圆柱体"""
        # 绘制侧面
        glBegin(GL_QUAD_STRIP)

        for i in range(slices + 1):
            angle = 2.0 * math.pi * i / slices
            x = math.cos(angle)
            y = math.sin(angle)

            # 计算表面法向量
            nx, ny = x, y

            glNormal3f(nx, ny, 0.0)
            glVertex3f(base_radius * x, base_radius * y, 0.0)
            glVertex3f(top_radius * x, top_radius * y, height)

        glEnd()

        # 绘制底面
        glBegin(GL_TRIANGLE_FAN)
        glNormal3f(0.0, 0.0, -1.0)
        glVertex3f(0.0, 0.0, 0.0)

        for i in range(slices + 1):
            angle = 2.0 * math.pi * i / slices
            x = math.cos(angle)
            y = math.sin(angle)
            glVertex3f(base_radius * x, base_radius * y, 0.0)

        glEnd()

        # 绘制顶面
        glBegin(GL_TRIANGLE_FAN)
        glNormal3f(0.0, 0.0, 1.0)
        glVertex3f(0.0, 0.0, height)

        for i in range(slices + 1):
            angle = 2.0 * math.pi * (slices - i) / slices
            x = math.cos(angle)
            y = math.sin(angle)
            glVertex3f(top_radius * x, top_radius * y, height)

        glEnd()

    def _draw_sphere(self, radius, slices=16, stacks=16):
        """绘制球体"""
        for i in range(stacks):
            lat0 = math.pi * (-0.5 + float(i) / stacks)
            z0 = math.sin(lat0)
            zr0 = math.cos(lat0)

            lat1 = math.pi * (-0.5 + float(i + 1) / stacks)
            z1 = math.sin(lat1)
            zr1 = math.cos(lat1)

            glBegin(GL_QUAD_STRIP)

            for j in range(slices + 1):
                lng = 2 * math.pi * float(j) / slices
                x = math.cos(lng)
                y = math.sin(lng)

                glNormal3f(x * zr0, y * zr0, z0)
                glVertex3f(radius * x * zr0, radius * y * zr0, radius * z0)
                glNormal3f(x * zr1, y * zr1, z1)
                glVertex3f(radius * x * zr1, radius * y * zr1, radius * z1)

            glEnd()

    def _draw_gripper(self):
        """绘制机械手爪"""
        # 绘制手爪基座
        self._draw_sphere(0.8)

        # 绘制手爪手指
        glPushMatrix()
        glTranslatef(0.0, 0.4, 0.0)
        glRotatef(90, 1.0, 0.0, 0.0)
        self._draw_cylinder(0.2, 0.1, 1.5)
        glPopMatrix()

        glPushMatrix()
        glTranslatef(0.0, -0.4, 0.0)
        glRotatef(-90, 1.0, 0.0, 0.0)
        self._draw_cylinder(0.2, 0.1, 1.5)
        glPopMatrix()

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        self.lastPos = event.pos()

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if event.buttons() & Qt.LeftButton:
            dx = event.x() - self.lastPos.x()
            dy = event.y() - self.lastPos.y()

            self.yRot += dx
            self.xRot += dy
            self.update()

        elif event.buttons() & Qt.RightButton:
            dx = event.x() - self.lastPos.x()
            dy = event.y() - self.lastPos.y()

            self.zoom += dy * 0.1
            self.update()

        self.lastPos = event.pos()

    def wheelEvent(self, event):
        """鼠标滚轮事件"""
        delta = event.angleDelta().y() / 120  # 每个刻度是120
        self.zoom += delta
        self.update()

    def set_joint_angles(self, angles):
        """设置关节角度"""
        if len(angles) == len(self.joint_angles):
            self.joint_angles = angles.copy()
            self.update()


class VisionProcessingWidget(QWidget):
    """视觉处理控制组件"""

    paramChanged = pyqtSignal(dict)

    def __init__(self, parent=None):
        """初始化视觉处理组件"""
        super().__init__(parent)

        # 初始化视觉处理参数
        self.vision_params = {
            'enabled': True,
            'edge_detection': True,
            'threshold1': 50,
            'threshold2': 150,
            'blur_size': 5,
            'min_area': 500,
            'max_area': 50000,
            'force_multiplier': 1.0
        }

        # 图像处理变量
        self.original_image = None
        self.processed_image = None
        self.detected_edges = []

        # 初始化UI
        self._init_ui()

    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 创建视觉显示部分
        display_group = QGroupBox("视觉处理显示")
        display_layout = QHBoxLayout(display_group)

        # 原始图像显示
        self.original_image_label = QLabel()
        self.original_image_label.setMinimumSize(320, 240)
        self.original_image_label.setAlignment(Qt.AlignCenter)
        self.original_image_label.setStyleSheet("background-color: black;")
        display_layout.addWidget(self.original_image_label)

        # 处理后图像显示
        self.processed_image_label = QLabel()
        self.processed_image_label.setMinimumSize(320, 240)
        self.processed_image_label.setAlignment(Qt.AlignCenter)
        self.processed_image_label.setStyleSheet("background-color: black;")
        display_layout.addWidget(self.processed_image_label)

        main_layout.addWidget(display_group)

        # 创建参数控制部分
        control_layout = QHBoxLayout()

        # 边缘检测参数
        edge_group = QGroupBox("边缘检测参数")
        edge_layout = QGridLayout(edge_group)

        # 启用边缘检测
        self.edge_detection_check = QCheckBox("启用边缘检测")
        self.edge_detection_check.setChecked(self.vision_params['edge_detection'])
        self.edge_detection_check.toggled.connect(self._on_param_changed)
        edge_layout.addWidget(self.edge_detection_check, 0, 0, 1, 2)

        # Canny参数 - 阈值1
        edge_layout.addWidget(QLabel("阈值1:"), 1, 0)
        self.threshold1_spin = QSpinBox()
        self.threshold1_spin.setRange(0, 255)
        self.threshold1_spin.setValue(self.vision_params['threshold1'])
        self.threshold1_spin.valueChanged.connect(self._on_param_changed)
        edge_layout.addWidget(self.threshold1_spin, 1, 1)

        # Canny参数 - 阈值2
        edge_layout.addWidget(QLabel("阈值2:"), 2, 0)
        self.threshold2_spin = QSpinBox()
        self.threshold2_spin.setRange(0, 255)
        self.threshold2_spin.setValue(self.vision_params['threshold2'])
        self.threshold2_spin.valueChanged.connect(self._on_param_changed)
        edge_layout.addWidget(self.threshold2_spin, 2, 1)

        # 模糊尺寸
        edge_layout.addWidget(QLabel("模糊尺寸:"), 3, 0)
        self.blur_spin = QSpinBox()
        self.blur_spin.setRange(1, 15)
        self.blur_spin.setValue(self.vision_params['blur_size'])
        self.blur_spin.setSingleStep(2)  # 只允许奇数
        self.blur_spin.valueChanged.connect(self._ensure_odd)
        edge_layout.addWidget(self.blur_spin, 3, 1)

        control_layout.addWidget(edge_group)

        # 检测过滤参数
        filter_group = QGroupBox("检测过滤")
        filter_layout = QGridLayout(filter_group)

        # 最小面积
        filter_layout.addWidget(QLabel("最小面积:"), 0, 0)
        self.min_area_spin = QSpinBox()
        self.min_area_spin.setRange(0, 100000)
        self.min_area_spin.setValue(self.vision_params['min_area'])
        self.min_area_spin.setSingleStep(100)
        self.min_area_spin.valueChanged.connect(self._on_param_changed)
        filter_layout.addWidget(self.min_area_spin, 0, 1)

        # 最大面积
        filter_layout.addWidget(QLabel("最大面积:"), 1, 0)
        self.max_area_spin = QSpinBox()
        self.max_area_spin.setRange(1000, 1000000)
        self.max_area_spin.setValue(self.vision_params['max_area'])
        self.max_area_spin.setSingleStep(1000)
        self.max_area_spin.valueChanged.connect(self._on_param_changed)
        filter_layout.addWidget(self.max_area_spin, 1, 1)

        control_layout.addWidget(filter_group)

        # 力反馈参数
        force_group = QGroupBox("力反馈调节")
        force_layout = QGridLayout(force_group)

        # 力反馈倍率
        force_layout.addWidget(QLabel("力反馈倍率:"), 0, 0)
        self.force_multiplier_spin = QDoubleSpinBox()
        self.force_multiplier_spin.setRange(0.1, 10.0)
        self.force_multiplier_spin.setValue(self.vision_params['force_multiplier'])
        self.force_multiplier_spin.setSingleStep(0.1)
        self.force_multiplier_spin.setDecimals(2)
        self.force_multiplier_spin.valueChanged.connect(self._on_param_changed)
        force_layout.addWidget(self.force_multiplier_spin, 0, 1)

        # 预设模式组合框
        force_layout.addWidget(QLabel("预设模式:"), 1, 0)
        self.preset_combo = QComboBox()
        self.preset_combo.addItems(["精细模式", "标准模式", "强力模式"])
        self.preset_combo.currentIndexChanged.connect(self._on_preset_changed)
        force_layout.addWidget(self.preset_combo, 1, 1)

        # 力反馈指示器
        self.force_indicator = QProgressBar()
        self.force_indicator.setRange(0, 100)
        self.force_indicator.setValue(0)
        force_layout.addWidget(QLabel("当前力反馈:"), 2, 0)
        force_layout.addWidget(self.force_indicator, 2, 1)

        control_layout.addWidget(force_group)

        main_layout.addLayout(control_layout)

        # 底部操作按钮
        button_layout = QHBoxLayout()

        # 刷新按钮
        refresh_btn = QPushButton("刷新视图")
        refresh_btn.clicked.connect(self._on_refresh)
        button_layout.addWidget(refresh_btn)

        # 应用设置按钮
        apply_btn = QPushButton("应用设置")
        apply_btn.clicked.connect(self._on_apply)
        button_layout.addWidget(apply_btn)

        # 保存设置按钮
        save_btn = QPushButton("保存设置")
        save_btn.clicked.connect(self._on_save_settings)
        button_layout.addWidget(save_btn)

        # 加载设置按钮
        load_btn = QPushButton("加载设置")
        load_btn.clicked.connect(self._on_load_settings)
        button_layout.addWidget(load_btn)

        main_layout.addLayout(button_layout)

        # 启动图像更新定时器
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self._update_force_indicator)
        self.update_timer.start(100)  # 10 Hz

    def _ensure_odd(self, value):
        """确保模糊尺寸为奇数"""
        if value % 2 == 0:
            new_value = value + 1
            self.blur_spin.setValue(new_value)
        else:
            self._on_param_changed()

    def _on_param_changed(self):
        """参数变更处理"""
        # 更新参数字典
        self.vision_params['edge_detection'] = self.edge_detection_check.isChecked()
        self.vision_params['threshold1'] = self.threshold1_spin.value()
        self.vision_params['threshold2'] = self.threshold2_spin.value()
        self.vision_params['blur_size'] = self.blur_spin.value()
        self.vision_params['min_area'] = self.min_area_spin.value()
        self.vision_params['max_area'] = self.max_area_spin.value()
        self.vision_params['force_multiplier'] = self.force_multiplier_spin.value()

        # 处理图像
        self._process_image()

    def _on_preset_changed(self, index):
        """预设模式变更处理"""
        if index == 0:  # 精细模式
            self.threshold1_spin.setValue(30)
            self.threshold2_spin.setValue(100)
            self.blur_spin.setValue(3)
            self.force_multiplier_spin.setValue(0.5)
        elif index == 1:  # 标准模式
            self.threshold1_spin.setValue(50)
            self.threshold2_spin.setValue(150)
            self.blur_spin.setValue(5)
            self.force_multiplier_spin.setValue(1.0)
        elif index == 2:  # 强力模式
            self.threshold1_spin.setValue(80)
            self.threshold2_spin.setValue(200)
            self.blur_spin.setValue(7)
            self.force_multiplier_spin.setValue(2.0)

    def _on_refresh(self):
        """刷新视图"""
        self._process_image()

    def _on_apply(self):
        """应用设置"""
        self.paramChanged.emit(self.vision_params)

    def _on_save_settings(self):
        """保存设置"""
        filename, _ = QFileDialog.getSaveFileName(self, "保存设置", "", "JSON文件 (*.json)")
        if filename:
            try:
                import json
                with open(filename, 'w') as f:
                    json.dump(self.vision_params, f, indent=4)
            except Exception as e:
                print(f"保存设置失败: {str(e)}")

    def _on_load_settings(self):
        """加载设置"""
        filename, _ = QFileDialog.getOpenFileName(self, "加载设置", "", "JSON文件 (*.json)")
        if filename:
            try:
                import json
                with open(filename, 'r') as f:
                    params = json.load(f)
                self._apply_loaded_params(params)
            except Exception as e:
                print(f"加载设置失败: {str(e)}")

    def _apply_loaded_params(self, params):
        """应用加载的参数"""
        if 'edge_detection' in params:
            self.edge_detection_check.setChecked(params['edge_detection'])
        if 'threshold1' in params:
            self.threshold1_spin.setValue(params['threshold1'])
        if 'threshold2' in params:
            self.threshold2_spin.setValue(params['threshold2'])
        if 'blur_size' in params:
            self.blur_spin.setValue(params['blur_size'])
        if 'min_area' in params:
            self.min_area_spin.setValue(params['min_area'])
        if 'max_area' in params:
            self.max_area_spin.setValue(params['max_area'])
        if 'force_multiplier' in params:
            self.force_multiplier_spin.setValue(params['force_multiplier'])

        # 更新参数字典
        self.vision_params.update(params)

        # 处理图像
        self._process_image()

    def _update_force_indicator(self):
        """更新力反馈指示器（模拟）"""
        if not self.detected_edges:
            self.force_indicator.setValue(0)
            return

        # 模拟基于检测到的边缘数量和面积的力反馈
        edge_count = len(self.detected_edges)
        avg_area = sum(area for _, area in self.detected_edges) / edge_count if edge_count > 0 else 0

        # 计算力反馈值 (0-100)
        force_value = min(100, int((edge_count * avg_area / 1000) * self.vision_params['force_multiplier']))

        # 设置进度条颜色
        if force_value < 33:
            self.force_indicator.setStyleSheet("QProgressBar::chunk { background-color: #2ecc71; }")
        elif force_value < 66:
            self.force_indicator.setStyleSheet("QProgressBar::chunk { background-color: #f39c12; }")
        else:
            self.force_indicator.setStyleSheet("QProgressBar::chunk { background-color: #e74c3c; }")

        # 更新力反馈指示器
        self.force_indicator.setValue(force_value)

    def set_image(self, image):
        """设置图像"""
        self.original_image = image

        # 显示原始图像
        height, width, channel = image.shape
        bytes_per_line = 3 * width
        q_image = QImage(image.data, width, height, bytes_per_line, QImage.Format_RGB888)
        self.original_image_label.setPixmap(QPixmap.fromImage(q_image).scaled(
            self.original_image_label.width(),
            self.original_image_label.height(),
            Qt.KeepAspectRatio
        ))

        # 处理图像
        self._process_image()

    def _process_image(self):
        """处理图像"""
        if self.original_image is None:
            return

        # 复制原始图像
        processed = self.original_image.copy()

        # 边缘检测
        if self.vision_params['edge_detection']:
            # 转换为灰度图
            gray = cv2.cvtColor(processed, cv2.COLOR_BGR2GRAY)

            # 应用高斯模糊
            blur_size = self.vision_params['blur_size']
            blurred = cv2.GaussianBlur(gray, (blur_size, blur_size), 0)

            # Canny边缘检测
            edges = cv2.Canny(blurred,
                              self.vision_params['threshold1'],
                              self.vision_params['threshold2'])

            # 寻找轮廓
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            # 过滤轮廓
            self.detected_edges = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if self.vision_params['min_area'] <= area <= self.vision_params['max_area']:
                    # 绘制轮廓
                    cv2.drawContours(processed, [contour], 0, (0, 255, 0), 2)

                    # 计算轮廓中心
                    M = cv2.moments(contour)
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        cv2.circle(processed, (cx, cy), 5, (255, 0, 0), -1)

                    # 保存检测到的边缘
                    self.detected_edges.append((contour, area))

            # 显示边缘计数
            cv2.putText(processed, f"检测到 {len(self.detected_edges)} 个边缘",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

        # 存储处理后图像
        self.processed_image = processed

        # 显示处理后图像
        height, width, channel = processed.shape
        bytes_per_line = 3 * width
        q_image = QImage(processed.data, width, height, bytes_per_line, QImage.Format_RGB888)
        self.processed_image_label.setPixmap(QPixmap.fromImage(q_image).scaled(
            self.processed_image_label.width(),
            self.processed_image_label.height(),
            Qt.KeepAspectRatio
        ))

        # 更新力反馈指示器
        self._update_force_indicator()


class ForceVisualizerWidget(QWidget):
    """力反馈可视化组件"""

    def __init__(self, parent=None):
        """初始化力可视化组件"""
        super().__init__(parent)

        # 初始化数据
        self.force_data = {
            'x': 0.0,
            'y': 0.0,
            'z': 0.0,
            'magnitude': 0.0
        }

        # 力和扭矩历史数据
        self.history_length = 100
        self.force_history = {
            'x': [0.0] * self.history_length,
            'y': [0.0] * self.history_length,
            'z': [0.0] * self.history_length,
            'magnitude': [0.0] * self.history_length
        }

        # 初始化UI
        self._init_ui()

    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 创建力数据显示部分
        force_group = QGroupBox("当前力反馈数据")
        force_layout = QGridLayout(force_group)

        # 力数据标签
        force_layout.addWidget(QLabel("X轴力:"), 0, 0)
        self.force_x_label = QLabel("0.00 N")
        force_layout.addWidget(self.force_x_label, 0, 1)

        force_layout.addWidget(QLabel("Y轴力:"), 1, 0)
        self.force_y_label = QLabel("0.00 N")
        force_layout.addWidget(self.force_y_label, 1, 1)

        force_layout.addWidget(QLabel("Z轴力:"), 2, 0)
        self.force_z_label = QLabel("0.00 N")
        force_layout.addWidget(self.force_z_label, 2, 1)

        force_layout.addWidget(QLabel("合力:"), 3, 0)
        self.force_mag_label = QLabel("0.00 N")
        force_layout.addWidget(self.force_mag_label, 3, 1)

        # 力方向可视化
        self.force_direction_widget = QWidget()
        self.force_direction_widget.setMinimumSize(150, 150)
        self.force_direction_widget.paintEvent = self._paint_force_direction
        force_layout.addWidget(self.force_direction_widget, 0, 2, 4, 1)

        main_layout.addWidget(force_group)

        # 创建历史数据图表
        self.chart_widget = pg.PlotWidget()
        self.chart_widget.setBackground('k')
        self.chart_widget.setLabel('left', '力 (N)')
        self.chart_widget.setLabel('bottom', '时间 (样本)')
        self.chart_widget.addLegend()
        self.chart_widget.showGrid(x=True, y=True)

        # 创建曲线
        self.force_x_curve = self.chart_widget.plot(
            self.force_history['x'],
            pen=pg.mkPen(color=(255, 0, 0), width=2),
            name='X轴力'
        )

        self.force_y_curve = self.chart_widget.plot(
            self.force_history['y'],
            pen=pg.mkPen(color=(0, 255, 0), width=2),
            name='Y轴力'
        )

        self.force_z_curve = self.chart_widget.plot(
            self.force_history['z'],
            pen=pg.mkPen(color=(0, 0, 255), width=2),
            name='Z轴力'
        )

        self.force_mag_curve = self.chart_widget.plot(
            self.force_history['magnitude'],
            pen=pg.mkPen(color=(255, 255, 0), width=2),
            name='合力'
        )

        main_layout.addWidget(self.chart_widget)

        # 更新定时器
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self._update_display)
        self.update_timer.start(100)  # 10 Hz

    def _paint_force_direction(self, event):
        """绘制力方向可视化"""
        painter = QPainter(self.force_direction_widget)
        painter.setRenderHint(QPainter.Antialiasing)

        width = self.force_direction_widget.width()
        height = self.force_direction_widget.height()

        # 绘制背景
        painter.fillRect(0, 0, width, height, QColor(40, 40, 40))

        # 绘制坐标轴
        center_x = width / 2
        center_y = height / 2
        axis_length = min(width, height) * 0.4

        painter.setPen(QPen(QColor(200, 200, 200), 1))

        # X轴
        painter.drawLine(
            int(center_x - axis_length), int(center_y),
            int(center_x + axis_length), int(center_y)
        )
        painter.drawText(int(center_x + axis_length + 5), int(center_y), "X")

        # Y轴
        painter.drawLine(
            int(center_x), int(center_y - axis_length),
            int(center_x), int(center_y + axis_length)
        )
        painter.drawText(int(center_x), int(center_y - axis_length - 5), "Y")

        # 绘制力向量
        # 标准化XY平面上的向量
        fx = self.force_data['x']
        fy = self.force_data['y']
        fz = self.force_data['z']
        magnitude = self.force_data['magnitude']

        if magnitude > 0:
            # 计算2D方向（XY平面投影）
            length_2d = (fx * fx + fy * fy) ** 0.5

            if length_2d > 0:
                # 正则化为单位向量并乘以力的大小
                scale_factor = min(axis_length, axis_length * magnitude / 10.0)
                dx = (fx / length_2d) * scale_factor
                dy = (fy / length_2d) * scale_factor

                # 绘制线条
                painter.setPen(QPen(QColor(255, 165, 0), 3))
                painter.drawLine(
                    int(center_x), int(center_y),
                    int(center_x + dx), int(center_y - dy)  # 注意Y轴向下为正，所以要取负
                )

                # 绘制箭头
                arrowhead_size = 10
                angle = math.atan2(-dy, dx)  # Y轴向下为正，所以dy取负

                arrow_p1_x = center_x + dx - arrowhead_size * math.cos(angle - math.pi / 6)
                arrow_p1_y = center_y - dy - arrowhead_size * math.sin(angle - math.pi / 6)

                arrow_p2_x = center_x + dx - arrowhead_size * math.cos(angle + math.pi / 6)
                arrow_p2_y = center_y - dy - arrowhead_size * math.sin(angle + math.pi / 6)

                painter.setBrush(QBrush(QColor(255, 165, 0)))

                points = [
                    QPointF(center_x + dx, center_y - dy),
                    QPointF(arrow_p1_x, arrow_p1_y),
                    QPointF(arrow_p2_x, arrow_p2_y)
                ]

                painter.drawPolygon(points)

        # Z轴力表示为透明度变化的圆
        z_circle_radius = 20
        z_opacity = min(1.0, abs(fz) / 10.0)

        if fz > 0:
            # 向上力
            z_color = QColor(0, 255, 255, int(z_opacity * 255))
        else:
            # 向下力
            z_color = QColor(255, 0, 255, int(z_opacity * 255))

        painter.setBrush(QBrush(z_color))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(
            int(center_x - z_circle_radius),
            int(center_y - z_circle_radius),
            z_circle_radius * 2,
            z_circle_radius * 2
        )

    def _update_display(self):
        """更新显示"""
        # 更新力数据标签
        self.force_x_label.setText(f"{self.force_data['x']:.2f} N")
        self.force_y_label.setText(f"{self.force_data['y']:.2f} N")
        self.force_z_label.setText(f"{self.force_data['z']:.2f} N")
        self.force_mag_label.setText(f"{self.force_data['magnitude']:.2f} N")

        # 更新力方向可视化
        self.force_direction_widget.update()

        # 更新图表
        self.force_x_curve.setData(self.force_history['x'])
        self.force_y_curve.setData(self.force_history['y'])
        self.force_z_curve.setData(self.force_history['z'])
        self.force_mag_curve.setData(self.force_history['magnitude'])

    def update_force_data(self, force_data):
        """更新力数据"""
        self.force_data = force_data

        # 更新历史数据
        for key in self.force_history.keys():
            self.force_history[key].append(force_data[key])
            if len(self.force_history[key]) > self.history_length:
                self.force_history[key].pop(0)

        # 更新显示
        self._update_display()


class AdvancedArmControlPanel(QWidget):
    """高级机械臂控制面板"""
    # 定义信号
    jointAngleChanged = pyqtSignal(int, float)  # 关节索引, 角度
    endEffectorMoved = pyqtSignal(float, float, float)  # x, y, z
    visionParamsChanged = pyqtSignal(dict)  # 视觉参数
    presetSelected = pyqtSignal(str)  # 预设名称
    emergencyStop = pyqtSignal()  # 紧急停止

    def __init__(self, parent=None):
        """初始化高级机械臂控制面板"""
        super().__init__(parent)

        # 初始化关节角度
        self.joint_angles = [0.0, 0.0, 0.0, 0.0, 0.0]
        self.joint_limits = [
            (-180, 180),  # 关节1
            (-90, 90),  # 关节2
            (-120, 120),  # 关节3
            (-90, 90),  # 关节4
            (-180, 180)  # 关节5
        ]

        # 初始化末端位置
        self.end_effector_pos = {
            'x': 0.0,
            'y': 0.0,
            'z': 0.0
        }

        # 模拟力反馈数据
        self.force_data = {
            'x': 0.0,
            'y': 0.0,
            'z': 0.0,
            'magnitude': 0.0
        }

        # 初始化UI
        self._init_ui()

        # 启动更新定时器（模拟力反馈）
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self._simulate_forces)
        self.update_timer.start(100)  # 10 Hz

    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 顶部工具栏
        toolbar_layout = QHBoxLayout()

        # 预设按钮
        preset_label = QLabel("操作预设:")
        toolbar_layout.addWidget(preset_label)

        self.preset_combo = QComboBox()
        self.preset_combo.addItems(["默认姿态", "抓取姿态", "观察姿态", "休息姿态"])
        self.preset_combo.currentTextChanged.connect(self._on_preset_selected)
        toolbar_layout.addWidget(self.preset_combo)

        # 添加间隔
        toolbar_layout.addStretch()

        # 紧急停止按钮
        self.stop_btn = QPushButton("紧急停止")
        self.stop_btn.setStyleSheet("""
            background-color: #e74c3c;
            color: white;
            font-weight: bold;
            padding: 8px;
            font-size: 14px;
            border-radius: 5px;
        """)
        self.stop_btn.clicked.connect(self._on_emergency_stop)
        toolbar_layout.addWidget(self.stop_btn)

        main_layout.addLayout(toolbar_layout)

        # 创建标签页
        tab_widget = QTabWidget()

        # 创建关节控制标签页
        joint_tab = QWidget()
        joint_layout = QVBoxLayout(joint_tab)

        # 分割器：左侧关节控制，右侧3D可视化
        joint_splitter = QSplitter(Qt.Horizontal)

        # 左侧关节控制面板
        joint_control_widget = QWidget()
        joint_control_layout = QVBoxLayout(joint_control_widget)

        # 为每个关节创建弧形滑块
        self.joint_sliders = []
        for i in range(len(self.joint_angles)):
            joint_group = QGroupBox(f"关节 {i + 1}")
            joint_slider_layout = QVBoxLayout(joint_group)

            # 弧形滑块
            min_angle, max_angle = self.joint_limits[i]
            arc_slider = ArcSlider(min_angle, max_angle, self.joint_angles[i])
            arc_slider.valueChanged.connect(lambda v, idx=i: self._on_joint_angle_changed(idx, v))
            joint_slider_layout.addWidget(arc_slider)

            self.joint_sliders.append(arc_slider)
            joint_control_layout.addWidget(joint_group)

        # 添加重置按钮
        reset_btn = QPushButton("重置关节角度")
        reset_btn.clicked.connect(self._reset_joint_angles)
        joint_control_layout.addWidget(reset_btn)

        joint_control_layout.addStretch()
        joint_splitter.addWidget(joint_control_widget)

        # 右侧3D可视化
        self.arm_vis = RobotArmGL()
        joint_splitter.addWidget(self.arm_vis)

        # 设置分割器比例
        joint_splitter.setSizes([400, 600])

        joint_layout.addWidget(joint_splitter)
        tab_widget.addTab(joint_tab, "关节控制")

        # 创建视觉控制标签页
        vision_tab = QWidget()
        vision_layout = QVBoxLayout(vision_tab)

        # 视觉处理组件
        self.vision_widget = VisionProcessingWidget()
        self.vision_widget.paramChanged.connect(self._on_vision_params_changed)
        vision_layout.addWidget(self.vision_widget)

        tab_widget.addTab(vision_tab, "视觉边缘识别")

        # 创建力反馈标签页
        force_tab = QWidget()
        force_layout = QVBoxLayout(force_tab)

        # 力可视化组件
        self.force_widget = ForceVisualizerWidget()
        force_layout.addWidget(self.force_widget)

        tab_widget.addTab(force_tab, "力反馈监测")

        main_layout.addWidget(tab_widget)

    def _on_joint_angle_changed(self, joint_idx, angle):
        """关节角度变更处理"""
        # 更新角度
        self.joint_angles[joint_idx] = angle

        # 更新3D可视化
        self.arm_vis.set_joint_angles(self.joint_angles)

        # 发送信号
        self.jointAngleChanged.emit(joint_idx, angle)

    def _on_vision_params_changed(self, params):
        """视觉参数变更处理"""
        self.visionParamsChanged.emit(params)

    def _on_preset_selected(self, preset_name):
        """预设选择处理"""
        # 根据预设名称设置关节角度
        if preset_name == "默认姿态":
            self._set_joint_angles([0.0, 0.0, 0.0, 0.0, 0.0])
        elif preset_name == "抓取姿态":
            self._set_joint_angles([0.0, 45.0, -45.0, 0.0, 0.0])
        elif preset_name == "观察姿态":
            self._set_joint_angles([0.0, 0.0, -90.0, 0.0, 90.0])
        elif preset_name == "休息姿态":
            self._set_joint_angles([0.0, 90.0, 0.0, 0.0, 0.0])

        # 发送信号
        self.presetSelected.emit(preset_name)

    def _on_emergency_stop(self):
        """紧急停止处理"""
        # 重置所有关节
        self._reset_joint_angles()

        # 发送紧急停止信号
        self.emergencyStop.emit()

    def _reset_joint_angles(self):
        """重置关节角度"""
        self._set_joint_angles([0.0, 0.0, 0.0, 0.0, 0.0])

    def _set_joint_angles(self, angles):
        """设置关节角度"""
        # 更新关节角度
        for i, angle in enumerate(angles):
            if i < len(self.joint_angles):
                self.joint_angles[i] = angle
                self.joint_sliders[i].set_value(angle)

        # 更新3D可视化
        self.arm_vis.set_joint_angles(self.joint_angles)

    def _simulate_forces(self):
        """模拟力反馈（仅用于演示）"""
        # 根据关节角度模拟力反馈
        # 实际应用中，这些数据应该从传感器读取
        fx = math.sin(time.time()) * 2.0 + self.joint_angles[0] / 90.0
        fy = math.cos(time.time() * 0.5) * 3.0 + self.joint_angles[1] / 45.0
        fz = math.sin(time.time() * 0.3) * 1.5 + self.joint_angles[2] / 60.0

        # 计算合力
        magnitude = math.sqrt(fx * fx + fy * fy + fz * fz)

        # 更新力数据
        self.force_data = {
            'x': fx,
            'y': fy,
            'z': fz,
            'magnitude': magnitude
        }

        # 更新力可视化
        self.force_widget.update_force_data(self.force_data)

    def set_camera_frame(self, frame):
        """设置摄像头帧"""
        if frame is not None:
            # 转换BGR到RGB (OpenCV使用BGR)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self.vision_widget.set_image(rgb_frame)

    def get_joint_angles(self):
        """获取关节角度"""
        return self.joint_angles.copy()

    def set_force_data(self, force_data):
        """设置力数据"""
        self.force_data = force_data
        self.force_widget.update_force_data(force_data)