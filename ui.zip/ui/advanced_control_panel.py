# ui/advanced_control_panel.py
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                             QGroupBox, QTabWidget, QGridLayout, QComboBox, QSpinBox,
                             QDoubleSpinBox, QSlider, QDial, QRadioButton, QCheckBox, QScrollArea)
from PyQt5.QtCore import Qt, pyqtSignal, QPointF, QRectF, QTimer
from PyQt5.QtGui import QPainter, QColor, QPen, QBrush, QPainterPath, QFont, QLinearGradient
from PyQt5.QtCore import Qt, pyqtSignal, pyqtSlot, QPointF, QRectF, QTimer
from OpenGL.GLUT import *
import sys
class AdvancedSlider(QWidget):
    """高级滑块控件"""
    valueChanged = pyqtSignal(float)

    def __init__(self, min_value=-100, max_value=100, default_value=0, parent=None):
        super().__init__(parent)

        self.min_value = min_value
        self.max_value = max_value
        self.value = default_value
        self.setMinimumSize(200, 40)

        # 刻度标记
        self.tick_interval = (max_value - min_value) / 10
        self.show_ticks = True

        # 滑块属性
        self.handle_width = 10
        self.track_height = 6
        self.pressed = False

        # 配色
        self.handle_color = QColor(52, 152, 219)  # 蓝色
        self.track_color = QColor(189, 195, 199)  # 灰色
        self.filled_color = QColor(41, 128, 185)  # 深蓝

        # 非线性映射 (对数或指数)
        self.nonlinear = False
        self.exponent = 2.0  # 指数因子

    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 绘制轨道
        track_rect = QRectF(
            self.handle_width / 2,
            (self.height() - self.track_height) / 2,
            self.width() - self.handle_width,
            self.track_height
        )

        # 轨道背景
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(self.track_color))
        painter.drawRoundedRect(track_rect, 3, 3)

        # 填充部分
        normalized = (self.value - self.min_value) / (self.max_value - self.min_value)
        filled_width = (self.width() - self.handle_width) * normalized

        filled_rect = QRectF(
            self.handle_width / 2,
            (self.height() - self.track_height) / 2,
            filled_width,
            self.track_height
        )

        painter.setBrush(QBrush(self.filled_color))
        painter.drawRoundedRect(filled_rect, 3, 3)

        # 绘制滑块手柄
        handle_x = self.handle_width / 2 + filled_width - self.handle_width / 2
        handle_rect = QRectF(
            handle_x,
            (self.height() - 2 * self.track_height) / 2,
            self.handle_width,
            2 * self.track_height
        )

        painter.setBrush(QBrush(self.handle_color))
        painter.setPen(QPen(Qt.darkGray, 1))
        painter.drawRoundedRect(handle_rect, 5, 5)

        # 绘制刻度
        if self.show_ticks:
            painter.setPen(QPen(Qt.darkGray, 1))

            for i in range(11):
                tick_value = self.min_value + i * (self.max_value - self.min_value) / 10
                tick_pos = self.handle_width / 2 + (self.width() - self.handle_width) * (
                            tick_value - self.min_value) / (self.max_value - self.min_value)

                # 绘制刻度线
                painter.drawLine(
                    int(tick_pos),
                    int(track_rect.bottom() + 2),
                    int(tick_pos),
                    int(track_rect.bottom() + 5)
                )

                # 绘制刻度值
                if i % 2 == 0:  # 只显示偶数刻度
                    painter.setFont(QFont("Arial", 7))
                    painter.drawText(
                        int(tick_pos - 10),
                        int(track_rect.bottom() + 15),
                        20,
                        10,
                        Qt.AlignCenter,
                        str(int(tick_value))
                    )

        # 绘制当前值
        painter.setFont(QFont("Arial", 8, QFont.Bold))
        painter.setPen(Qt.black)
        painter.drawText(
            0,
            5,
            self.width(),
            15,
            Qt.AlignCenter,
            f"{self.value:.1f}"
        )

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            self.pressed = True
            self._update_value_from_position(event.x())
            self.update()

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if self.pressed:
            self._update_value_from_position(event.x())
            self.update()

    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        if event.button() == Qt.LeftButton and self.pressed:
            self.pressed = False
            self._update_value_from_position(event.x())
            self.update()

    def _update_value_from_position(self, x_pos):
        """从鼠标位置更新值"""
        pos_min = self.handle_width / 2
        pos_max = self.width() - self.handle_width / 2

        # 确保在有效范围内
        pos = max(pos_min, min(x_pos, pos_max))

        # 计算位置的归一化值 (0-1)
        normalized = (pos - pos_min) / (pos_max - pos_min)

        # 应用非线性映射
        if self.nonlinear:
            if self.exponent != 1.0:
                if self.min_value < 0 and self.max_value > 0:
                    # 有正负范围的情况
                    zero_point = -self.min_value / (self.max_value - self.min_value)
                    if normalized < zero_point:
                        # 负值区域
                        normalized_neg = normalized / zero_point
                        normalized = zero_point * pow(normalized_neg, self.exponent)
                    else:
                        # 正值区域
                        normalized_pos = (normalized - zero_point) / (1 - zero_point)
                        normalized = zero_point + (1 - zero_point) * pow(normalized_pos, self.exponent)
                else:
                    # 只有正值或只有负值
                    normalized = pow(normalized, self.exponent)

        # 计算实际值
        new_value = self.min_value + normalized * (self.max_value - self.min_value)

        # 更新值并发送信号
        if new_value != self.value:
            self.value = new_value
            self.valueChanged.emit(new_value)

    def set_value(self, value):
        """设置滑块值"""
        value = max(self.min_value, min(value, self.max_value))
        if value != self.value:
            self.value = value
            self.update()
            self.valueChanged.emit(value)

    def set_range(self, min_value, max_value):
        """设置滑块范围"""
        if min_value >= max_value:
            return

        self.min_value = min_value
        self.max_value = max_value

        # 确保当前值在新范围内
        self.value = max(min_value, min(self.value, max_value))
        self.update()

    def set_nonlinear(self, nonlinear, exponent=2.0):
        """设置非线性模式"""
        self.nonlinear = nonlinear
        self.exponent = exponent
        self.update()


class TouchPad(QWidget):
    """触控板控件"""
    positionChanged = pyqtSignal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(200, 200)

        # 位置
        self.x_value = 0.0
        self.y_value = 0.0

        # 状态
        self.pressed = False

        # 样式设置
        self.bg_color = QColor(44, 62, 80)
        self.grid_color = QColor(52, 73, 94)
        self.handle_color = QColor(46, 204, 113)
        self.border_color = QColor(52, 152, 219)

    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 计算区域
        pad_rect = self._get_pad_rect()

        # 绘制背景
        painter.setPen(QPen(self.border_color, 2))
        painter.setBrush(QBrush(self.bg_color))
        painter.drawRoundedRect(pad_rect, 5, 5)

        # 绘制网格
        painter.setPen(QPen(self.grid_color, 1, Qt.DotLine))

        # 水平线
        for i in range(1, 5):
            y = pad_rect.top() + pad_rect.height() * i / 5
            painter.drawLine(
                int(pad_rect.left()),
                int(y),
                int(pad_rect.right()),
                int(y)
            )

        # 垂直线
        for i in range(1, 5):
            x = pad_rect.left() + pad_rect.width() * i / 5
            painter.drawLine(
                int(x),
                int(pad_rect.top()),
                int(x),
                int(pad_rect.bottom())
            )

        # 绘制中心线
        painter.setPen(QPen(self.grid_color, 2))
        painter.drawLine(
            int(pad_rect.left()),
            int(pad_rect.center().y()),
            int(pad_rect.right()),
            int(pad_rect.center().y())
        )
        painter.drawLine(
            int(pad_rect.center().x()),
            int(pad_rect.top()),
            int(pad_rect.center().x()),
            int(pad_rect.bottom())
        )

        # 计算手柄位置
        handle_x = pad_rect.center().x() + self.x_value * pad_rect.width() / 2
        handle_y = pad_rect.center().y() - self.y_value * pad_rect.height() / 2

        # 绘制手柄
        painter.setPen(QPen(Qt.black, 1))
        painter.setBrush(QBrush(self.handle_color))
        painter.drawEllipse(QPointF(handle_x, handle_y), 10, 10)

        # 绘制坐标值
        painter.setFont(QFont("Arial", 8))
        painter.setPen(Qt.white)
        painter.drawText(
            pad_rect.adjusted(5, 5, -5, -25),
            Qt.AlignLeft | Qt.AlignBottom,
            f"X: {self.x_value:.2f}"
        )
        painter.drawText(
            pad_rect.adjusted(5, 5, -5, -25),
            Qt.AlignRight | Qt.AlignBottom,
            f"Y: {self.y_value:.2f}"
        )

    def _get_pad_rect(self):
        """获取触控板区域"""
        size = min(self.width(), self.height()) - 10
        return QRectF(
            (self.width() - size) / 2,
            (self.height() - size) / 2,
            size,
            size
        )

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            pad_rect = self._get_pad_rect()
            if pad_rect.contains(event.pos()):
                self.pressed = True
                self._update_values_from_position(event.pos())

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if self.pressed:
            self._update_values_from_position(event.pos())

    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        if event.button() == Qt.LeftButton and self.pressed:
            self.pressed = False
            # 释放时回到中心
            self.x_value = 0.0
            self.y_value = 0.0
            self.update()
            self.positionChanged.emit(self.x_value, self.y_value)

    def _update_values_from_position(self, pos):
        """从鼠标位置更新值"""
        pad_rect = self._get_pad_rect()

        # 计算相对于中心的位置
        x_pos = pos.x() - pad_rect.center().x()
        y_pos = pad_rect.center().y() - pos.y()  # 反转Y轴，向上为正

        # 归一化为[-1, 1]范围
        x_value = x_pos / (pad_rect.width() / 2)
        y_value = y_pos / (pad_rect.height() / 2)

        # 限制在圆形区域内
        distance = (x_value * x_value + y_value * y_value) ** 0.5
        if distance > 1.0:
            x_value /= distance
            y_value /= distance

        # 更新值并发送信号
        if x_value != self.x_value or y_value != self.y_value:
            self.x_value = x_value
            self.y_value = y_value
            self.update()
            self.positionChanged.emit(x_value, y_value)

    def set_position(self, x, y):
        """设置位置 (外部调用)"""
        # 限制在[-1, 1]范围内
        x = max(-1.0, min(x, 1.0))
        y = max(-1.0, min(y, 1.0))

        # 限制在圆形区域内
        distance = (x * x + y * y) ** 0.5
        if distance > 1.0:
            x /= distance
            y /= distance

        if x != self.x_value or y != self.y_value:
            self.x_value = x
            self.y_value = y
            self.update()


# 完成并增强控制模式选择器
class ControlModeSelector(QWidget):
    """控制模式选择器"""
    modeChanged = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(400, 80)

        self.modes = {
            "water": {
                "name": "水中运动模式",
                "description": "全方位操控水下机器人",
                "color": QColor(41, 128, 185),  # 蓝色
                "key": "Y按键"
            },
            "walk": {
                "name": "行走模式",
                "description": "使用履带进行陆地行走",
                "color": QColor(39, 174, 96),  # 绿色
                "key": "X按键"
            },
            "seedling": {
                "name": "育苗模式",
                "description": "精确控制上下移动",
                "color": QColor(142, 68, 173),  # 紫色
                "key": "A按键"
            },
            "transplant": {
                "name": "移植模式",
                "description": "控制移植机构",
                "color": QColor(230, 126, 34),  # 橙色
                "key": "B按键"
            }
        }

        self.current_mode = "water"
        self.hover_mode = None
        self.buttons = {}

        # 创建布局
        self.layout = QHBoxLayout(self)
        self.layout.setSpacing(10)

        # 创建模式按钮
        for mode_id, mode_info in self.modes.items():
            button = QPushButton(mode_info["name"])
            button.setCheckable(True)
            button.setMinimumHeight(60)
            button.setProperty("mode", mode_id)
            button.clicked.connect(self._on_button_clicked)

            # 样式表
            button.setStyleSheet(f"""
                QPushButton {{
                    background-color: {mode_info["color"].name()};
                    color: white;
                    border: none;
                    border-radius: 5px;
                    padding: 8px;
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: {mode_info["color"].lighter(110).name()};
                }}
                QPushButton:checked {{
                    background-color: {mode_info["color"].darker(120).name()};
                    border: 2px solid white;
                }}
            """)

            # 添加键盘快捷键标签
            key_label = QLabel(mode_info["key"])
            key_label.setAlignment(Qt.AlignCenter)
            key_label.setStyleSheet("""
                background-color: rgba(0, 0, 0, 120);
                color: white;
                border-radius: 3px;
                padding: 2px;
                font-size: 8pt;
            """)

            # 创建按钮容器
            button_container = QWidget()
            button_layout = QVBoxLayout(button_container)
            button_layout.setContentsMargins(0, 0, 0, 0)
            button_layout.addWidget(button)
            button_layout.addWidget(key_label)

            self.layout.addWidget(button_container)
            self.buttons[mode_id] = button

        # 设置初始模式
        self.set_mode("water")

        # 创建定时器用于闪烁效果
        self.blink_timer = QTimer(self)
        self.blink_timer.timeout.connect(self._update_blink)
        self.blink_timer.start(500)  # 每500毫秒闪烁一次
        self.blink_state = False

    def set_mode(self, mode):
        """设置当前模式"""
        if mode in self.modes:
            old_mode = self.current_mode
            self.current_mode = mode

            # 更新按钮状态
            for mode_id, button in self.buttons.items():
                button.setChecked(mode_id == mode)

            # 发送模式改变信号
            if old_mode != mode:
                self.modeChanged.emit(mode)

            return True
        return False

    def _on_button_clicked(self):
        """按钮点击事件"""
        button = self.sender()
        mode = button.property("mode")
        if mode:
            self.set_mode(mode)

    def _update_blink(self):
        """更新闪烁效果"""
        self.blink_state = not self.blink_state

        # 如果有手柄操作切换了模式，闪烁该模式按钮
        if hasattr(self, 'last_mode_change') and self.last_mode_change:
            mode = self.last_mode_change
            button = self.buttons.get(mode)

            if button and self.blink_state:
                button.setStyleSheet(f"""
                    QPushButton {{
                        background-color: white;
                        color: {self.modes[mode]["color"].name()};
                        border: 2px solid {self.modes[mode]["color"].name()};
                        border-radius: 5px;
                        padding: 8px;
                        font-weight: bold;
                    }}
                """)
            else:
                # 恢复正常样式
                button.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {self.modes[mode]["color"].name()};
                        color: white;
                        border: none;
                        border-radius: 5px;
                        padding: 8px;
                        font-weight: bold;
                    }}
                    QPushButton:hover {{
                        background-color: {self.modes[mode]["color"].lighter(110).name()};
                    }}
                    QPushButton:checked {{
                        background-color: {self.modes[mode]["color"].darker(120).name()};
                        border: 2px solid white;
                    }}
                """)

            # 3秒后停止闪烁
            if hasattr(self, 'blink_counter'):
                self.blink_counter += 1
                if self.blink_counter > 6:  # 3秒 (6次500ms)
                    self.last_mode_change = None
                    self.blink_counter = 0
            else:
                self.blink_counter = 0

        self.update()

    def highlight_mode_change(self, mode):
        """高亮显示模式变化（由手柄触发）"""
        if mode in self.modes:
            self.last_mode_change = mode
            self.blink_counter = 0
            self.blink_state = True
            self._update_blink()


# 新增：手柄状态显示组件
class JoystickStatusWidget(QWidget):
    """手柄状态显示组件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(320, 240)

        # 手柄状态
        self.connected = False
        self.joystick_name = ""
        self.axes_data = {}
        self.button_states = {}
        self.current_mode = "water"
        self.special_features = {
            "auto_depth": False,
            "auto_heading": False,
            "precision": False,
            "special_mode": False
        }

        # Xbox按钮布局
        self.button_positions = {
            "A": (160, 180),
            "B": (190, 150),
            "X": (130, 150),
            "Y": (160, 120),
            "LB": (90, 90),
            "RB": (230, 90),
            "Back": (120, 110),
            "Start": (200, 110),
            "Home": (160, 110),
            "L3": (90, 150),
            "R3": (230, 150),
            "DPad_Up": (90, 170),
            "DPad_Down": (90, 210),
            "DPad_Left": (70, 190),
            "DPad_Right": (110, 190)
        }

        # 创建更新定时器
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update)
        self.update_timer.start(50)  # 20fps

        # 功能映射显示
        self.function_mappings = {
            "Y": "水中模式",
            "B": "移植模式",
            "X": "行走模式",
            "A": "育苗模式",
            "DPad_Up": "挤胶水",
            "DPad_Down": "特技模式",
            "DPad_Left": "钥匙杆顺旋",
            "DPad_Right": "钥匙杆逆旋",
            "LB+DPad_Up": "预设位置1",
            "LB+DPad_Down": "预设位置2",
            "LB+DPad_Left": "预设位置3",
            "LB+DPad_Right": "预设位置4",
            "RB+DPad_Up": "自定动作1",
            "RB+DPad_Down": "自定动作2",
            "RB+DPad_Left": "自定动作3",
            "RB+DPad_Right": "自定动作4",
            "L3": "深度保持",
            "R3": "精确模式",
            "Back": "切换摄像头",
            "Start": "系统菜单",
            "LB+RB": "紧急停止"
        }

        # 按钮颜色
        self.button_colors = {
            "A": QColor(0, 185, 0),  # 绿色
            "B": QColor(230, 0, 0),  # 红色
            "X": QColor(0, 100, 230),  # 蓝色
            "Y": QColor(230, 230, 0),  # 黄色
            "LB": QColor(128, 128, 128),
            "RB": QColor(128, 128, 128),
            "Back": QColor(128, 128, 128),
            "Start": QColor(128, 128, 128),
            "Home": QColor(20, 180, 20),
            "L3": QColor(64, 64, 64),
            "R3": QColor(64, 64, 64),
            "DPad_Up": QColor(200, 200, 200),
            "DPad_Down": QColor(200, 200, 200),
            "DPad_Left": QColor(200, 200, 200),
            "DPad_Right": QColor(200, 200, 200)
        }

    def update_joystick_data(self, data):
        """更新手柄数据"""
        self.connected = True
        self.joystick_name = data.get("joystick_name", "Xbox Controller")
        self.axes_data = data.get("axes", {})
        self.button_states = data.get("buttons", {})
        self.current_mode = data.get("mode", "water")

        # 更新特殊功能状态
        self.special_features["auto_depth"] = data.get("auto_depth", False)
        self.special_features["auto_heading"] = data.get("auto_heading", False)
        self.special_features["precision"] = data.get("precision", False)
        self.special_features["special_mode"] = data.get("special_mode", False)

        self.update()

    def set_connected(self, connected, name=""):
        """设置连接状态"""
        self.connected = connected
        self.joystick_name = name
        self.update()

    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 绘制背景
        background_rect = self.rect()
        if self.connected:
            bg_color = QColor(44, 62, 80)  # 深蓝色背景
        else:
            bg_color = QColor(150, 40, 40)  # 红色背景表示未连接

        painter.fillRect(background_rect, bg_color)

        # 未连接状态显示
        if not self.connected:
            painter.setPen(Qt.white)
            painter.setFont(QFont("Arial", 12, QFont.Bold))
            painter.drawText(background_rect, Qt.AlignCenter, "手柄未连接")
            return

        # 绘制手柄轮廓
        self._draw_controller_outline(painter)

        # 绘制按钮和状态
        self._draw_buttons(painter)

        # 绘制摇杆状态
        self._draw_joysticks(painter)

        # 绘制模式和特殊功能状态
        self._draw_mode_status(painter)

        # 绘制手柄名称
        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 9))
        painter.drawText(10, 20, self.joystick_name)

    def _draw_controller_outline(self, painter):
        """绘制手柄轮廓"""
        painter.setPen(QPen(QColor(100, 100, 100), 2))
        painter.setBrush(Qt.NoBrush)

        # 简化的手柄轮廓
        path = QPainterPath()
        path.moveTo(70, 70)
        path.lineTo(250, 70)
        path.arcTo(220, 70, 60, 60, 90, -180)
        path.lineTo(70, 130)
        path.arcTo(40, 70, 60, 60, 270, -180)
        path.closeSubpath()

        painter.drawPath(path)

    def _draw_buttons(self, painter):
        """绘制按钮状态"""
        for button_name, pos in self.button_positions.items():
            # 设置按钮颜色
            color = self.button_colors.get(button_name, QColor(150, 150, 150))

            # 如果按钮被按下，使用更亮的颜色
            pressed = self.button_states.get(button_name, False)
            if pressed:
                color = color.lighter(150)

            painter.setPen(Qt.black)
            painter.setBrush(QBrush(color))

            # 绘制按钮
            if button_name in ["A", "B", "X", "Y"]:
                # 大圆形按钮
                painter.drawEllipse(QPointF(pos[0], pos[1]), 15, 15)
            elif button_name.startswith("DPad_"):
                # 方向键
                dpad_center = (90, 190)
                if button_name == "DPad_Up":
                    painter.drawPolygon([
                        QPointF(dpad_center[0], dpad_center[1] - 20),
                        QPointF(dpad_center[0] - 10, dpad_center[1] - 5),
                        QPointF(dpad_center[0] + 10, dpad_center[1] - 5)
                    ])
                elif button_name == "DPad_Down":
                    painter.drawPolygon([
                        QPointF(dpad_center[0], dpad_center[1] + 20),
                        QPointF(dpad_center[0] - 10, dpad_center[1] + 5),
                        QPointF(dpad_center[0] + 10, dpad_center[1] + 5)
                    ])
                elif button_name == "DPad_Left":
                    painter.drawPolygon([
                        QPointF(dpad_center[0] - 20, dpad_center[1]),
                        QPointF(dpad_center[0] - 5, dpad_center[1] - 10),
                        QPointF(dpad_center[0] - 5, dpad_center[1] + 10)
                    ])
                elif button_name == "DPad_Right":
                    painter.drawPolygon([
                        QPointF(dpad_center[0] + 20, dpad_center[1]),
                        QPointF(dpad_center[0] + 5, dpad_center[1] - 10),
                        QPointF(dpad_center[0] + 5, dpad_center[1] + 10)
                    ])
            else:
                # 其他按钮为小矩形
                painter.drawRoundedRect(pos[0] - 10, pos[1] - 5, 20, 10, 3, 3)

            # 绘制按钮名
            painter.setPen(Qt.white)
            painter.setFont(QFont("Arial", 7))
            text_rect = QRectF(pos[0] - 12, pos[1] - 12, 24, 24)
            painter.drawText(text_rect, Qt.AlignCenter, button_name.replace("DPad_", ""))

    def _draw_joysticks(self, painter):
        """绘制摇杆状态"""
        # 左摇杆
        left_center = QPointF(90, 150)
        left_x = self.axes_data.get("LX", 0.0)
        left_y = self.axes_data.get("LY", 0.0)

        # 右摇杆
        right_center = QPointF(230, 150)
        right_x = self.axes_data.get("RX", 0.0)
        right_y = self.axes_data.get("RY", 0.0)

        # 绘制摇杆底座
        painter.setPen(QPen(Qt.darkGray, 1))
        painter.setBrush(QBrush(QColor(30, 30, 30)))
        painter.drawEllipse(left_center, 20, 20)
        painter.drawEllipse(right_center, 20, 20)

        # 绘制摇杆位置
        painter.setPen(QPen(Qt.black, 1))
        painter.setBrush(QBrush(QColor(200, 200, 200)))

        # 计算摇杆位置
        left_pos = QPointF(left_center.x() + left_x * 15, left_center.y() + left_y * 15)
        right_pos = QPointF(right_center.x() + right_x * 15, right_center.y() + right_y * 15)

        painter.drawEllipse(left_pos, 10, 10)
        painter.drawEllipse(right_pos, 10, 10)

        # 绘制扳机状态
        lt_value = (self.axes_data.get("LT", 0.0) + 1.0) / 2.0  # 转换为0-1
        rt_value = (self.axes_data.get("RT", 0.0) + 1.0) / 2.0

        # LT
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(100, 100, 150)))
        painter.drawRect(60, 80, 30, 5)
        painter.setBrush(QBrush(QColor(100, 150, 250)))
        painter.drawRect(60, 80, int(30 * lt_value), 5)

        # RT
        painter.setBrush(QBrush(QColor(150, 100, 100)))
        painter.drawRect(230, 80, 30, 5)
        painter.setBrush(QBrush(QColor(250, 100, 100)))
        painter.drawRect(230, 80, int(30 * rt_value), 5)

    def _draw_mode_status(self, painter):
        """绘制模式和特殊功能状态"""
        # 模式颜色映射
        mode_colors = {
            "water": QColor(41, 128, 185),
            "walk": QColor(39, 174, 96),
            "seedling": QColor(142, 68, 173),
            "transplant": QColor(230, 126, 34)
        }

        # 绘制当前模式
        mode_color = mode_colors.get(self.current_mode, QColor(100, 100, 100))
        painter.setPen(QPen(mode_color, 2))
        painter.setBrush(QBrush(mode_color.darker(150)))

        mode_rect = QRectF(10, 30, 300, 30)
        painter.drawRoundedRect(mode_rect, 5, 5)

        # 绘制模式文本
        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 10, QFont.Bold))

        mode_names = {
            "water": "水中运动模式",
            "walk": "行走模式",
            "seedling": "育苗模式",
            "transplant": "移植模式"
        }

        mode_name = mode_names.get(self.current_mode, "未知模式")
        painter.drawText(mode_rect, Qt.AlignCenter, mode_name)

        # 绘制特殊功能状态
        y_pos = 210
        for feature, enabled in self.special_features.items():
            feature_names = {
                "auto_depth": "自动深度",
                "auto_heading": "自动航向",
                "precision": "精确模式",
                "special_mode": "特技模式"
            }

            feature_name = feature_names.get(feature, feature)

            if enabled:
                painter.setPen(Qt.white)
                indicator_color = QColor(46, 204, 113)
            else:
                painter.setPen(QColor(180, 180, 180))
                indicator_color = QColor(100, 100, 100)

            painter.setFont(QFont("Arial", 8))
            painter.drawText(200, y_pos, feature_name)

            # 绘制状态指示器
            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(indicator_color))
            painter.drawEllipse(280, y_pos - 8, 10, 10)

            y_pos += 15


# 手柄功能映射面板
class JoystickMappingPanel(QWidget):
    """手柄功能映射显示面板"""

    def __init__(self, parent=None):
        super().__init__(parent)

        self.layout = QVBoxLayout(self)

        # 标题
        title_label = QLabel("Xbox手柄功能映射")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-size: 14pt; font-weight: bold; margin-bottom: 10px;")
        self.layout.addWidget(title_label)

        # 创建映射表
        self.mapping_grid = QGridLayout()
        self.mapping_grid.setSpacing(5)

        # 添加表头
        self.mapping_grid.addWidget(self._create_header("按键"), 0, 0)
        self.mapping_grid.addWidget(self._create_header("功能"), 0, 1)
        self.mapping_grid.addWidget(self._create_header("模式"), 0, 2)

        # 填充映射表
        self._populate_mapping_table()

        # 创建一个滚动区域容器
        scroll_widget = QWidget()
        scroll_widget.setLayout(self.mapping_grid)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(scroll_widget)

        self.layout.addWidget(scroll_area)

    def _create_header(self, text):
        """创建表头标签"""
        label = QLabel(text)
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet("font-weight: bold; background-color: #3498db; color: white; padding: 5px;")
        return label

    def _populate_mapping_table(self):
        """填充映射表"""
        mappings = [
            # 模式切换
            {"button": "Y", "function": "水中运动模式", "mode": "全局"},
            {"button": "X", "function": "行走模式", "mode": "全局"},
            {"button": "A", "function": "育苗模式", "mode": "全局"},
            {"button": "B", "function": "移植模式", "mode": "全局"},

            # 方向键
            {"button": "方向键上", "function": "挤胶水", "mode": "全局"},
            {"button": "方向键下", "function": "特技模式切换", "mode": "全局"},
            {"button": "方向键左", "function": "钥匙杆顺时针旋转", "mode": "全局"},
            {"button": "方向键右", "function": "钥匙杆逆时针旋转", "mode": "全局"},

            # 预设位置
            {"button": "LB + 方向键上", "function": "预设位置1", "mode": "全局"},
            {"button": "LB + 方向键下", "function": "预设位置2", "mode": "全局"},
            {"button": "LB + 方向键左", "function": "预设位置3", "mode": "全局"},
            {"button": "LB + 方向键右", "function": "预设位置4", "mode": "全局"},

            # 自定义动作
            {"button": "RB + 方向键上", "function": "自定义动作1", "mode": "全局"},
            {"button": "RB + 方向键下", "function": "自定义动作2", "mode": "全局"},
            {"button": "RB + 方向键左", "function": "自定义动作3", "mode": "全局"},
            {"button": "RB + 方向键右", "function": "自定义动作4", "mode": "全局"},

            # 特殊功能
            {"button": "L3", "function": "自动深度保持", "mode": "水中"},
            {"button": "R3", "function": "精细操作模式", "mode": "全局"},
            {"button": "LB + RB", "function": "紧急停止", "mode": "全局"},
            {"button": "Back", "function": "切换摄像头", "mode": "全局"},
            {"button": "Start", "function": "系统菜单", "mode": "全局"},

            # 左右摇杆
            {"button": "左摇杆", "function": "移动控制", "mode": "全部"},
            {"button": "右摇杆", "function": "方向/姿态控制", "mode": "全部"},
            {"button": "LT", "function": "下降", "mode": "水中/育苗"},
            {"button": "RT", "function": "上升", "mode": "水中/育苗"},
        ]

        row = 1
        for mapping in mappings:
            # 按钮单元格
            button_cell = QLabel(mapping["button"])
            button_cell.setAlignment(Qt.AlignCenter)
            button_cell.setStyleSheet("padding: 5px; border-bottom: 1px solid #ddd; font-weight: bold;")

            # 功能单元格
            function_cell = QLabel(mapping["function"])
            function_cell.setAlignment(Qt.AlignCenter)
            function_cell.setStyleSheet("padding: 5px; border-bottom: 1px solid #ddd;")

            # 模式单元格
            mode_cell = QLabel(mapping["mode"])
            mode_cell.setAlignment(Qt.AlignCenter)
            mode_cell.setStyleSheet("padding: 5px; border-bottom: 1px solid #ddd;")

            # 交替行背景色
            if row % 2 == 0:
                style = "background-color: rgba(230, 230, 230, 100);"
                button_cell.setStyleSheet(button_cell.styleSheet() + style)
                function_cell.setStyleSheet(function_cell.styleSheet() + style)
                mode_cell.setStyleSheet(mode_cell.styleSheet() + style)

            self.mapping_grid.addWidget(button_cell, row, 0)
            self.mapping_grid.addWidget(function_cell, row, 1)
            self.mapping_grid.addWidget(mode_cell, row, 2)

            row += 1


# 控制面板主类
class AdvancedControlPanel(QWidget):
    """高级控制面板"""
    # 重命名信号以匹配原始控制面板
    control_mode_changed = pyqtSignal(str)  # 原来是modeChanged
    manual_control_updated = pyqtSignal(dict)  # 原来是controlValueChanged
    emergency_stop = pyqtSignal()  # 添加这个信号

    # 保留其他信号用于高级功能
    controlValueChanged = pyqtSignal(str, float)
    controlPositionChanged = pyqtSignal(str, float, float)
    commandExecuted = pyqtSignal(str, dict)

    def __init__(self, robot_controller=None, joystick=None, parent=None):
        """
        初始化高级控制面板

        Args:
            robot_controller: 机器人控制器对象
            joystick: 手柄控制器对象
            parent: 父组件
        """
        super().__init__(parent)
        self.robot = robot_controller
        self.joystick = joystick

        # 当前模式
        self.current_mode = "water"

        # 初始化UI
        self._init_ui()

    def _init_ui(self):
        """初始化UI"""
        main_layout = QVBoxLayout(self)

        # 控制模式选择器 - 使用增强版的选择器
        self.mode_selector = ControlModeSelector()
        self.mode_selector.modeChanged.connect(self._on_mode_changed)
        main_layout.addWidget(self.mode_selector)

        # 创建标签页控件
        tab_widget = QTabWidget()

        # 基本控制标签页
        basic_tab = QWidget()
        basic_layout = QVBoxLayout(basic_tab)

        # 触控板控制
        touch_group = QGroupBox("触控操控")
        touch_layout = QHBoxLayout(touch_group)

        # 左侧触控板 (前进/转向)
        left_layout = QVBoxLayout()
        left_layout.addWidget(QLabel("前进/转向"))
        self.left_touchpad = TouchPad()
        self.left_touchpad.positionChanged.connect(lambda x, y: self._on_touchpad_moved("movement", x, y))
        left_layout.addWidget(self.left_touchpad)
        touch_layout.addLayout(left_layout)

        # 右侧触控板 (垂直/俯仰)
        right_layout = QVBoxLayout()
        right_layout.addWidget(QLabel("垂直/俯仰"))
        self.right_touchpad = TouchPad()
        self.right_touchpad.positionChanged.connect(lambda x, y: self._on_touchpad_moved("altitude", x, y))
        right_layout.addWidget(self.right_touchpad)
        touch_layout.addLayout(right_layout)

        basic_layout.addWidget(touch_group)

        # 滑块控制
        slider_group = QGroupBox("精确控制")
        slider_layout = QGridLayout(slider_group)

        # 前进滑块
        slider_layout.addWidget(QLabel("前进/后退:"), 0, 0)
        self.forward_slider = AdvancedSlider(-100, 100, 0)
        self.forward_slider.valueChanged.connect(lambda v: self._on_slider_changed("forward", v))
        slider_layout.addWidget(self.forward_slider, 0, 1)

        # 左右滑块
        slider_layout.addWidget(QLabel("左右平移:"), 1, 0)
        self.lateral_slider = AdvancedSlider(-100, 100, 0)
        self.lateral_slider.valueChanged.connect(lambda v: self._on_slider_changed("lateral", v))
        slider_layout.addWidget(self.lateral_slider, 1, 1)

        # 垂直滑块
        slider_layout.addWidget(QLabel("上浮/下潜:"), 2, 0)
        self.vertical_slider = AdvancedSlider(-100, 100, 0)
        self.vertical_slider.valueChanged.connect(lambda v: self._on_slider_changed("vertical", v))
        slider_layout.addWidget(self.vertical_slider, 2, 1)

        # 偏航滑块
        slider_layout.addWidget(QLabel("偏航控制:"), 3, 0)
        self.yaw_slider = AdvancedSlider(-100, 100, 0)
        self.yaw_slider.valueChanged.connect(lambda v: self._on_slider_changed("yaw", v))
        slider_layout.addWidget(self.yaw_slider, 3, 1)

        basic_layout.addWidget(slider_group)

        # 添加手柄状态显示
        joystick_group = QGroupBox("手柄状态")
        joystick_layout = QVBoxLayout(joystick_group)

        self.joystick_status = JoystickStatusWidget()
        joystick_layout.addWidget(self.joystick_status)

        basic_layout.addWidget(joystick_group)

        # 创建高级标签页
        advanced_tab = QWidget()
        advanced_layout = QVBoxLayout(advanced_tab)

        # PID设置组
        pid_group = QGroupBox("PID控制参数")
        pid_layout = QGridLayout(pid_group)

        # 控制器选择
        pid_layout.addWidget(QLabel("控制器:"), 0, 0)
        self.controller_combo = QComboBox()
        self.controller_combo.addItems(["深度控制", "航向控制", "俯仰控制", "横滚控制"])
        pid_layout.addWidget(self.controller_combo, 0, 1, 1, 2)

        # Kp
        pid_layout.addWidget(QLabel("Kp:"), 1, 0)
        self.kp_spin = QDoubleSpinBox()
        self.kp_spin.setRange(0.0, 10.0)
        self.kp_spin.setSingleStep(0.1)
        self.kp_spin.setValue(1.0)
        pid_layout.addWidget(self.kp_spin, 1, 1)

        self.kp_slider = QSlider(Qt.Horizontal)
        self.kp_slider.setRange(0, 100)
        self.kp_slider.setValue(10)
        pid_layout.addWidget(self.kp_slider, 1, 2)

        # Ki
        pid_layout.addWidget(QLabel("Ki:"), 2, 0)
        self.ki_spin = QDoubleSpinBox()
        self.ki_spin.setRange(0.0, 10.0)
        self.ki_spin.setSingleStep(0.01)
        self.ki_spin.setValue(0.1)
        pid_layout.addWidget(self.ki_spin, 2, 1)

        self.ki_slider = QSlider(Qt.Horizontal)
        self.ki_slider.setRange(0, 100)
        self.ki_slider.setValue(10)
        pid_layout.addWidget(self.ki_slider, 2, 2)

        # Kd
        pid_layout.addWidget(QLabel("Kd:"), 3, 0)
        self.kd_spin = QDoubleSpinBox()
        self.kd_spin.setRange(0.0, 10.0)
        self.kd_spin.setSingleStep(0.01)
        self.kd_spin.setValue(0.05)
        pid_layout.addWidget(self.kd_spin, 3, 1)

        self.kd_slider = QSlider(Qt.Horizontal)
        self.kd_slider.setRange(0, 100)
        self.kd_slider.setValue(5)
        pid_layout.addWidget(self.kd_slider, 3, 2)

        # 应用按钮
        pid_layout.addWidget(QLabel(""), 4, 0)
        self.apply_pid_btn = QPushButton("应用参数")
        self.apply_pid_btn.clicked.connect(self._on_apply_pid)
        pid_layout.addWidget(self.apply_pid_btn, 4, 1, 1, 2)

        advanced_layout.addWidget(pid_group)

        # 目标设定组
        target_group = QGroupBox("目标设定")
        target_layout = QGridLayout(target_group)

        # 深度目标
        target_layout.addWidget(QLabel("目标深度:"), 0, 0)
        self.depth_target = QDoubleSpinBox()
        self.depth_target.setRange(0.0, 100.0)
        self.depth_target.setSingleStep(0.1)
        self.depth_target.setValue(1.0)
        self.depth_target.setSuffix(" m")
        target_layout.addWidget(self.depth_target, 0, 1)

        # 航向目标
        target_layout.addWidget(QLabel("目标航向:"), 1, 0)
        self.heading_target = QDoubleSpinBox()
        self.heading_target.setRange(0.0, 359.9)
        self.heading_target.setSingleStep(1.0)
        self.heading_target.setValue(0.0)
        self.heading_target.setSuffix(" °")
        target_layout.addWidget(self.heading_target, 1, 1)

        # 目标设定按钮
        self.set_target_btn = QPushButton("设置目标")
        self.set_target_btn.clicked.connect(self._on_set_target)
        target_layout.addWidget(self.set_target_btn, 2, 0, 1, 2)

        advanced_layout.addWidget(target_group)

        # 添加手柄功能映射面板
        mapping_group = QGroupBox("Xbox手柄功能映射")
        mapping_layout = QVBoxLayout(mapping_group)

        self.mapping_panel = JoystickMappingPanel()
        mapping_layout.addWidget(self.mapping_panel)

        advanced_layout.addWidget(mapping_group)

        # 添加标签页
        tab_widget.addTab(basic_tab, "基本控制")
        tab_widget.addTab(advanced_tab, "高级设置")
        main_layout.addWidget(tab_widget)

        # 紧急停止按钮
        self.stop_btn = QPushButton("紧急停止")
        self.stop_btn.setStyleSheet("""
            background-color: #e74c3c;
            color: white;
            font-weight: bold;
            padding: 10px;
            font-size: 14px;
            border-radius: 5px;
        """)
        self.stop_btn.clicked.connect(self._on_emergency_stop)
        main_layout.addWidget(self.stop_btn)

        # 连接滑块与微调框
        self.kp_slider.valueChanged.connect(lambda v: self.kp_spin.setValue(v / 10.0))
        self.kp_spin.valueChanged.connect(lambda v: self.kp_slider.setValue(int(v * 10)))

        self.ki_slider.valueChanged.connect(lambda v: self.ki_spin.setValue(v / 10.0))
        self.ki_spin.valueChanged.connect(lambda v: self.ki_slider.setValue(int(v * 10)))

        self.kd_slider.valueChanged.connect(lambda v: self.kd_spin.setValue(v / 10.0))
        self.kd_spin.valueChanged.connect(lambda v: self.kd_slider.setValue(int(v * 10)))

    def _on_touchpad_moved(self, pad_name, x, y):
        """触控板移动事件处理"""
        self.controlPositionChanged.emit(pad_name, x, y)

        # 更新相应滑块
        if pad_name == "movement":
            self.forward_slider.set_value(y * 100)
            self.lateral_slider.set_value(x * 100)
        elif pad_name == "altitude":
            self.vertical_slider.set_value(y * 100)
            self.yaw_slider.set_value(x * 100)

        # 构建手动控制数据并发送兼容信号
        manual_controls = {
            "forward": self.forward_slider.value / 100.0,
            "lateral": self.lateral_slider.value / 100.0,
            "vertical": self.vertical_slider.value / 100.0,
            "yaw": self.yaw_slider.value / 100.0,
            "pitch": 0.0,
            "roll": 0.0
        }
        self.manual_control_updated.emit(manual_controls)

    def _on_slider_changed(self, slider_name, value):
        """滑块变化事件处理"""
        self.controlValueChanged.emit(slider_name, value)

        # 更新相应触控板
        if slider_name == "forward":
            x = self.left_touchpad.x_value
            y = value / 100.0
            self.left_touchpad.set_position(x, y)
        elif slider_name == "lateral":
            x = value / 100.0
            y = self.left_touchpad.y_value
            self.left_touchpad.set_position(x, y)
        elif slider_name == "vertical":
            x = self.right_touchpad.x_value
            y = value / 100.0
            self.right_touchpad.set_position(x, y)
        elif slider_name == "yaw":
            x = value / 100.0
            y = self.right_touchpad.y_value
            self.right_touchpad.set_position(x, y)

        # 构建手动控制数据并发送兼容信号
        manual_controls = {
            "forward": self.forward_slider.value / 100.0,
            "lateral": self.lateral_slider.value / 100.0,
            "vertical": self.vertical_slider.value / 100.0,
            "yaw": self.yaw_slider.value / 100.0,
            "pitch": 0.0,  # 目前未在UI中实现
            "roll": 0.0  # 目前未在UI中实现
        }
        self.manual_control_updated.emit(manual_controls)

    def _on_mode_changed(self, mode):
        """控制模式变更事件处理"""
        self.current_mode = mode
        self._update_mode_ui(mode)
        # 使用正确的信号名
        self.control_mode_changed.emit(mode)

    def _update_mode_ui(self, mode):
        """根据模式更新UI"""
        # 针对不同模式调整UI
        if mode == "water":
            self.vertical_slider.setEnabled(True)
            self.yaw_slider.setEnabled(True)
            self.right_touchpad.setEnabled(True)

        elif mode == "walk":
            self.vertical_slider.setEnabled(False)
            self.yaw_slider.setEnabled(True)
            self.right_touchpad.setEnabled(True)

        elif mode == "seedling":
            self.vertical_slider.setEnabled(True)
            self.yaw_slider.setEnabled(False)
            self.right_touchpad.setEnabled(True)

        elif mode == "transplant":
            self.vertical_slider.setEnabled(True)
            self.yaw_slider.setEnabled(True)
            self.right_touchpad.setEnabled(True)

    def _on_apply_pid(self):
        """应用PID参数事件处理"""
        controller_index = self.controller_combo.currentIndex()
        controller_names = ["depth", "heading", "pitch", "roll"]

        if controller_index < len(controller_names):
            controller = controller_names[controller_index]

            pid_params = {
                "controller": controller,
                "kp": self.kp_spin.value(),
                "ki": self.ki_spin.value(),
                "kd": self.kd_spin.value()
            }

            self.commandExecuted.emit("set_pid", pid_params)

    def _on_set_target(self):
        """设置目标事件处理"""
        target_params = {
            "depth": self.depth_target.value(),
            "heading": self.heading_target.value()
        }

        self.commandExecuted.emit("set_target", target_params)

    def _on_emergency_stop(self):
        """紧急停止事件处理"""
        # 重置所有控制
        self.forward_slider.set_value(0)
        self.lateral_slider.set_value(0)
        self.vertical_slider.set_value(0)
        self.yaw_slider.set_value(0)

        self.left_touchpad.set_position(0, 0)
        self.right_touchpad.set_position(0, 0)

        # 发送紧急停止信号(两种都发送)
        self.emergency_stop.emit()  # 兼容原控制面板
        self.commandExecuted.emit("emergency_stop", {})  # 高级功能

    @pyqtSlot(dict)
    def update_joystick_data(self, joystick_data):
        """从手柄数据更新控制界面"""
        # 更新手柄状态显示组件
        self.joystick_status.update_joystick_data(joystick_data)

        # 如果模式变化，更新模式选择器
        mode = joystick_data.get("mode", "water")
        if mode != self.current_mode:
            self.mode_selector.set_mode(mode)
            self.mode_selector.highlight_mode_change(mode)
            self._on_mode_changed(mode)

        # 获取移动向量
        movement = joystick_data.get("movement", {})

        # 阻断信号避免循环更新
        self.left_touchpad.blockSignals(True)
        self.right_touchpad.blockSignals(True)
        self.forward_slider.blockSignals(True)
        self.lateral_slider.blockSignals(True)
        self.vertical_slider.blockSignals(True)
        self.yaw_slider.blockSignals(True)

        # 更新控制UI
        forward = movement.get("forward", 0.0)
        lateral = movement.get("lateral", 0.0)
        vertical = movement.get("vertical", 0.0)
        yaw = movement.get("yaw", 0.0)

        # 更新触控板
        self.left_touchpad.set_position(lateral, forward)
        self.right_touchpad.set_position(yaw, vertical)

        # 更新滑块
        self.forward_slider.set_value(forward * 100)
        self.lateral_slider.set_value(lateral * 100)
        self.vertical_slider.set_value(vertical * 100)
        self.yaw_slider.set_value(yaw * 100)

        # 恢复信号
        self.left_touchpad.blockSignals(False)
        self.right_touchpad.blockSignals(False)
        self.forward_slider.blockSignals(False)
        self.lateral_slider.blockSignals(False)
        self.vertical_slider.blockSignals(False)
        self.yaw_slider.blockSignals(False)

        # 发送手动控制更新信号
        manual_controls = {
            "forward": forward,
            "lateral": lateral,
            "vertical": vertical,
            "yaw": yaw,
            "pitch": movement.get("pitch", 0.0),
            "roll": movement.get("roll", 0.0)
        }
        self.manual_control_updated.emit(manual_controls)

    def set_joystick_connected(self, connected, name=""):
        """设置手柄连接状态"""
        self.joystick_status.set_connected(connected, name)

        if not connected:
            # 如果手柄断开，重置控制
            self.left_touchpad.set_position(0, 0)
            self.right_touchpad.set_position(0, 0)
            self.forward_slider.set_value(0)
            self.lateral_slider.set_value(0)
            self.vertical_slider.set_value(0)
            self.yaw_slider.set_value(0)