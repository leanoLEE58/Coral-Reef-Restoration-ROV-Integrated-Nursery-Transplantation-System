# modules/communication.py
"""
通信模块，负责通过TCP与树莓派通信，树莓派再连接STM32控制水下机器人
"""
import time
import json
import threading
import socket
import queue
import zlib
from PyQt5.QtCore import QObject, pyqtSignal
from OpenGL.GLUT import *
import sys
import config


class CommunicationManager(QObject):
    """通信管理器类"""
    # 定义信号
    data_received = pyqtSignal(dict)
    connection_status = pyqtSignal(bool)
    error = pyqtSignal(str)
    latency_updated = pyqtSignal(float)  # 通信延迟信号

    def __init__(self, host=None, port=None):
        """
        初始化通信管理器

        Args:
            host: 树莓派IP地址，默认使用配置文件中的设置
            port: TCP端口，默认使用配置文件中的设置
        """
        super().__init__()
        self.host = host if host is not None else config.TCP_HOST
        self.port = port if port is not None else config.TCP_PORT
        self.socket = None
        self.connected = False
        self.running = False

        # 线程和队列
        self.receive_thread = None
        self.send_thread = None
        self.heartbeat_thread = None
        self.reconnect_thread = None

        # 使用优先级队列进行命令发送
        self.send_queue = queue.PriorityQueue()
        self.send_lock = threading.Lock()

        # 通信统计
        self.last_received_time = 0
        self.ping_times = []
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = config.MAX_RECONNECT_ATTEMPTS

        # 数据包格式
        self.packet_header = b'\xAA\x55'
        self.packet_footer = b'\x55\xAA'

        # 命令ID和确认
        self.command_id = 0
        self.command_id_lock = threading.Lock()
        self.pending_commands = {}  # 存储待确认的命令

    def connect(self):
        """连接到树莓派"""
        if self.connected:
            return True

        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(config.TCP_TIMEOUT)
            self.socket.connect((self.host, self.port))
            self.connected = True
            self.connection_status.emit(True)
            self.reconnect_attempts = 0

            # 启动接收线程
            self.running = True
            self.receive_thread = threading.Thread(target=self._receive_loop)
            self.receive_thread.daemon = True
            self.receive_thread.start()

            # 启动发送线程
            self.send_thread = threading.Thread(target=self._send_loop)
            self.send_thread.daemon = True
            self.send_thread.start()

            # 启动心跳线程
            self.heartbeat_thread = threading.Thread(target=self._heartbeat_loop)
            self.heartbeat_thread.daemon = True
            self.heartbeat_thread.start()

            return True

        except Exception as e:
            self.error.emit(f"连接失败: {str(e)}")
            self.connected = False
            self.connection_status.emit(False)
            self._schedule_reconnect()
            return False

    def disconnect(self):
        """断开连接"""
        self.running = False

        for thread in [self.receive_thread, self.send_thread, self.heartbeat_thread]:
            if thread and thread.is_alive():
                thread.join(timeout=1.0)

        if self.socket:
            try:
                self.socket.close()
            except:
                pass

        self.connected = False
        self.connection_status.emit(False)

        # 清空队列
        while not self.send_queue.empty():
            try:
                self.send_queue.get_nowait()
            except:
                pass

    def send_data(self, data, priority=1):
        """
        发送数据到队列

        Args:
            data: 要发送的数据字典
            priority: 优先级(0-高优先级,1-普通,2-低优先级)
        """
        # 添加命令ID和时间戳
        with self.command_id_lock:
            self.command_id = (self.command_id + 1) % 65536
            data['cmd_id'] = self.command_id
            cmd_id = self.command_id

        data['timestamp'] = time.time()

        # 存储等待确认的命令
        if data.get('type') != 'heartbeat':  # 不跟踪心跳包
            self.pending_commands[cmd_id] = {
                'data': data,
                'time': time.time(),
                'attempts': 0
            }

        # 将数据添加到优先级队列
        self.send_queue.put((priority, data))

    def _receive_loop(self):
        """接收数据线程"""
        buffer = bytearray()

        while self.running:
            if not self.is_connected():
                time.sleep(0.1)
                continue

            try:
                # 接收数据
                data = self.socket.recv(4096)
                if not data:
                    # 连接已关闭
                    self.error.emit("连接已关闭")
                    self._handle_connection_lost()
                    continue

                buffer.extend(data)
                self.last_received_time = time.time()

                # 查找完整数据包
                while len(buffer) >= 4:
                    # 查找包头
                    header_pos = buffer.find(self.packet_header)
                    if header_pos == -1:
                        # 未找到包头，清空缓冲区
                        buffer.clear()
                        break

                    # 如果包头不在开始位置，删除之前的数据
                    if header_pos > 0:
                        del buffer[:header_pos]
                        continue

                    # 查找包尾
                    footer_pos = buffer.find(self.packet_footer, 2)
                    if footer_pos == -1:
                        # 未找到包尾，等待更多数据
                        break

                    # 提取数据包
                    packet = buffer[2:footer_pos]
                    del buffer[:footer_pos + 2]

                    # 解析数据包
                    try:
                        decoded_data = self._decode_packet(packet)
                        if decoded_data:
                            self._process_received_data(decoded_data)
                    except Exception as e:
                        self.error.emit(f"数据解析错误: {str(e)}")

            except socket.timeout:
                # 超时，检查心跳
                elapsed = time.time() - self.last_received_time
                if elapsed > config.CONNECTION_TIMEOUT:
                    self.error.emit(f"连接超时: {elapsed:.1f}秒无响应")
                    self._handle_connection_lost()
            except Exception as e:
                if self.running:  # 只在运行状态报告错误
                    self.error.emit(f"接收数据错误: {str(e)}")
                    self._handle_connection_lost()
                time.sleep(0.1)

    def _send_loop(self):
        """发送数据线程"""
        last_send_time = 0
        min_send_interval = 1.0 / config.MAX_SEND_RATE

        while self.running:
            if not self.is_connected():
                time.sleep(0.1)
                continue

            try:
                # 控制发送频率
                now = time.time()
                if now - last_send_time < min_send_interval:
                    time.sleep(0.001)
                    continue

                # 检查发送队列
                if not self.send_queue.empty():
                    priority, data = self.send_queue.get_nowait()

                    # 检查是否需要重传确认包
                    if 'ack' not in data and data.get('type') != 'heartbeat':
                        cmd_id = data.get('cmd_id')
                        if cmd_id in self.pending_commands:
                            # 更新重传计数
                            self.pending_commands[cmd_id]['attempts'] += 1

                            # 如果重传次数过多，放弃该命令
                            if self.pending_commands[cmd_id]['attempts'] > config.MAX_RETRANSMIT:
                                self.error.emit(f"命令 {cmd_id} 重传失败")
                                del self.pending_commands[cmd_id]
                                continue

                    # 编码和发送数据包
                    packet = self._encode_packet(data)
                    self.socket.sendall(packet)
                    last_send_time = time.time()

                # 检查超时的命令并重传
                now = time.time()
                for cmd_id, cmd_info in list(self.pending_commands.items()):
                    if now - cmd_info['time'] > config.COMMAND_TIMEOUT:
                        # 重新排队发送
                        cmd_info['time'] = now
                        self.send_queue.put((0, cmd_info['data']))  # 高优先级重传

            except Exception as e:
                if self.running:  # 只在运行状态报告错误
                    self.error.emit(f"发送数据错误: {str(e)}")
                    self._handle_connection_lost()
                time.sleep(0.1)

    def _heartbeat_loop(self):
        """心跳包发送线程"""
        while self.running:
            if self.is_connected():
                try:
                    # 发送心跳包
                    heartbeat = {
                        "type": "heartbeat",
                        "timestamp": time.time()
                    }
                    # 优先级最低(2)的心跳包
                    self.send_data(heartbeat, priority=2)
                except Exception as e:
                    if self.running:
                        self.error.emit(f"发送心跳包错误: {str(e)}")

            # 心跳间隔
            time.sleep(config.HEARTBEAT_INTERVAL)

    def _process_received_data(self, data):
        """
        处理接收到的数据

        Args:
            data: 接收到的数据字典
        """
        # 处理心跳响应
        if data.get('type') == 'heartbeat_ack':
            send_time = data.get('original_timestamp', 0)
            if send_time > 0:
                # 计算往返时间
                rtt = time.time() - send_time
                # 保存最近的延迟时间
                self.ping_times.append(rtt)
                if len(self.ping_times) > 10:
                    self.ping_times.pop(0)
                # 计算平均延迟
                avg_latency = sum(self.ping_times) / len(self.ping_times)
                self.latency_updated.emit(avg_latency)
            return

        # 处理命令确认
        if data.get('type') == 'ack':
            cmd_id = data.get('cmd_id')
            if cmd_id in self.pending_commands:
                del self.pending_commands[cmd_id]
            return

        # 发送确认包（除了确认包自己）
        if 'cmd_id' in data and data.get('type') != 'ack':
            ack = {
                "type": "ack",
                "cmd_id": data.get('cmd_id'),
                "timestamp": time.time()
            }
            self.send_data(ack, priority=0)  # 高优先级确认

        # 发送数据接收信号
        self.data_received.emit(data)

    def _handle_connection_lost(self):
        """处理连接丢失"""
        # 只在已连接状态处理断连
        if self.connected:
            self.connected = False
            self.connection_status.emit(False)

            if self.socket:
                try:
                    self.socket.close()
                except:
                    pass
                self.socket = None

            # 安排重连
            self._schedule_reconnect()

    def _schedule_reconnect(self):
        """安排自动重连"""
        if self.reconnect_attempts < self.max_reconnect_attempts:
            self.reconnect_attempts += 1
            # 启动重连线程
            if not self.reconnect_thread or not self.reconnect_thread.is_alive():
                self.reconnect_thread = threading.Thread(target=self._reconnect_loop)
                self.reconnect_thread.daemon = True
                self.reconnect_thread.start()

    def _reconnect_loop(self):
        """重连线程"""
        # 使用指数退避重连
        wait_time = min(config.TCP_RETRY_INTERVAL * (2 ** (self.reconnect_attempts - 1)), 60)
        time.sleep(wait_time)

        if self.running and not self.connected:
            self.connect()

    def _encode_packet(self, data):
        """
        编码数据包

        Args:
            data: 要编码的数据字典

        Returns:
            编码后的字节数据
        """
        # 将数据转换为JSON字符串
        json_data = json.dumps(data).encode('utf-8')

        # 对大数据包进行压缩
        if len(json_data) > config.COMPRESSION_THRESHOLD:
            compressed = zlib.compress(json_data)
            # 添加压缩标志
            packet = bytearray()
            packet.extend(self.packet_header)
            packet.extend(b'C')  # 压缩标志
            packet.extend(compressed)
            packet.extend(self.packet_footer)
        else:
            # 不压缩小数据包
            packet = bytearray()
            packet.extend(self.packet_header)
            packet.extend(b'N')  # 无压缩标志
            packet.extend(json_data)
            packet.extend(self.packet_footer)

        return packet

    def _decode_packet(self, packet):
        """
        解码数据包

        Args:
            packet: 要解码的字节数据

        Returns:
            解码后的数据字典
        """
        try:
            # 检查是否压缩
            if packet[0:1] == b'C':
                # 解压缩
                decompressed = zlib.decompress(packet[1:])
                json_data = decompressed.decode('utf-8')
            else:
                # 直接解码
                json_data = packet[1:].decode('utf-8')

            return json.loads(json_data)
        except Exception as e:
            self.error.emit(f"解码数据包错误: {str(e)}")
            return None

    def is_connected(self):
        """检查是否已连接"""
        return self.connected and self.socket is not None

    def get_available_hosts(self):
        """
        扫描局域网中可能的树莓派设备

        Returns:
            可能的树莓派IP列表
        """
        hosts = []

        # 添加配置中的默认主机
        hosts.append(config.TCP_HOST)

        # 如果配置了备用主机，也添加
        if hasattr(config, 'BACKUP_HOSTS') and config.BACKUP_HOSTS:
            hosts.extend(config.BACKUP_HOSTS)

        # 这里可以实现简单的网络扫描
        # 例如探测某些常见端口或广播发现协议

        return hosts

    def get_statistics(self):
        """
        获取通信统计信息

        Returns:
            通信统计字典
        """
        stats = {
            "connected": self.is_connected(),
            "reconnect_attempts": self.reconnect_attempts,
            "pending_commands": len(self.pending_commands),
            "queue_size": self.send_queue.qsize(),
        }

        # 计算平均延迟
        if self.ping_times:
            stats["avg_latency"] = sum(self.ping_times) / len(self.ping_times)
            stats["min_latency"] = min(self.ping_times)
            stats["max_latency"] = max(self.ping_times)
        else:
            stats["avg_latency"] = 0
            stats["min_latency"] = 0
            stats["max_latency"] = 0

        return stats