# config.py
"""
珊瑚守望水下机器人 - 配置文件
"""

# 通信设置 - 串口（保留向后兼容）
SERIAL_PORT = "/dev/ttyUSB0"  # 串口设备
SERIAL_BAUDRATE = 115200      # 波特率
COMMUNICATION_TIMEOUT = 1.0   # 通信超时时间(秒)

# TCP通信设置
TCP_HOST = "192.168.58.172"    # 树莓派默认IP地址
TCP_PORT = 8888               # 通信端口
TCP_TIMEOUT = 3.0             # Socket超时(秒)
TCP_RETRY_INTERVAL = 5.0      # 断线重连间隔(秒)
CONNECTION_TIMEOUT = 5.0      # 无数据超时视为断线(秒)
HEARTBEAT_INTERVAL = 1.0      # 心跳包发送间隔(秒)
MAX_RECONNECT_ATTEMPTS = 10   # 最大重连尝试次数
MAX_SEND_RATE = 100           # 最大发送频率(Hz)
COMMAND_TIMEOUT = 0.5         # 命令超时时间(秒)
MAX_RETRANSMIT = 3            # 命令最大重传次数
COMPRESSION_THRESHOLD = 1024  # 数据压缩阈值(字节)
BACKUP_HOSTS = [              # 备用树莓派IP地址
    "192.168.1.101",
    "192.168.1.102"
]

# 视频流设置
VIDEO_SOURCE = 0               # 摄像头索引或RTSP地址
VIDEO_WIDTH = 640              # 视频宽度
VIDEO_HEIGHT = 480             # 视频高度
VIDEO_FPS = 30                 # 视频帧率
VIDEO_RTSP_URL = "rtsp://192.168.1.100:8554/live"  # RTSP流地址
VIDEO_BUFFER_SIZE = 10         # 视频帧缓冲大小
VIDEO_RECORD_PATH = "./videos" # 视频录制保存路径

# 控制设置
JOYSTICK_DEADZONE = 0.1        # 手柄死区
JOYSTICK_CURVE = 1.2           # 手柄响应曲线(1.0为线性，大于1更敏感)
CONTROL_UPDATE_RATE = 50       # 控制更新频率(Hz)
MAX_THRUST = 100               # 最大推力百分比

# PID默认参数
PID_DEFAULTS = {
    "depth": {
        "kp": 1.0,
        "ki": 0.1,
        "kd": 0.05,
        "target": 1.0
    },
    "heading": {
        "kp": 1.5,
        "ki": 0.0,
        "kd": 0.2,
        "target": 0.0
    },
    "pitch": {
        "kp": 1.0,
        "ki": 0.0,
        "kd": 0.1,
        "target": 0.0
    }
}

# UI设置
UI_THEME = "dark"              # 界面主题 (dark/light)
UI_REFRESH_RATE = 120          # UI刷新率(Hz)
LANGUAGE = "zh_CN"             # 界面语言

# 机器人参数
ROBOT_NAME = "珊瑚守望V1.7"
MAX_DEPTH = 100                # 最大深度(米)
BATTERY_CAPACITY = 10000       # 电池容量(mAh)
BATTERY_WARNING = 20           # 电池警告阈值(%)