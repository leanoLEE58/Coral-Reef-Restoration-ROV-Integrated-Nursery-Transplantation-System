# ui/video_widget.py
"""
视频显示组件
"""
import time

from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox
from PyQt5.QtCore import Qt, pyqtSlot, QSize
from PyQt5.QtGui import QImage, QPixmap, QPainter, QColor, QPen, QFont

import config
from OpenGL.GLUT import *
import sys

class VideoWidget(QWidget):
    """视频显示组件"""

    def __init__(self, parent=None):
        """
        初始化视频显示组件

        Args:
            parent: 父组件
        """
        super().__init__(parent)
        self.image = QImage()
        self.video_size = QSize(config.VIDEO_WIDTH, config.VIDEO_HEIGHT)
        self.overlay_enabled = True
        self.screenshot_count = 0

        # 初始化UI
        self._init_ui()

    def _init_ui(self):
        """初始化UI"""
        # 主布局
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        # 视频显示标签
        self.video_label = QLabel(self)
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setMinimumSize(640, 480)
        self.video_label.setStyleSheet("background-color: #000000;")
        layout.addWidget(self.video_label)

        # 控制栏
        control_layout = QHBoxLayout()

        # 截图按钮
        self.screenshot_btn = QPushButton("截图", self)
        self.screenshot_btn.clicked.connect(self._take_screenshot)
        control_layout.addWidget(self.screenshot_btn)

        # 滤镜选择
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("滤镜:", self))
        self.filter_combo = QComboBox(self)
        self.filter_combo.addItems(["无", "灰度", "模糊", "边缘检测"])
        filter_layout.addWidget(self.filter_combo)
        control_layout.addLayout(filter_layout)

        # 叠加信息开关
        self.overlay_btn = QPushButton("信息叠加: 开", self)
        self.overlay_btn.setCheckable(True)
        self.overlay_btn.setChecked(True)
        self.overlay_btn.clicked.connect(self._toggle_overlay)
        control_layout.addWidget(self.overlay_btn)

        control_layout.addStretch()

        layout.addLayout(control_layout)

        # 设置样式
        self.setStyleSheet("""
            QPushButton {
                background-color: #2c3e50;
                color: white;
                border: none;
                padding: 5px 10px;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #34495e;
            }
            QPushButton:checked {
                background-color: #16a085;
            }
            QComboBox {
                background-color: #2c3e50;
                color: white;
                border: none;
                padding: 5px;
                border-radius: 3px;
            }
            QComboBox QAbstractItemView {
                background-color: #34495e;
                color: white;
                selection-background-color: #16a085;
            }
        """)

    # 在VideoWidget类中添加以下方法

    def set_video_source(self, source):
        """设置视频源"""
        # 此方法可以在主窗口中调用，用于更新视频源
        # 实际实现在主窗口的_select_camera方法中
        pass

    def save_current_frame(self, filename=None):
        """保存当前帧为图像文件"""
        if self.image.isNull():
            return False

        if filename is None:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            filename = f"capture_{timestamp}.png"

        return self.image.save(filename)

    def toggle_recording(self, recording=None):
        """切换视频录制状态"""
        if recording is not None:
            self.recording = recording
        else:
            self.recording = not getattr(self, 'recording', False)

        # 更新录制按钮文本
        if hasattr(self, 'record_btn'):
            self.record_btn.setText("停止录制" if self.recording else "开始录制")
    @pyqtSlot(QImage)
    def update_image(self, image):
        """
        更新视频图像

        Args:
            image: 新的视频图像
        """
        self.image = image
        pixmap = QPixmap.fromImage(image)

        # 添加调试信息
        if hasattr(self, 'show_debug_info') and self.show_debug_info:
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 0))  # 黄色文本
            painter.setFont(QFont("Arial", 10))

            # 添加帧率信息
            current_time = time.time()
            if hasattr(self, 'last_frame_time'):
                fps = 1.0 / (current_time - self.last_frame_time)
                painter.drawText(10, 20, f"FPS: {fps:.1f}")
            self.last_frame_time = current_time

            # 添加图像尺寸信息
            painter.drawText(10, 40, f"尺寸: {image.width()}x{image.height()}")

            painter.end()

        # 保持宽高比例缩放
        scaled_pixmap = pixmap.scaled(
            self.video_label.size(),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )

        self.video_label.setPixmap(scaled_pixmap)

    def resizeEvent(self, event):
        """
        重写大小调整事件

        Args:
            event: 事件对象
        """
        super().resizeEvent(event)

        # 如果有图像，重新缩放显示
        if not self.image.isNull():
            pixmap = QPixmap.fromImage(self.image)
            scaled_pixmap = pixmap.scaled(
                self.video_label.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.video_label.setPixmap(scaled_pixmap)

    def _take_screenshot(self):
        """保存当前帧为截图"""
        if not self.image.isNull():
            self.screenshot_count += 1
            filename = f"screenshot_{self.screenshot_count}.png"
            self.image.save(filename)

    def _toggle_overlay(self, checked):
        """
        切换叠加信息显示

        Args:
            checked: 是否选中
        """
        self.overlay_enabled = checked
        if checked:
            self.overlay_btn.setText("信息叠加: 开")
        else:
            self.overlay_btn.setText("信息叠加: 关")

    def get_selected_filter(self):
        """
        获取选中的滤镜

        Returns:
            选中的滤镜名称
        """
        filter_index = self.filter_combo.currentIndex()
        if filter_index == 0:
            return None
        elif filter_index == 1:
            return "grayscale"
        elif filter_index == 2:
            return "blur"
        elif filter_index == 3:
            return "edge"
        return None

    def draw_overlay(self, pixmap, robot_status):
        """
        绘制叠加信息

        Args:
            pixmap: 要绘制的QPixmap对象
            robot_status: 机器人状态信息

        Returns:
            绘制叠加信息后的QPixmap
        """
        if not self.overlay_enabled or not robot_status:
            return pixmap

        # 创建绘图对象
        result = QPixmap(pixmap)
        painter = QPainter(result)

        # 设置字体
        font = QFont("Arial", 10)
        painter.setFont(font)

        # 绘制状态信息
        y_offset = 20
        text_items = [
            f"深度: {robot_status.get('depth', 0.0):.2f} m",
            f"航向: {robot_status.get('heading', 0.0):.1f}°",
            f"俯仰: {robot_status.get('pitch', 0.0):.1f}°",
            f"横滚: {robot_status.get('roll', 0.0):.1f}°",
            f"温度: {robot_status.get('temperature', 0.0):.1f}°C",
            f"电池: {robot_status.get('battery', 0.0):.1f}%"
        ]

        # 添加半透明背景
        painter.fillRect(5, 5, 200, len(text_items) * 20 + 10, QColor(0, 0, 0, 128))

        # 绘制文本
        painter.setPen(QColor(255, 255, 255))
        for text in text_items:
            painter.drawText(10, y_offset, text)
            y_offset += 20

        # 绘制水平仪
        self._draw_attitude_indicator(painter, robot_status, result.width(), result.height())

        # 如果检测到漏水，绘制警告
        if robot_status.get('leak_detected', False):
            painter.setPen(QPen(QColor(255, 0, 0), 3))
            painter.drawText(result.width() - 200, 30, "漏水警告!")

        # 如果电池电量低，绘制警告
        battery = robot_status.get('battery', 100.0)
        if battery < config.BATTERY_WARNING:
            painter.setPen(QPen(QColor(255, 0, 0), 3))
            painter.drawText(result.width() - 200, 60, f"电池电量低: {battery:.1f}%")

        painter.end()
        return result

    def _draw_attitude_indicator(self, painter, robot_status, width, height):
        """
        绘制姿态指示器

        Args:
            painter: QPainter对象
            robot_status: 机器人状态信息
            width: 画布宽度
            height: 画布高度
        """
        # 姿态指示器位置和大小
        center_x = width - 80
        center_y = height - 80
        radius = 60

        # 获取姿态数据
        roll = robot_status.get('roll', 0.0)
        pitch = robot_status.get('pitch', 0.0)

        # 绘制外圆
        painter.setPen(QPen(QColor(255, 255, 255), 2))
        painter.drawEllipse(center_x - radius, center_y - radius, radius * 2, radius * 2)

        # 绘制水平线
        painter.save()
        painter.translate(center_x, center_y)
        painter.rotate(roll)

        # 根据俯仰角调整水平线位置
        pitch_offset = (pitch / 90.0) * radius * 0.8

        painter.setPen(QPen(QColor(0, 255, 0), 2))
        painter.drawLine(-radius, pitch_offset, radius, pitch_offset)

        # 绘制刻度
        painter.setPen(QPen(QColor(255, 255, 255), 1))
        for i in range(-30, 31, 10):
            y = (i / 90.0) * radius * 0.8
            line_length = 10 if i % 30 == 0 else 5
            painter.drawLine(-line_length, y, line_length, y)

        painter.restore()

        # 绘制中心标记
        painter.setPen(QPen(QColor(255, 0, 0), 2))
        painter.drawLine(center_x - 10, center_y, center_x + 10, center_y)
        painter.drawLine(center_x, center_y - 10, center_x, center_y + 10)