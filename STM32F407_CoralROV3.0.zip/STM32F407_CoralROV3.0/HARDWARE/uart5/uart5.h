#ifndef __UART5_H
#define __UART5_H
#include "stdio.h"
#include "stm32f4xx_conf.h"
#include "sys.h"
//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//Mini STM32开发板
//串口1初始化		   
//正点原子@ALIENTEK
//技术论坛:www.openedv.csom
//修改日期:2011/6/14
//版本：V1.4
//版权所有，盗版必究。
//Copyright(C) 正点原子 2009-2019
//All rights reserved
//********************************************************************************
//V1.3修改说明 
//支持适应不同频率下的串口波特率设置.
//加入了对printf的支持
//增加了串口接收命令功能.
//修正了printf第一个字符丢失的bug
//V1.4修改说明
//1,修改串口初始化IO的bug
//2,修改了USART_RX_STA,使得串口最大接收字节数为2的14次方
//3,增加了USART_REC_LEN,用于定义串口最大允许接收的字节数(不大于2的14次方)
//4,修改了EN_USART1_RX的使能方式
////////////////////////////////////////////////////////////////////////////////// 	
#define USART_REC_LEN  			200  	//定义最大接收字节数 200
#define EN_UART5_RX 			1		//使能（1）/禁止（0）串口5接收

#define FRAME_HEADER  0x55      //帧头
#define OBJ_STEPMOTOR 0x01      //步进电机
#define OBJ_SERVO     0x02      //舵机
#define OBJ_PADDLE    0x03      //推进器  @Prm1 no  @Prm2 speed
#define OBJ_LVD       0x04      //履带电机
#define OBJ_TJQ_ShangSheng  0x0F      //ROV上升
#define OBJ_TJQ_XiaQian     0x10      //ROV下潜
#define OBJ_TJQ_TingZhi     0x11      //推进器停止
#define OBJ_TJQ_ZuoZhuan    0x0D      //ROV左转
#define OBJ_TJQ_YouZhuan    0x0E      //ROV右转
#define OBJ_TJQ_QianJin     0x0B      //ROV前进
#define OBJ_TJQ_HouTui      0x0C      //ROV后退
#define OBJ_TJQ_ZuoYi       0x13      //ROV左移
#define OBJ_TJQ_YouYi       0x14      //ROV右移
#define OBJ_LvD_TingZhi     0x12      //履带停止
#define OBJ_LvD_QianJin     0x09      //履带前进
#define OBJ_LvD_HouTui      0x0A      //履带后退
#define OBJ_LvD_Left    	0x17      //履带左转
#define OBJ_LvD_Right	    0x18      //履带右转
#define OBJ_UP_STEPMOTOR    0x07      //履带上升
#define OBJ_DOWN_STEPMOTOR  0x08      //履带下降
#define OBJ_AG_XiaFang      0x05      //网格下放
#define OBJ_AG_HuiShou      0x06      //网格回收
#define OBJ_CT_Off		    0x15      //磁铁吸附状态
#define OBJ_CT_On		    0x16      //磁铁无磁状态
#define OBJ_SUO		        0x19      //三角锁
//#define OBJ_DUOJI   		0x1A      //舵机
#define OBJ_SET_Para        0x1C      //PID参数
#define OBJ_AUTO_START      0x1A      //自动模式
#define OBJ_AUTO_STOP       0x1B      //退出自动
#define OBJ_AUTO_SET        0x1D      //误差

typedef enum {
	false = 0, true = !false
}bool;

extern uint8_t RaspberryRxBuf[16];
extern bool isUartRxCompleted;

extern u8  USART_RX_BUF[USART_REC_LEN]; //接收缓冲,最大USART_REC_LEN个字节.末字节为换行符 
extern u16 USART_RX_STA;         		//接收状态标记	
extern uint8_t flag_uart5Received;//--接收标记
//如果想串口中断接收，请不要注释以下宏定义
void uart5_Init(u32 bound);
#endif
