#include "stm32f4xx.h"
#include "string.h"
#include "usart3.h"
//#include "LobotServoController.h"

#if EN_USART1_RX   //???????
//??1??????
//??,??USARTx->SR??????????
u8 USART_RX_BUF3[USART_REC_LEN];     //????,??USART_REC_LEN???.
//????
//bit15,	??????
//bit14,	???0x0d
//bit13~0,	??????????
u16 USART_RX_STA3=0;       //??????

uint8_t flag=0;

//int fputc(int c, FILE * stream)
//{
//	while(!(USART3->SR & (1<<7)));
//	USART3->DR=c;//???c???????????,??????????????????
//	
//	return c;
//}

void uart3NVICInit(void)
{
	//USART3 NVIC
	NVIC_InitTypeDef NVIC_InitStructure;
	
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void uart3_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
    
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
    GPIO_PinAFConfig(GPIOD,GPIO_PinSource8,GPIO_AF_USART3);
	GPIO_PinAFConfig(GPIOD,GPIO_PinSource9,GPIO_AF_USART3);
	
	//USART3_TX    PD8
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	//USART3_RX    PD9
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
    
	//USART ??
	USART_InitStructure.USART_BaudRate = bound;//???
	USART_InitStructure.USART_WordLength = USART_WordLength_8b; //???
	USART_InitStructure.USART_StopBits = USART_StopBits_1; //???
	USART_InitStructure.USART_Parity = USART_Parity_No; //???
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //???
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx; //????
    
	USART_Init(USART3, &USART_InitStructure);
	uart3NVICInit();
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
	USART_Cmd(USART3, ENABLE);
}

void uart3WriteBuf(uint8_t *buf, uint8_t len)
{
	while (len--) {
		while ((USART3->SR & 0x40) == 0);
		USART_SendData(USART3,*buf++);
	}
}

void USART3_IRQHandler(void)                	//??1??????
{
    u8 Res;
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)  //????(?????????0x0d 0x0a??)
	{
		Res =USART_ReceiveData(USART3);//(USART3->DR);	//????????
		if((USART_RX_STA3&0x8000)==0)//?????
		{
			if(USART_RX_STA3&0x4000)//????0x0d
			{
				if(Res!=0x0a)USART_RX_STA3=0;//????,????
				else USART_RX_STA3|=0x8000;	//????? 
			}
			else //????0X0D
			{
				if(Res==0x0d)USART_RX_STA3|=0x4000;
				else
				{
					if(Res=='!')
                    {
                        flag=1;
                    }
                    else
                    {
                    USART_RX_BUF3[USART_RX_STA3&0X3FFF]=Res ;
					USART_RX_STA3++;
					if(USART_RX_STA3>(USART_REC_LEN-1))USART_RX_STA3=0;//??????,??????	  
                    }
				}
			}
		}
  }
}
#endif
