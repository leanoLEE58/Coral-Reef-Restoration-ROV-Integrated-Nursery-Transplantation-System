#ifndef __PADDLE_H
#define __PADDLE_H
#include "sys.h"

void Paddle_Init(void);
void Set_Paddlespeed(uint8_t no, int16_t speed);


#endif
