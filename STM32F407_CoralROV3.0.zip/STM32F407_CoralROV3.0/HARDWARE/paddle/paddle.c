#include "paddle.h"
#include "delay.h"

void Paddle_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStucture;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStucture;
    TIM_OCInitTypeDef TIM_OCInitStucture;
    
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource6,GPIO_AF_TIM4);
    GPIO_PinAFConfig(GPIOD,GPIO_PinSource13,GPIO_AF_TIM4);
    GPIO_PinAFConfig(GPIOD,GPIO_PinSource14,GPIO_AF_TIM4);
    GPIO_PinAFConfig(GPIOD,GPIO_PinSource15,GPIO_AF_TIM4);
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource1,GPIO_AF_TIM5);
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource2,GPIO_AF_TIM5);
    
    GPIO_InitStucture.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStucture.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStucture.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStucture.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStucture.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB,&GPIO_InitStucture);
    GPIO_InitStucture.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_Init(GPIOD,&GPIO_InitStucture);
    GPIO_InitStucture.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
    GPIO_Init(GPIOA,&GPIO_InitStucture);
    
	TIM_TimeBaseInitStucture.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStucture.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStucture.TIM_Period = 2000-1;
	TIM_TimeBaseInitStucture.TIM_Prescaler = 840-1;
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStucture);
    TIM_TimeBaseInit(TIM5,&TIM_TimeBaseInitStucture);
	
	TIM_OCInitStucture.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStucture.TIM_OCNPolarity = TIM_OCPolarity_High;
	TIM_OCInitStucture.TIM_OutputState = ENABLE;
	TIM_OC1Init(TIM4,&TIM_OCInitStucture);
    TIM_OC2Init(TIM4,&TIM_OCInitStucture);
    TIM_OC3Init(TIM4,&TIM_OCInitStucture);
    TIM_OC4Init(TIM4,&TIM_OCInitStucture);
    TIM_OC2Init(TIM5,&TIM_OCInitStucture);
    TIM_OC3Init(TIM5,&TIM_OCInitStucture);
	
    TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable); //使能预装载寄存器
    TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM5, TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM5, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM4,ENABLE);//ARPE 使能
    TIM_ARRPreloadConfig(TIM5,ENABLE);
    
	TIM_Cmd(TIM4,ENABLE);
    TIM_Cmd(TIM5,ENABLE);
    
    delay_ms(1000);
    TIM_SetCompare1(TIM4,150);
    TIM_SetCompare2(TIM4,150);
    TIM_SetCompare3(TIM4,150);
    TIM_SetCompare4(TIM4,150);
    TIM_SetCompare2(TIM5,150);
    TIM_SetCompare3(TIM5,150);
    delay_ms(1000);
    TIM_SetCompare1(TIM4,200);
    TIM_SetCompare2(TIM4,200);
    TIM_SetCompare3(TIM4,200);
    TIM_SetCompare4(TIM4,200);
    TIM_SetCompare2(TIM5,200);
    TIM_SetCompare3(TIM5,200);
    delay_ms(1000);
    TIM_SetCompare1(TIM4,150);
    TIM_SetCompare2(TIM4,150);
    TIM_SetCompare3(TIM4,150);
    TIM_SetCompare4(TIM4,150);
    TIM_SetCompare2(TIM5,150);
    TIM_SetCompare3(TIM5,150);
    delay_ms(1000);
}

//推进器转速控制，0~100正转，0~-100反转, 绝对值越大速度越大,软限幅：60(满速度de60%)
void Set_Paddlespeed(uint8_t no, int16_t speed)
{
    if(no!=2 && no !=5)
    {
        if(speed >= 60)
        speed = 60;
        else if(speed <= -60)
        speed = -60;
    }
    else
    {
        if(speed >= 80)
        speed = 80;
        else if(speed <= -80)
        speed = -80;
    }
    
    speed = 150 + speed / 2;
    
    switch(no)
    {
        case 1:{TIM_SetCompare1(TIM4,speed);break;}
        case 2:{TIM_SetCompare2(TIM4,speed);break;}
        case 3:{TIM_SetCompare3(TIM4,speed);break;}
        case 4:{TIM_SetCompare4(TIM4,speed);break;}
        case 5:{TIM_SetCompare2(TIM5,speed);break;}
        case 6:{TIM_SetCompare3(TIM5,speed);break;}
        default:
            break;
    }
}
