#ifndef __TEST_H
#define __TEST_H
#include "sys.h"

void test(void);

#endif
