#include "pid.h"
#include "paddle.h"
#include "mpu6050.h"
#include "ms5837.h"

PIDTypeDef pid_roll, pid_pitch, pid_yaw, pid_depth, pid_h, pid_v;

void PID_Init(PIDTypeDef *pid,float p,float i,float d,float maxI,float maxOut)
{
    pid->kp=p;
    pid->ki=i;
    pid->kd=d;
    pid->maxIntegral=maxI;
    pid->maxOutput=maxOut;
}

void PID_Calc(PIDTypeDef *pid,float reference,float feedback)
{
    float dout;
    float pout;
 	//更新数据
    pid->lastError=pid->error;//将旧error存起来
    pid->error=reference-feedback;//计算新error
    if(pid->error<=-180)                      //角度偏差数据处理 使其处于+-180°优孤化为劣弧
        pid->error=pid->error+360;
    if(pid->error>=180)
        pid->error=pid->error-360;
    //计算微分
    dout=(pid->error-pid->lastError)*pid->kd;
    //计算比例
    pout=pid->error*pid->kp;
    //计算积分
    pid->integral+=pid->error*pid->ki;
    //积分限幅
    if(pid->integral > pid->maxIntegral) pid->integral=pid->maxIntegral;
    else if(pid->integral < -pid->maxIntegral) pid->integral=-pid->maxIntegral;
    //计算输出
    pid->output=pout+dout+pid->integral;
    //输出限幅
    if(pid->output > pid->maxOutput) pid->output=pid->maxOutput;
    else if(pid->output < -pid->maxOutput) pid->output=-pid->maxOutput;
}

void Set_Attitute(float sr,float sp,float sy)
{
    PID_Calc(&pid_roll,  sr, eulerAngle.roll );
    PID_Calc(&pid_pitch, sp, eulerAngle.pitch);
    PID_Calc(&pid_yaw,   sy, eulerAngle.yaw  );
    
    Set_Paddlespeed(1,  pid_roll.output);
    Set_Paddlespeed(2, -pid_roll.output);
    Set_Paddlespeed(3,  pid_roll.output);
    Set_Paddlespeed(4, -pid_roll.output);
    Set_Paddlespeed(5,  pid_roll.output);
    Set_Paddlespeed(6, -pid_roll.output);
}

void Set_Depth(float sd)
{
    PID_Calc(&pid_depth, sd, Depth);
    
    
}
