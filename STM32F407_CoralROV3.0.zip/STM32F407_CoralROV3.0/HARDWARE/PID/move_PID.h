#ifndef __MOVE_PID_H
#define __MOVE_PID_H

struct PID
{
	float angle;
    float last_angle;
    float goal;
    float err;
    float last_err;
    float derr;
    float errsum;
    
	float kp;
    float ki;
    float kd;
};

extern struct PID pidx,pidy,pidz;

void PID_init(struct PID * pc,float agle,float goal,float p,float i,float d);
void PID_Update(struct PID * pc,float p,float i,float d);
float PID_angle(struct PID * pc,float agle,float target);
float yaw_56(float yaw,float goalz);
float rollpitch_13(float pitch,float roll,float goalx,float goaly);
float rollpitch_24(float pitch,float roll,float goalx,float goaly);
void Move(void);

#endif
