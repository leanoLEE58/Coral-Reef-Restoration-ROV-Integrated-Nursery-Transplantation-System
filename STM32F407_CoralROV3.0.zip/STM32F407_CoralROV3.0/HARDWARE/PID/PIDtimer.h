#ifndef __PIDTIMER_H
#define __PIDTIMER_H
#include "sys.h"
#include "stdint.h"

void TIM13_Int_Init(uint16_t arr,uint16_t psc);


#endif
