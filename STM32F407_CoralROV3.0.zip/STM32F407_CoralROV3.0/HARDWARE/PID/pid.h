#ifndef __PID_H
#define __PID_H

typedef struct
{
   	float kp,ki,kd;//三个系数
    float error,lastError;//误差、上次误差
    float integral,maxIntegral;//积分、积分限幅
    float output,maxOutput;//输出、输出限幅
}PIDTypeDef;

extern PIDTypeDef pid_roll, pid_pitch, pid_yaw, pid_depth, pid_h, pid_v;

void PID_Init(PIDTypeDef *pid,float p,float i,float d,float maxI,float maxOut);
void PID_Calc(PIDTypeDef *pid,float reference,float feedback);

void Set_Attitute(float sr,float sp,float sy);

#endif
