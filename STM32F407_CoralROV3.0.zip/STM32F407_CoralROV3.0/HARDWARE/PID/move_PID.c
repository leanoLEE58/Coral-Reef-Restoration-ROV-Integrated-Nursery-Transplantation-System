#include "move_PID.h"
#include "math.h"
#include "mpu6050.h"
//#include "Gyroscope_solve.h"
#include "paddle.h"

#define ERR2PWM_MAX		100  //可以更改
#define ERR2PWM_MIN		-100 //可以更改
#define PWM_MAX 		50
#define PWM_MIN 		-50

struct PID pidx,pidy,pidz;

//PID初始化 当前角度 目标角度 p i d
void PID_init(struct PID * pc,float agle,float goal,float p,float i,float d)
{
	pc->angle = agle;
	pc->last_angle = 0;
	pc->goal = goal;
	pc->err = 0;
	pc->last_err = 0;
	pc->derr = 0;
	pc->errsum = 0;
	
	pc->kp = p;
	pc->ki = i;
	pc->kd = d;
}

//PID更新 串口数据判断 更新p i d
void PID_Update(struct PID * pc,float p,float i,float d)
{
	pc->kp = p;
	pc->ki = i;
	pc->kd = d;
}

//PID 根据角度不断刷新 间隔10ms
float PID_angle(struct PID * pc,float agle,float target)
{
	float pwm_value = 0;
	
	pc->goal = target;
	pc->angle = agle;
	
	//误差项 = 目标 - 当前值
	pc->err = pc->goal - pc->angle;
	
	//积分项 + 限幅
	pc->errsum += pc->err;
	
	if (pc->errsum > ERR2PWM_MAX)
		pc->errsum = ERR2PWM_MAX;
	if (pc->errsum < ERR2PWM_MIN)
		pc->errsum = ERR2PWM_MIN;
	
	//微分项
	pc->derr = pc->err - pc->last_err;
	
	//更新err
	pc->last_err = pc->err;
	
	pwm_value = pc->kp * pc->err + pc->ki * pc->errsum + pc->kd * pc->derr;
	
	if (pwm_value > PWM_MAX)
		pwm_value = PWM_MAX;
	if (pwm_value < PWM_MIN)
		pwm_value = PWM_MIN;
	
	return pwm_value;
}

/*
Gyroscope_getValues();
Gyroscope_solve();
eulerAngle.pitch,eulerAngle.roll,eulerAngle.yaw
Set_Paddlespeed(1,10);

首先是 自稳定
	首先是z轴自稳定 然后是判断 四个角度的两个角度之间的PID
然后是 前进(后退) 右转(左转)

*/
//推进器5 -推进器6 yaw角度 （-180，+180）
float yaw_56(float yaw,float goalz)
{
	return PID_angle(&pidz,yaw,goalz);//z 角度 目标角度
}

//推进器1 -推进器3
float rollpitch_13(float pitch,float roll,float goalx,float goaly)
{
	return PID_angle(&pidy,pitch,goaly) - PID_angle(&pidx,roll,goalx);
}

//推进器2 -推进器4
float rollpitch_24(float pitch,float roll,float goalx,float goaly)
{
	return PID_angle(&pidy,pitch,goaly) + PID_angle(&pidx,roll,goalx);
}

void Move(void)
{
//	Set_Paddlespeed(1,rollpitch_13(eulerAngle.pitch,eulerAngle.roll,0,0));
//	Set_Paddlespeed(3,-rollpitch_13(eulerAngle.pitch,eulerAngle.roll,0,0));
//	
//	Set_Paddlespeed(2,rollpitch_24(eulerAngle.pitch,eulerAngle.roll,0,0));
//	Set_Paddlespeed(4,-rollpitch_24(eulerAngle.pitch,eulerAngle.roll,0,0));
//	
//	Set_Paddlespeed(5,yaw_56(eulerAngle.yaw,pidz.goal));
//	Set_Paddlespeed(6,-yaw_56(eulerAngle.yaw,pidz.goal));
}

void Push(void) // 5 6
{
	
}

void Turn(void) // 
{
	
}

void Up(void)
{
	
}
