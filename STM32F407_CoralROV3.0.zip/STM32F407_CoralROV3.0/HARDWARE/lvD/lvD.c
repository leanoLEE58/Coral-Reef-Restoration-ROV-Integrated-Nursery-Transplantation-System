#include "lvD.h"

void LvD_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStucture;
    
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource7,GPIO_AF_TIM3);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource0,GPIO_AF_TIM3);
    
	GPIO_InitStucture.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStucture.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStucture.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStucture);
    GPIO_InitStucture.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOB,&GPIO_InitStucture);
    
    GPIO_InitStucture.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStucture.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStucture.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_InitStucture.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_Init(GPIOC,&GPIO_InitStucture);
    
}

//lvdai电机控制，@param n:l-左,r-右    d:f-前进,b-后退,s-停止    s:速度0~100(满速百分比)
void Set_LvDSpeed(u8 n, u8 d, u16 s)
{
    if(s > 80) s = 80;
    s = s * 20;
    if(n == 'l'){
        if(d == 's') TIM_SetCompare2(TIM3, 0);
        else{
            if(d == 'f') l_forward();
            else if(d == 'b') l_backward();
            TIM_SetCompare2(TIM3, s);
        }
    }
    else if(n == 'r'){
        if(d == 's') TIM_SetCompare3(TIM3, 0);
        else{
            if(d == 'b') r_forward();
            else if(d == 'f') r_backward();
            TIM_SetCompare3(TIM3, s);
        }
    }
}
