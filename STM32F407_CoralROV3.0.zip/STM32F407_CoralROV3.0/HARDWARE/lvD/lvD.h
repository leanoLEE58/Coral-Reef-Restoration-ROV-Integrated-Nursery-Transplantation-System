#ifndef __LVD_H
#define __LVD_H
#include "sys.h"

#define l_forward()     GPIO_SetBits(GPIOC, GPIO_Pin_4)
#define l_backward()  GPIO_ResetBits(GPIOC, GPIO_Pin_4)
#define r_forward()     GPIO_SetBits(GPIOC, GPIO_Pin_5)
#define r_backward()  GPIO_ResetBits(GPIOC, GPIO_Pin_5)

void LvD_Init(void);
void Set_LvDSpeed(u8 n, u8 d, u16 s);

#endif
