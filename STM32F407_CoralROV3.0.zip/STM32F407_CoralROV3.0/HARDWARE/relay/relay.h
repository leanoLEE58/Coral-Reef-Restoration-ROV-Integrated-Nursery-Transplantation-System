#ifndef __RELAY_H
#define __RELAY_H
#include "sys.h"


void Relay_Init(void);
void Set_Relaystate(u8 id, u8 state);

#endif
