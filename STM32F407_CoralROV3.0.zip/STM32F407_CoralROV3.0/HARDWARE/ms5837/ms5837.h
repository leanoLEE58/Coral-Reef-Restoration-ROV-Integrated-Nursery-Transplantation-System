#ifndef __MS5837_H
#define __MS5837_H
#include "stdint.h"

extern uint64_t TEMP;
extern uint32_t Pressure;
extern uint32_t Depth;

void MS583703BA_RESET(void);
void MS5837_Init(void);
unsigned long MS583703BA_GetConversion(uint8_t command);
void MS5837_Getdata(void);

#endif
