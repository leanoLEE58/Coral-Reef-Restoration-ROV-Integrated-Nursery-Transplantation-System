#ifndef __SERVO_H
#define __SERVO_H
#include "sys.h"

void Servo_Init(void);
void Set_Servoangle(uint8_t no, float angle);
void Actiongroup(void);

#endif
