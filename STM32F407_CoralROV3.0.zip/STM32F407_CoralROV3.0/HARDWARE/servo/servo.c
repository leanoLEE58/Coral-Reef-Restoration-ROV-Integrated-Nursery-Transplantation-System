#include "servo.h"
#include "delay.h"

void Servo_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStucture;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_OCInitTypeDef TIM_OCInitStucture;
    
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
//    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	
    TIM_InternalClockConfig(TIM2);
    TIM_InternalClockConfig(TIM3);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource15,GPIO_AF_TIM2);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource3 ,GPIO_AF_TIM2);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource10,GPIO_AF_TIM2);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource11,GPIO_AF_TIM2);
//    GPIO_PinAFConfig(GPIOC,GPIO_PinSource9 ,GPIO_AF_TIM3);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource4 ,GPIO_AF_TIM3);
    
	GPIO_InitStucture.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStucture.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStucture.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStucture.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStucture.GPIO_PuPd = GPIO_PuPd_DOWN;
	GPIO_Init(GPIOA,&GPIO_InitStucture);
    GPIO_InitStucture.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_4;
    GPIO_Init(GPIOB,&GPIO_InitStucture);
//    GPIO_InitStucture.GPIO_Pin = GPIO_Pin_9;
//    GPIO_Init(GPIOC,&GPIO_InitStucture);
    
    TIM_TimeBaseStructInit(&TIM_TimeBaseInitStructure);
	
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 2000-1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 840-1;
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);
    TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);
	
	TIM_OCInitStucture.TIM_Pulse = 120;
	TIM_OCInitStucture.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStucture.TIM_OCNPolarity = TIM_OCPolarity_High;
	TIM_OCInitStucture.TIM_OutputState = ENABLE;
	TIM_OC1Init(TIM2,&TIM_OCInitStucture);
    TIM_OC2Init(TIM2,&TIM_OCInitStucture);
    TIM_OC3Init(TIM2,&TIM_OCInitStucture);
    TIM_OC4Init(TIM2,&TIM_OCInitStucture);
    TIM_OCInitStucture.TIM_Pulse = 206;
    TIM_OC1Init(TIM3,&TIM_OCInitStucture);//PB4坏
//    TIM_OC4Init(TIM3,&TIM_OCInitStucture);
    TIM_OCInitStucture.TIM_Pulse = 0;
    TIM_OC2Init(TIM3,&TIM_OCInitStucture);//履带电机
    TIM_OC3Init(TIM3,&TIM_OCInitStucture);//履带电机
    
    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC4PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);//PB4坏
//    TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);//履带电机
    TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);//履带电机

    TIM_ARRPreloadConfig(TIM2,ENABLE);
    TIM_ARRPreloadConfig(TIM3,ENABLE);
	
	TIM_Cmd(TIM2,ENABLE);
    TIM_Cmd(TIM3,ENABLE);   
}

//控制舵机角度，舵机号，0~270°，验证可用√
void Set_Servoangle(uint8_t no, float angle)
{
	if(angle >= 250)
        angle = 250;
    else if(angle <= 20)
        angle = 20;
    
    angle = 50 + angle * 200 / 270;
    
    switch(no)
    {
        case 1:{TIM_SetCompare1(TIM2,angle);break;}
        case 2:{TIM_SetCompare2(TIM2,angle);break;}
        case 3:{TIM_SetCompare3(TIM2,angle);break;}
        case 4:{TIM_SetCompare4(TIM2,angle);break;}
        case 5:{TIM_SetCompare1(TIM3,angle);break;}
        default:
            break;
    }
}
void Actiongroup(void)
{
    Set_Servoangle(1,180);    //down
    Set_Servoangle(2,20);
    Set_Servoangle(3,180);
    Set_Servoangle(4,20);
//    Set_Servoangle(5,240);
    delay_ms(2000);
    Set_Servoangle(1,120);
    Set_Servoangle(2,120);
    Set_Servoangle(3,120);
    Set_Servoangle(4,120);
//    Set_Servoangle(5,120);
    delay_ms(2000);
    Set_Servoangle(1,30);    //up
    Set_Servoangle(2,180);
    Set_Servoangle(3,20);
    Set_Servoangle(4,180);
//    Set_Servoangle(5,60);
    delay_ms(2000);
    Set_Servoangle(1,120);
    Set_Servoangle(2,120);
    Set_Servoangle(3,120);
    Set_Servoangle(4,120);
//    Set_Servoangle(5,120);
    delay_ms(2000);
}
