#ifndef __DAC_H
#define __DAC_H
#include "sys.h"

void dac_Init(void);
void dac_Set_Vol(uint16_t vol);

#endif
