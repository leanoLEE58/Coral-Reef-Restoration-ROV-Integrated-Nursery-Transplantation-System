#include "driver.h"
#include "delay.h"
//#include "usart.h"


uint8_t rcr_remainder;   //重复计数余数部分
uint8_t is_rcr_finish=1; //重复计数器是否设置完成
long rcr_integer;	//重复计数整数部分
long target_pos=0;  //有符号方向
long current_pos=0; //有符号方向
DIR_Type motor_dir=CCW;//顺时针


/************** 驱动器控制信号线初始化 ****************/
void Driver_Init2(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);//使能GPIOG时钟
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);//使能GPIOG时钟
    
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; //DRIVER_DIR DRIVER_OE对应引脚
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//普通输出模式
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉
	GPIO_Init(GPIOE, &GPIO_InitStructure);//初始化GPIOG3,4
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13; //DRIVER_DIR DRIVER_OE对应引脚
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//普通输出模式
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉
	GPIO_Init(GPIOF, &GPIO_InitStructure);//初始化GPIOG3,4
	
	GPIO_ResetBits(GPIOE,GPIO_Pin_10);//PG3输出低 使能输出  DRIVER_ENA
	GPIO_SetBits(GPIOF,GPIO_Pin_13);//PG4输出高 顺时针方向  DRIVER_DIR
}

void Driver_Init1(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);//使能GPIOG时钟
 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12; //DRIVER_DIR DRIVER_OE对应引脚
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//普通输出模式
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉
	GPIO_Init(GPIOF, &GPIO_InitStructure);//初始化GPIOG3,4
	
	GPIO_ResetBits(GPIOF,GPIO_Pin_12);//PG3输出低 使能输出  DRIVER_ENA
	GPIO_SetBits(GPIOF,GPIO_Pin_11);//PG4输出高 顺时针方向  DRIVER_DIR
}

void Driver_Init3(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG, ENABLE);//使能GPIOG时钟
 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7; //DRIVER_DIR DRIVER_OE对应引脚
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//普通输出模式
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉
	GPIO_Init(GPIOG, &GPIO_InitStructure);//初始化GPIOG6,7
	
	GPIO_ResetBits(GPIOG,GPIO_Pin_7);//PG3输出低 使能输出  DRIVER_ENA
	GPIO_SetBits(GPIOG,GPIO_Pin_6);//PG4输出高 顺时针方向  DRIVER_DIR
}

void Driver_Init4(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG, ENABLE);//使能GPIOG时钟
 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12; //DRIVER_DIR DRIVER_OE对应引脚
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//普通输出模式
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉
	GPIO_Init(GPIOG, &GPIO_InitStructure);//初始化GPIOG11，12
	
	GPIO_ResetBits(GPIOG,GPIO_Pin_12);//PG3输出低 使能输出  DRIVER_ENA
	GPIO_SetBits(GPIOG,GPIO_Pin_11);//PG4输出高 顺时针方向  DRIVER_DIR
}

/***********************************************
//TIM1_CH2(PC7) 单脉冲输出+重复计数功能初始化
//TIM1 时钟频率 84*2=168MHz
//arr:自动重装值
//psc:时钟预分频数
************************************************/
void TIM1_OPM_RCR_Init2(uint16_t arr,uint16_t psc)
{		 					 
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);  	//TIM1时钟使能    
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE); 	//使能PORTC时钟	                                                                     	

	GPIO_PinAFConfig(GPIOE,GPIO_PinSource11,GPIO_AF_TIM1); //GPIOC7复用为定时器8
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;           //GPIOC7
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;        //复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;	//速度100MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;      //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;      //下拉
	GPIO_Init(GPIOE,&GPIO_InitStructure);               //初始化PC7
	
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
	
	TIM_TimeBaseStructure.TIM_Period = arr; //设置在下一个更新事件装入活动的自动重装载寄存器周期的值	 
	TIM_TimeBaseStructure.TIM_Prescaler = psc; //设置用来作为TIMx时钟频率除数的预分频值   
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //设置时钟分割:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //TIM向上计数模式
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure); //根据TIM_TimeBaseInitStruct中指定的参数初始化TIMx的时间基数单位
	TIM_ClearITPendingBit(TIM1,TIM_IT_Update);

	TIM_UpdateRequestConfig(TIM1,TIM_UpdateSource_Regular); /********* 设置只有计数溢出作为更新中断 ********/
	TIM_SelectOnePulseMode(TIM1,TIM_OPMode_Single);/******* 单脉冲模式 **********/
 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2; //选择定时器模式:TIM脉冲宽度调制模式2
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //比较输出2使能
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable; /****** 比较输出2N失能 *******/
	TIM_OCInitStructure.TIM_Pulse = arr>>1; //设置待装入捕获比较寄存器的脉冲值，右移一位
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //输出极性:TIM输出比较极性高
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);  //根据TIM_OCInitStruct中指定的参数初始化外设TIMx

	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);  //CH2预装载使能	 
	TIM_ARRPreloadConfig(TIM1, ENABLE); //使能TIMx在ARR上的预装载寄存器
	
	TIM_ITConfig(TIM1, TIM_IT_Update ,ENABLE);  //TIM1   使能或者失能指定的TIM中断
 
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn;  //TIM1中断
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //先占优先级1级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;  //从优先级1级
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQ通道被使能
	NVIC_Init(&NVIC_InitStructure);  //根据NVIC_InitStruct中指定的参数初始化外设NVIC寄存器
	
	TIM_ClearITPendingBit(TIM1, TIM_IT_Update);  //清除TIMx的中断待处理位:TIM 中断源
	TIM_Cmd(TIM1, ENABLE);  //使能TIM1		
	TIM_CtrlPWMOutputs(TIM1, ENABLE);//TIM1 8 !!!!!!!!!	
}

void TIM1_OPM_RCR_Init1(uint16_t arr,uint16_t psc)
{		 					 
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);  	//TIM1时钟使能    
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE); 	//使能PORTC时钟	                                                                     	

	GPIO_PinAFConfig(GPIOE,GPIO_PinSource9,GPIO_AF_TIM1); //GPIOC6复用为定时器8
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;           //GPIOC6
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;        //复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;	//速度100MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;      //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;      //下拉
	GPIO_Init(GPIOE,&GPIO_InitStructure);               //初始化PC6
	
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
	
	TIM_TimeBaseStructure.TIM_Period = arr; //设置在下一个更新事件装入活动的自动重装载寄存器周期的值	 
	TIM_TimeBaseStructure.TIM_Prescaler =psc; //设置用来作为TIMx时钟频率除数的预分频值   
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //设置时钟分割:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //TIM向上计数模式
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure); //根据TIM_TimeBaseInitStruct中指定的参数初始化TIMx的时间基数单位
	TIM_ClearITPendingBit(TIM1,TIM_IT_Update);

	TIM_UpdateRequestConfig(TIM1,TIM_UpdateSource_Regular); /********* 设置只有计数溢出作为更新中断 ********/
	TIM_SelectOnePulseMode(TIM1,TIM_OPMode_Single);/******* 单脉冲模式 **********/
 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //选择定时器模式:TIM脉冲宽度调制模式2
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //比较输出2使能
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable; /****** 比较输出2N失能 *******/
	TIM_OCInitStructure.TIM_Pulse = arr>>1; //设置待装入捕获比较寄存器的脉冲值，右移一位
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //输出极性:TIM输出比较极性高
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);  //根据TIM_OCInitStruct中指定的参数初始化外设TIMx

	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);  //CH2预装载使能	 
	TIM_ARRPreloadConfig(TIM1, ENABLE); //使能TIMx在ARR上的预装载寄存器
	
	TIM_ITConfig(TIM1, TIM_IT_Update ,ENABLE);  //TIM1   使能或者失能指定的TIM中断
 
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn;  //TIM1中断
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //先占优先级1级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;  //从优先级1级
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQ通道被使能
 	NVIC_Init(&NVIC_InitStructure);  //根据NVIC_InitStruct中指定的参数初始化外设NVIC寄存器
	
	TIM_ClearITPendingBit(TIM1, TIM_IT_Update);  //清除TIMx的中断待处理位:TIM 中断源
	TIM_Cmd(TIM1, ENABLE);  //使能TIM1			
	TIM_CtrlPWMOutputs(TIM1, ENABLE);//TIM1 8 !!!!!!!!!	
}

void TIM1_OPM_RCR_Init3(uint16_t arr,uint16_t psc)
{		 					 
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);  	//TIM1时钟使能    
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE); 	//使能PORTC时钟	                                                                     	

	GPIO_PinAFConfig(GPIOE,GPIO_PinSource13,GPIO_AF_TIM1); //GPIOC6复用为定时器8
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;           //GPIOC6
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;        //复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;	//速度100MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;      //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;      //下拉
	GPIO_Init(GPIOE,&GPIO_InitStructure);               //初始化PC6
	
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
	
	TIM_TimeBaseStructure.TIM_Period = arr; //设置在下一个更新事件装入活动的自动重装载寄存器周期的值	 
	TIM_TimeBaseStructure.TIM_Prescaler =psc; //设置用来作为TIMx时钟频率除数的预分频值   
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //设置时钟分割:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //TIM向上计数模式
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure); //根据TIM_TimeBaseInitStruct中指定的参数初始化TIMx的时间基数单位
	TIM_ClearITPendingBit(TIM1,TIM_IT_Update);

	TIM_UpdateRequestConfig(TIM1,TIM_UpdateSource_Regular); /********* 设置只有计数溢出作为更新中断 ********/
	TIM_SelectOnePulseMode(TIM1,TIM_OPMode_Single);/******* 单脉冲模式 **********/
 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //选择定时器模式:TIM脉冲宽度调制模式2
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //比较输出2使能
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable; /****** 比较输出2N失能 *******/
	TIM_OCInitStructure.TIM_Pulse = arr>>1; //设置待装入捕获比较寄存器的脉冲值，右移一位
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //输出极性:TIM输出比较极性高
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);  //根据TIM_OCInitStruct中指定的参数初始化外设TIMx

	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);  //CH2预装载使能	 
	TIM_ARRPreloadConfig(TIM1, ENABLE); //使能TIMx在ARR上的预装载寄存器
	
	TIM_ITConfig(TIM1, TIM_IT_Update ,ENABLE);  //TIM1   使能或者失能指定的TIM中断
 
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn;  //TIM1中断
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //先占优先级1级

	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;  //从优先级1级
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQ通道被使能
 	NVIC_Init(&NVIC_InitStructure);  //根据NVIC_InitStruct中指定的参数初始化外设NVIC寄存器
	
	TIM_ClearITPendingBit(TIM1, TIM_IT_Update);  //清除TIMx的中断待处理位:TIM 中断源
	TIM_Cmd(TIM1, ENABLE);  //使能TIM1			
	TIM_CtrlPWMOutputs(TIM1, ENABLE);//TIM1 8 !!!!!!!!!	
}

void TIM1_OPM_RCR_Init4(uint16_t arr,uint16_t psc)
{		 					 
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);  	//TIM1时钟使能    
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE); 	//使能PORTC时钟	                                                                     	

	GPIO_PinAFConfig(GPIOE,GPIO_PinSource14,GPIO_AF_TIM1); //GPIOC6复用为定时器8
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;           //GPIOC6
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;        //复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;	//速度100MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;      //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;      //下拉
	GPIO_Init(GPIOE,&GPIO_InitStructure);               //初始化PC6
	
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
	
	TIM_TimeBaseStructure.TIM_Period = arr; //设置在下一个更新事件装入活动的自动重装载寄存器周期的值	 
	TIM_TimeBaseStructure.TIM_Prescaler =psc; //设置用来作为TIMx时钟频率除数的预分频值   
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //设置时钟分割:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //TIM向上计数模式
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure); //根据TIM_TimeBaseInitStruct中指定的参数初始化TIMx的时间基数单位
	TIM_ClearITPendingBit(TIM1,TIM_IT_Update);

	TIM_UpdateRequestConfig(TIM1,TIM_UpdateSource_Regular); /********* 设置只有计数溢出作为更新中断 ********/
	TIM_SelectOnePulseMode(TIM1,TIM_OPMode_Single);/******* 单脉冲模式 **********/
 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //选择定时器模式:TIM脉冲宽度调制模式2
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //比较输出2使能
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable; /****** 比较输出2N失能 *******/
	TIM_OCInitStructure.TIM_Pulse = arr>>1; //设置待装入捕获比较寄存器的脉冲值，右移一位
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //输出极性:TIM输出比较极性高
	TIM_OC4Init(TIM1, &TIM_OCInitStructure);  //根据TIM_OCInitStruct中指定的参数初始化外设TIMx

	TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);  //CH2预装载使能	 
	TIM_ARRPreloadConfig(TIM1, ENABLE); //使能TIMx在ARR上的预装载寄存器
	
	TIM_ITConfig(TIM1, TIM_IT_Update ,ENABLE);  //TIM1   使能或者失能指定的TIM中断
 
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn;  //TIM1中断
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  //先占优先级1级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;  //从优先级1级
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQ通道被使能
 	NVIC_Init(&NVIC_InitStructure);  //根据NVIC_InitStruct中指定的参数初始化外设NVIC寄存器
	
	TIM_ClearITPendingBit(TIM1, TIM_IT_Update);  //清除TIMx的中断待处理位:TIM 中断源
	TIM_Cmd(TIM1, ENABLE);  //使能TIM1			
	TIM_CtrlPWMOutputs(TIM1, ENABLE);//TIM1 8 !!!!!!!!!	
}

/******* TIM1更新中断服务程序 *********/
void TIM1_UP_TIM10_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM1,TIM_FLAG_Update)!=RESET)//获取当前定时器状态，判断是否完成更新，更新中断
	{
		TIM_ClearITPendingBit(TIM1,TIM_FLAG_Update);//清除更新中断标志位		
		if(is_rcr_finish==0)//重复计数器未设置完成    重复计数器默认初始值为1，已完成状态
		{
			if(rcr_integer!=0) //整数部分脉冲还未发送完成
			{
				TIM1->RCR=RCR_VAL;//设置重复计数值
				rcr_integer--;//减少RCR_VAL+1个脉冲				
			}else if(rcr_remainder!=0)//余数部分脉冲 不为0
			{
				TIM1->RCR=rcr_remainder-1;//设置余数部分
				rcr_remainder=0;//清零
				is_rcr_finish=1;//重复计数器设置完成				
			}else goto out;   //rcr_remainder=0，直接退出			 
			TIM_GenerateEvent(TIM1,TIM_EventSource_Update);//产生一个更新事件 重新初始化计数器
			TIM_CtrlPWMOutputs(TIM1,ENABLE);	//MOE 主输出使能	
			TIM_Cmd(TIM1, ENABLE);  //使能TIM1			
			if(motor_dir==CW) //如果方向为顺时针   
				current_pos+=(TIM1->RCR+1);//加上重复计数值
			else          //否则方向为逆时针
				current_pos-=(TIM1->RCR+1);//减去重复计数值			
		}else
		{
out:		is_rcr_finish=1;//重复计数器设置完成
			TIM_CtrlPWMOutputs(TIM1,DISABLE);	//MOE 主输出关闭
			TIM_Cmd(TIM1, DISABLE);  //关闭TIM1				V
			//printf("当前位置=%ld\r\n",current_pos);//打印输出
		}	
	}
}

/***************** 启动TIM1 *****************/
void TIM1_Startup1(uint32_t frequency)   //启动定时器8
{
	uint16_t temp_arr=1000000/frequency-1; 
	TIM_SetAutoreload(TIM1,temp_arr);//设定自动重装值	
	TIM_SetCompare1(TIM1,temp_arr>>1); //匹配值2等于重装值一半，是以占空比为50%	
  TIM_SetCounter(TIM1,0);//计数器清零
	TIM_Cmd(TIM1, ENABLE);  //使能TIM1
	
	TIM_SetCompare3(TIM1,0);  //CH3预装载失能
}

void TIM1_Startup2(uint32_t frequency)   //启动定时器8
{
	uint16_t temp_arr=1000000/frequency-1; 
	TIM_SetAutoreload(TIM1,temp_arr);//设定自动重装值	
  TIM_SetCompare2(TIM1,temp_arr>>1); //匹配值2等于重装值一半，是以占空比为50%
	TIM_SetCounter(TIM1,0);//计数器清零
	TIM_Cmd(TIM1, ENABLE);  //使能TIM1
}

void TIM1_Startup3(uint32_t frequency)   //启动定时器8
{
	uint16_t temp_arr=1000000/frequency-1; 
	TIM_SetAutoreload(TIM1,temp_arr);//设定自动重装值	
  TIM_SetCompare3(TIM1,temp_arr>>1); //匹配值2等于重装值一半，是以占空比为50%
	TIM_SetCounter(TIM1,0);//计数器清零
	TIM_Cmd(TIM1, ENABLE);  //使能TIM1
	
	TIM_SetCompare1(TIM1,0);  //CH3预装载失能
}

void TIM1_Startup4(uint32_t frequency)   //启动定时器8
{
	uint16_t temp_arr=1000000/frequency-1; 
	TIM_SetAutoreload(TIM1,temp_arr);//设定自动重装值	
  TIM_SetCompare4(TIM1,temp_arr>>1); //匹配值2等于重装值一半，是以占空比为50%
	TIM_SetCounter(TIM1,0);//计数器清零
	TIM_Cmd(TIM1, ENABLE);  //使能TIM1
}

/********************************************
//相对定位函数 22222222222222222222222222
//num 0～2147483647
//frequency: 20Hz~100KHz
//dir: CW(顺时针方向)  CCW(逆时针方向)
num pwm波
频率是快慢
1000个PWM波是16°23′50″，对应0.28623399弧度
*********************************************/
void Locate_Rle2(long num,uint32_t frequency,DIR_Type dir) //相对定位函数
{
	
	Driver_Init2();			//驱动器初始化
	TIM1_OPM_RCR_Init2(999,168-1); //1MHz计数频率  单脉冲+重复计数模式 
	
	
	if(num<=0) //数值小等于0 则直接返回
	{
		//printf("\r\nThe num should be greater than zero!!\r\n");
		return;
	}
//	if(TIM1->CR1&0x01)//上一次脉冲还未发送完成  直接返回
//	{
//		//printf("\r\nThe last time pulses is not send finished,wait please!\r\n");
//		return;
//	}
	if((frequency<20)||(frequency>100000))//脉冲频率不在范围内 直接返回
	{
		//printf("\r\nThe frequency is out of range! please reset it!!(range:20Hz~100KHz)\r\n");
		return;
	}
	motor_dir=dir;//得到方向	
	DRIVER_DIR_2=motor_dir;//设置方向
	
	if(motor_dir==CW)//顺时针
		target_pos=current_pos+num;//目标位置
	else if(motor_dir==CCW)//逆时针
		target_pos=current_pos-num;//目标位置
	
	rcr_integer=num/(RCR_VAL+1);//重复计数整数部分
	rcr_remainder=num%(RCR_VAL+1);//重复计数余数部分
	is_rcr_finish=0;//重复计数器未设置完成
	TIM1_Startup2(frequency);//开启TIM1
}
/********************************************
//绝对定位函数 2222222222222222222222222
//num   -2147483648～2147483647
//frequency: 20Hz~100KHz
*********************************************/
void Locate_Abs2(long num,uint32_t frequency)//绝对定位函数
{
	if(TIM1->CR1&0x01)//上一次脉冲还未发送完成 直接返回
	{
		//printf("\r\nThe last time pulses is not send finished,wait please!\r\n");
		return;
	}
	if((frequency<20)||(frequency>100000))//脉冲频率不在范围内 直接返回
	{
		//printf("\r\nThe frequency is out of range! please reset it!!(range:20Hz~100KHz)\r\n");
		return;
	}
	target_pos=num;//设置目标位置
	if(target_pos!=current_pos)//目标和当前位置不同
	{
		if(target_pos>current_pos)
			motor_dir=CW;//顺时针
		else
			motor_dir=CCW;//逆时针
		DRIVER_DIR_2=motor_dir;//设置方向
		
		rcr_integer=abs(target_pos-current_pos)/(RCR_VAL+1);//重复计数整数部分
		rcr_remainder=abs(target_pos-current_pos)%(RCR_VAL+1);//重复计数余数部分
		is_rcr_finish=0;//重复计数器设置完成
		TIM1_Startup2(frequency);//开启TIM1
	}
}

/********************************************
//相对定位函数 1111111111111111111111111111
//num 0～2147483647
//frequency: 20Hz~100KHz
//dir: CW(顺时针方向)  CCW(逆时针方向)
num pwm波
频率是快慢
1000个PWM波是16°23′50″，对应0.28623399弧度
*********************************************/
void Locate_Rle1(long num,uint32_t frequency,DIR_Type dir) //相对定位函数
{
	
	
	Driver_Init1();			//驱动器初始化
	TIM1_OPM_RCR_Init1(999,168-1); //1MHz计数频率  单脉冲+重复计数模式 
	
	if(num<=0) //数值小等于0 则直接返回
	{
		//printf("\r\nThe num should be greater than zero!!\r\n");
		return;
	}
//	if(TIM1->CR1&0x01)//上一次脉冲还未发送完成  直接返回
//	{
//		//printf("\r\nThe last time pulses is not send finished,wait please!\r\n");
//		return;
//	}
	if((frequency<20)||(frequency>100000))//脉冲频率不在范围内 直接返回
	{
		//printf("\r\nThe frequency is out of range! please reset it!!(range:20Hz~100KHz)\r\n");
		return;
	}
	motor_dir=dir;//得到方向	
	DRIVER_DIR_1=motor_dir;//设置方向
	
	if(motor_dir==CW)//顺时针
		target_pos=current_pos+num;//目标位置
	else if(motor_dir==CCW)//逆时针
		target_pos=current_pos-num;//目标位置
	
	rcr_integer=num/(RCR_VAL+1);//重复计数整数部分
	rcr_remainder=num%(RCR_VAL+1);//重复计数余数部分
	is_rcr_finish=0;//重复计数器未设置完成
	TIM1_Startup1(frequency);//开启TIM1
}
/********************************************
//绝对定位函数 1111111111111111111111111111111
//num   -2147483648～2147483647
//frequency: 20Hz~100KHz
*********************************************/
void Locate_Abs1(long num,uint32_t frequency)//绝对定位函数
{
	if(TIM1->CR1&0x01)//上一次脉冲还未发送完成 直接返回
	{
		//printf("\r\nThe last time pulses is not send finished,wait please!\r\n");
		return;
	}
	if((frequency<20)||(frequency>100000))//脉冲频率不在范围内 直接返回
	{
		//printf("\r\nThe frequency is out of range! please reset it!!(range:20Hz~100KHz)\r\n");
		return;
	}
	target_pos=num;//设置目标位置
	if(target_pos!=current_pos)//目标和当前位置不同
	{
		if(target_pos>current_pos)
			motor_dir=CW;//顺时针
		else
			motor_dir=CCW;//逆时针
		DRIVER_DIR_1=motor_dir;//设置方向
		
		rcr_integer=abs(target_pos-current_pos)/(RCR_VAL+1);//重复计数整数部分
		rcr_remainder=abs(target_pos-current_pos)%(RCR_VAL+1);//重复计数余数部分
		is_rcr_finish=0;//重复计数器设置完成
		TIM1_Startup1(frequency);//开启TIM1
	}
}

/********************************************
//相对定位函数 333333333333333333333333
//num 0～2147483647
//frequency: 20Hz~100KHz
//dir: CW(顺时针方向)  CCW(逆时针方向)
num pwm波
频率是快慢
1000个PWM波是16°23′50″，对应0.28623399弧度
*********************************************/
void Locate_Rle3(long num,uint32_t frequency,DIR_Type dir) //相对定位函数
{
	
	
	Driver_Init3();			//驱动器初始化
	TIM1_OPM_RCR_Init3(999,168-1); //1MHz计数频率  单脉冲+重复计数模式 
	
	if(num<=0) //数值小等于0 则直接返回
	{
		//printf("\r\nThe num should be greater than zero!!\r\n");
		return;
	}
//	if(TIM1->CR1&0x01)//上一次脉冲还未发送完成  直接返回
//	{
//		//printf("\r\nThe last time pulses is not send finished,wait please!\r\n");
//		return;
//	}
	if((frequency<20)||(frequency>100000))//脉冲频率不在范围内 直接返回
	{
		//printf("\r\nThe frequency is out of range! please reset it!!(range:20Hz~100KHz)\r\n");
		return;
	}
	motor_dir=dir;//得到方向	
	DRIVER_DIR_3=motor_dir;//设置方向
	
	if(motor_dir==CW)//顺时针
		target_pos=current_pos+num;//目标位置
	else if(motor_dir==CCW)//逆时针
		target_pos=current_pos-num;//目标位置
	
	rcr_integer=num/(RCR_VAL+1);//重复计数整数部分
	rcr_remainder=num%(RCR_VAL+1);//重复计数余数部分
	is_rcr_finish=0;//重复计数器未设置完成
	TIM1_Startup3(frequency);//开启TIM1
}
/********************************************
//绝对定位函数 33333333333333333333333333
//num   -2147483648～2147483647
//frequency: 20Hz~100KHz
*********************************************/
void Locate_Abs3(long num,uint32_t frequency)//绝对定位函数
{
	if(TIM1->CR1&0x01)//上一次脉冲还未发送完成 直接返回
	{
		//printf("\r\nThe last time pulses is not send finished,wait please!\r\n");
		return;
	}
	if((frequency<20)||(frequency>100000))//脉冲频率不在范围内 直接返回
	{
		//printf("\r\nThe frequency is out of range! please reset it!!(range:20Hz~100KHz)\r\n");
		return;
	}
	target_pos=num;//设置目标位置
	if(target_pos!=current_pos)//目标和当前位置不同
	{
		if(target_pos>current_pos)
			motor_dir=CW;//顺时针
		else
			motor_dir=CCW;//逆时针
		DRIVER_DIR_3=motor_dir;//设置方向
		
		rcr_integer=abs(target_pos-current_pos)/(RCR_VAL+1);//重复计数整数部分
		rcr_remainder=abs(target_pos-current_pos)%(RCR_VAL+1);//重复计数余数部分
		is_rcr_finish=0;//重复计数器设置完成
		TIM1_Startup3(frequency);//开启TIM1
	}
}

/********************************************
//相对定位函数 44444444444444444444444444
//num 0～2147483647
//frequency: 20Hz~100KHz
//dir: CW(顺时针方向)  CCW(逆时针方向)
num pwm波
频率是快慢
1000个PWM波是16°23′50″，对应0.28623399弧度
*********************************************/
void Locate_Rle4(long num,uint32_t frequency,DIR_Type dir) //相对定位函数
{
	
	
	Driver_Init4();			//驱动器初始化
	TIM1_OPM_RCR_Init4(999,168-1); //1MHz计数频率  单脉冲+重复计数模式 
	
	if(num<=0) //数值小等于0 则直接返回
	{
		//printf("\r\nThe num should be greater than zero!!\r\n");
		return;
	}
//	if(TIM1->CR1&0x01)//上一次脉冲还未发送完成  直接返回
//	{
//		//printf("\r\nThe last time pulses is not send finished,wait please!\r\n");
//		return;
//	}
	if((frequency<20)||(frequency>100000))//脉冲频率不在范围内 直接返回
	{
		//printf("\r\nThe frequency is out of range! please reset it!!(range:20Hz~100KHz)\r\n");
		return;
	}
	motor_dir=dir;//得到方向	
	DRIVER_DIR_4=motor_dir;//设置方向
	
	if(motor_dir==CW)//顺时针
		target_pos=current_pos+num;//目标位置
	else if(motor_dir==CCW)//逆时针
		target_pos=current_pos-num;//目标位置
	
	rcr_integer=num/(RCR_VAL+1);//重复计数整数部分
	rcr_remainder=num%(RCR_VAL+1);//重复计数余数部分
	is_rcr_finish=0;//重复计数器未设置完成
	TIM1_Startup4(frequency);//开启TIM1
}
/********************************************
//绝对定位函数 4444444444444444444444
//num   -2147483648～2147483647
//frequency: 20Hz~100KHz
*********************************************/
void Locate_Abs4(long num,uint32_t frequency)//绝对定位函数
{
	if(TIM1->CR1&0x01)//上一次脉冲还未发送完成 直接返回
	{
		//printf("\r\nThe last time pulses is not send finished,wait please!\r\n");
		return;
	}
	if((frequency<20)||(frequency>100000))//脉冲频率不在范围内 直接返回
	{
		//printf("\r\nThe frequency is out of range! please reset it!!(range:20Hz~100KHz)\r\n");
		return;
	}
	target_pos=num;//设置目标位置
	if(target_pos!=current_pos)//目标和当前位置不同
	{
		if(target_pos>current_pos)
			motor_dir=CW;//顺时针
		else
			motor_dir=CCW;//逆时针
		DRIVER_DIR_4=motor_dir;//设置方向
		
		rcr_integer=abs(target_pos-current_pos)/(RCR_VAL+1);//重复计数整数部分
		rcr_remainder=abs(target_pos-current_pos)%(RCR_VAL+1);//重复计数余数部分
		is_rcr_finish=0;//重复计数器设置完成
		TIM1_Startup4(frequency);//开启TIM1
	}
}

////传感器状态监测,逆时针
//uint8_t Check_Sensor0_State(void)
//{
//	 
//    //Sensor1触发情况
//    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == SET) 
//    {
//			//printf("\n----------Sensor 1 No Trigger---------\n");
//      return NORMAL;
//    }
//    //触发
//    else
//    {
//			//printf("\n----------Sensor 1 has Trigger---------\n");
//      return TAGGLE;    
//    }  
//		//delay_ms(10);
//}


//	//顺时针
//uint8_t Check_Sensor1_State(void)
//{
//		//Sensor2触发情况
//    if(GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_11) == SET) 
//    {
//			//printf("\n----------Sensor 2 No Trigger---------\n");
//      return NORMAL;
//    }
//    //触发
//    else
//    {
//			//printf("\n----------Sensor 2 has Trigger---------\n");
//      return TAGGLE;    
//    }  
//		//delay_ms(10);
//	}

//	
//	//下方
//	uint8_t Check_Sensor2_State(void)
//{
//		
//				//Sensor3触发情况
//    if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_2) == SET) 
//    {
//			//printf("\n----------Sensor 3 No Trigger---------\n");
//      return NORMAL;
//    }
//    //触发
//    else
//    {
//			//printf("\n----------Sensor 3 has Trigger---------\n");
//      return TAGGLE;    
//    } 
//		//delay_ms(10);
//		
//	}

//	
////上方
//	uint8_t Check_Sensor3_State(void)
//{
//		
//				//Sensor4触发情况
//    if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == SET) 
//    {
//			//printf("\n----------4No---------\n");
//      return NORMAL;
//    }
//    //触发
//    else
//    {
//			//printf("\n----------Sensor 4 has Trigger---------\n");
//      return TAGGLE;    
//    } 
//		
//		//delay_ms(10);
// }

//void turnLeft()
//{
//		/*负责控制右方传感器（逆时针）信号检测，检测到金属停止下降
//						测试成功
//				*/
//	while(1){		
//		if(Check_Sensor0_State()==NORMAL){			
//                Locate_RleLR(50,500,CW);
//				delay_ms(10);
//			}
//			else{			
//				return;
//			}
//	}
//}

//void turnRight()
//{
//		/*负责控制右方传感器（逆时针）信号检测，检测到金属停止下降
//						测试成功
//				*/
//	while(1){		
//		if(Check_Sensor1_State()==NORMAL){
//            Locate_RleLR(50,500,CCW);
//            delay_ms(10);
//		}
//		else{
//			return;
//		}
//	}
//}

//void turnUp()
//{
//		/*负责控制上方传感器（逆时针）信号检测，检测到金属停止下降
//						测试成功
//				*/
//		while(1)
//		{
//	  if(Check_Sensor3_State()==NORMAL)
//			{
//			Locate_RleUD(3000,10000,CCW);
//				delay_ms(100);
//			}
//			else
//			{
//				return;
//			}
//		}
//		

//}

//void turnDown()
//{
//		/*负责控制下方传感器（逆时针）信号检测，检测到金属停止下降
//						测试成功
//				*/
//			while(1)
//		{
//	  if(Check_Sensor2_State()==NORMAL)
//			{
//			Locate_RleUD(3000,15000,CW);
//				delay_ms(100);
//			}
//			else
//			{
//				return;
//			}
//		}
//		

//}
