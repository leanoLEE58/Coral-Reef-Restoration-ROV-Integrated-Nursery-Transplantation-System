#ifndef __DRIVER_H
#define __DRIVER_H
#include "sys.h"
#include "stdlib.h"	
#include "stdint.h"	


#define DRIVER_DIR_2   PFout(13) // 旋转方向
#define DRIVER_OE_2    PEout(10) // 使能脚 低电平有效 

#define DRIVER_DIR_1   PFout(11) // 旋转方向
#define DRIVER_OE_1    PFout(12) // 使能脚 低电平有效 

#define DRIVER_DIR_3   PGout(6) // 旋转方向
#define DRIVER_OE_3    PGout(7) // 使能脚 低电平有效 

#define DRIVER_DIR_4   PGout(11) // 旋转方向
#define DRIVER_OE_4    PGout(12) // 使能脚 低电平有效 

#define RCR_VAL    255  //每计数（RCR_VAL+1）次，中断一次，这个值（0~255）设置大一些可以降低中断频率
#define RCR_VAL1    255  //每计数（RCR_VAL+1）次，中断一次，这个值（0~255）设置大一些可以降低中断频率


#define TAGGLE 1
#define NORMAL 0

typedef enum
{
	CW = 1,//高电平顺时针
	CCW = 0,//低电平逆时针
}DIR_Type;//运行方向

extern long target_pos;//有符号方向
extern long current_pos;//有符号方向

void Driver_Init1(void);//驱动器初始化
void Driver_Init2(void);//驱动器初始化
void Driver_Init3(void);//驱动器初始化
void Driver_Init4(void);//驱动器初始化

void TIM1_OPM_RCR_Init1(uint16_t arr,uint16_t psc);//TIM8_CH2 单脉冲输出+重复计数功能初始化
void TIM1_OPM_RCR_Init2(uint16_t arr,uint16_t psc);//TIM8_CH2 单脉冲输出+重复计数功能初始化
void TIM1_OPM_RCR_Init3(uint16_t arr,uint16_t psc);//TIM8_CH2 单脉冲输出+重复计数功能初始化
void TIM1_OPM_RCR_Init4(uint16_t arr,uint16_t psc);//TIM8_CH2 单脉冲输出+重复计数功能初始化

void TIM1_Startup1(uint32_t frequency);   //启动定时器8
void TIM1_Startup2(uint32_t frequency);   //启动定时器8
void TIM1_Startup3(uint32_t frequency);   //启动定时器8
void TIM1_Startup4(uint32_t frequency);   //启动定时器8

void Locate_Rle1(long num,uint32_t frequency,DIR_Type dir); //相对定位函数
void Locate_Abs1(long num,uint32_t frequency);//绝对定位函数

void Locate_Rle2(long num,uint32_t frequency,DIR_Type dir); //相对定位函数
void Locate_Abs2(long num,uint32_t frequency);//绝对定位函数

void Locate_Rle3(long num,uint32_t frequency,DIR_Type dir); //相对定位函数
void Locate_Abs3(long num,uint32_t frequency);//绝对定位函数

void Locate_Rle4(long num,uint32_t frequency,DIR_Type dir); //相对定位函数
void Locate_Abs4(long num,uint32_t frequency);//绝对定位函数

//uint8_t Check_Sensor0_State(void);//水平方向左极限传感器
//uint8_t Check_Sensor1_State(void);//水平方向右极限传感器
//uint8_t Check_Sensor2_State(void);//竖直方向下极限传感器
//uint8_t Check_Sensor3_State(void);//竖直方向上极限传感器

//void turnUp(void);
//void turnDown(void);
//void turnLeft(void);
//void turnRight(void);

#endif


