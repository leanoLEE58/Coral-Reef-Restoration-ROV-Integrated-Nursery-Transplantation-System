#include "control.h"
int main(void)
{
    Contorl_Init();
	while(1)
    {
		Contorl();
//		if(solve_flag==1)
//		{
//			Contorl();
//			solve_flag=0;
//		}
	}
}
