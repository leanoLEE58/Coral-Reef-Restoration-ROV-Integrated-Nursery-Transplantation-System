#include "control.h"

uint8_t RaspberryRxBuf[16];
uint8_t suo_state=0;
uint8_t duoji_state=0;

void Contorl_Init(void)
{
	delay_init(168);    //延时函数初始化
    delay_ms(2000);
	
	MS5837_Init();      //深度传感器
	dac_Init();         //DAC初始化
	adc_Init();         //ADC初始化
	Servo_Init();       //舵机初始化
	Paddle_Init();      //推进器初始化
	MPU_Init();         //姿态传感器
    delay_ms(10);
//	while(mpu_dmp_init()){printf("mpu_dmp_init error\r\n");}
    mpu_dmp_init();
	uart3_Init(9600);   //--printf
	uart5_Init(9600);   //树莓派通信串口
	Relay_Init();       //继电器初始化
    LvD_Init();         //履带电机初始化
    
//    TIM13_Int_Init(100-1,8400-1);//PID定时器初始化 arr/10(ms)
    //PID初始化         P,I,D,积分限幅，输出限幅
    PID_Init(&pid_h, 1, 0, 0, 10000, 10000);
    PID_Init(&pid_v, 1, 0, 0, 10000, 10000);
    
////    Locate_Rle1(2000,5000,CW);//发送脉冲数(2000为90°)，发送脉冲频率，方向
////    Set_Servoangle(1,60);//舵机ID(1~5),舵机角度(0~270°)
////    Set_Paddlespeed(1,10);//推进器ID(1~6)，速度(0~100正转，-100~0反转,绝对值越大速度越大)
////    Set_LvDSpeed('l','f',20);//lvdai电机控制，@param n:l-左,r-右    d:f-前进,b-后退,s-停止    s:速度0~100(满速百分比)
////    Set_Relaystate(u8 id, u8 state);//继电器状态控制，id:1或2；state：1开，0关
////    MS5837_Getdata();//获取当前温度(TEMP/℃)、气压(Pressure/百帕)和水深(Depth/cm)，精度保留到个位
}

void Contorl(void)
{
    RaspuartHandle();
//	printf("control enter\r\n");
//    Actiongroup();
}


void RaspuartHandle(void)
{
	if (isUartRxCompleted) {
		isUartRxCompleted = false;
        printf("%s\r\n",RaspberryRxBuf);
		switch (RaspberryRxBuf[3]) {
        
        case OBJ_PADDLE: 
            Set_Paddlespeed(RaspberryRxBuf[4], RaspberryRxBuf[5]);
            break;
        case OBJ_AG_XiaFang: 
            AG_XiaFang();
            break;
        case OBJ_AG_HuiShou: 
            AG_HuiShou();
            break;
        case OBJ_UP_STEPMOTOR: 
            Locate_Rle1(4000,5000,CW);
            break;
        case OBJ_DOWN_STEPMOTOR: 
			Locate_Rle1(4000,5000,CCW);
            break;
        case OBJ_LvD_QianJin: //履带前进
            AG_LvD_QianJin(40);
            break;
        case OBJ_LvD_HouTui: //履带后退
            AG_LvD_HouTui(40);
            break;
        case OBJ_TJQ_QianJin: //ROV前进
            AG_TJQ_QianJin(RaspberryRxBuf[4]);
            break;
        case OBJ_TJQ_HouTui: //ROV后退
            AG_TJQ_HouTui(RaspberryRxBuf[4]);
            break;
        case OBJ_TJQ_ZuoZhuan: //ROV左转
            AG_TJQ_ZuoZhuan(RaspberryRxBuf[4]);
            break;  
        case OBJ_TJQ_YouZhuan: //ROV右转
            AG_TJQ_YouZhuan(RaspberryRxBuf[4]);
            break;
        case OBJ_TJQ_ShangSheng: //ROV上浮
            AG_TJQ_ShangSheng(RaspberryRxBuf[4]);
            break;
        case OBJ_TJQ_XiaQian: //ROV下潜
            AG_TJQ_XiaQian(RaspberryRxBuf[4]);
            break;
		case OBJ_TJQ_ZuoYi: //ROV左移
            AG_TJQ_ZuoYi(RaspberryRxBuf[4]);
            break;
		case OBJ_TJQ_YouYi: //ROV右移
            AG_TJQ_YouYi(RaspberryRxBuf[4]);
            break;
        case OBJ_TJQ_TingZhi: //推进器停止
            AG_TJQ_TingZhi();
            break;
        case OBJ_LvD_TingZhi: //履带停止
            AG_LvD_TingZhi();
            break;
        case OBJ_CT_Off: //电磁铁
            Set_Relaystate(2, 0);
            break;
        case OBJ_CT_On: //电磁铁
            Set_Relaystate(2, 1);
            break;
        case OBJ_LvD_Right: //履带右转
            AG_LvD_YouZhuan(40);
            break;
        case OBJ_LvD_Left: //履带左转
            AG_LvD_ZuoZhuan(40);
            break;
        case OBJ_SUO: //锁控制
                suo_state+=1;
                suo_state%=2;
             if(suo_state==0)
             {
                 Set_Servoangle(5,180);
                delay_ms(1000);
             }
             else if(suo_state==1)
             {
                 Set_Servoangle(5,30);
                delay_ms(1000);
             }
                break;
//        case OBJ_DUOJI: //下放舵机控制
//                duoji_state+=1;
//                duoji_state%=3;
//            if(duoji_state==0)//中位
//             {
//                Set_Servoangle(1,120);//185下放
//                Set_Servoangle(2,120);
//                Set_Servoangle(3,120);
//                Set_Servoangle(4,120);
//                delay_ms(1500);
//             }
//             else if(duoji_state==1)//低位
//             {
//                Set_Servoangle(1,180);//185下放
//                Set_Servoangle(2,20);
//                Set_Servoangle(3,180);
//                Set_Servoangle(4,20);
//                delay_ms(1500);
//             }
//             else if(duoji_state==2)//高位
//             {
//                Set_Servoangle(1,30);
//                Set_Servoangle(2,180);//30
//                Set_Servoangle(3,20);
//                Set_Servoangle(4,180);
//                delay_ms(1500);
//             }
//                break;
        case OBJ_SET_Para: //设置参数
                Set_para(RaspberryRxBuf[4],RaspberryRxBuf[5],RaspberryRxBuf[6],RaspberryRxBuf[7],RaspberryRxBuf[8],RaspberryRxBuf[9]);
            break;
		case OBJ_AUTO_START: //自动模式
                 AUTO();
            break;
		default:
			break;
		}
	}
}


void Set_para(float h_p, float h_i, float h_d, float v_p, float v_i, float v_d)
{
    pid_h.kp = h_p*0.1f;
    pid_h.ki = h_i;
    pid_h.kd = h_d;
    pid_v.kp = v_p*0.1f;
    pid_v.ki = v_i;
    pid_v.kd = v_d;
    printf("%f, %f, %f, %f, %f, %f\r\n",pid_h.kp, pid_h.ki, pid_h.kd, pid_v.kp, pid_v.ki, pid_v.kd);
}


void AUTO(void)
{
    while(1)
    {
        printf("auto enter\r\n");
        if (isUartRxCompleted)
        {
            isUartRxCompleted = false;
            switch (RaspberryRxBuf[3])
            {
                case OBJ_AUTO_SET:
                    PID_Calc(&pid_h, 0, RaspberryRxBuf[4]-50);
                    PID_Calc(&pid_v, 0, RaspberryRxBuf[5]-50);
                    if(pid_h.output>0)
                    {
                        AG_LvD_QianJin(30);
                        delay_ms(pid_h.output*100/5);
                        AG_LvD_TingZhi();
                        printf("qianjin:%f\r\n",pid_h.output*100);
                    }
                    else if(pid_h.output<0)
                    {
                        AG_LvD_HouTui(30);
                        delay_ms(pid_h.output*100/5);
                        AG_LvD_TingZhi();
                        printf("houtui:%f\r\n",pid_h.output*100);
                    }
                    if(pid_v.output>0)
                    {
                        AG_TJQ_ZuoYi(15);
                        delay_ms(pid_v.output*100/5/2);
                        AG_TJQ_TingZhi();
                        delay_ms(500);
                        printf("youyi:%f\r\n",pid_v.output*100);
                    }
                    else if(pid_v.output<0)
                    {
                        AG_TJQ_YouYi(15);
                        delay_ms(pid_v.output*100/5/2);
                        AG_TJQ_TingZhi();
                        delay_ms(500);
                        printf("zuoyi:%f\r\n",pid_v.output*100);
                    }
                    break;
                case OBJ_AUTO_STOP:
                    printf("auto exit\r\n");
                    return;
                default:
                    break;
            }
        }
    }
}


void AG_XiaFang(void)
{
    //Locate_Rle1(2000,5000,CCW);
    Locate_Rle3(4000,5000,CW);
    delay_ms(1500);
    Set_Servoangle(1,180);//185下放
    Set_Servoangle(2,20);
    Set_Servoangle(3,180);
    Set_Servoangle(4,20);
    delay_ms(1500);
//    Set_Servoangle(5,180);
//    delay_ms(1000);
//    Set_Servoangle(5,30);
    
    
//    Set_Servoangle(1,120);
//    Set_Servoangle(2,120);
//    Set_Servoangle(3,120);
//    Set_Servoangle(4,120);
//    delay_ms(1500);
}


void AG_HuiShou(void)
{
//    Set_Servoangle(1,180);//185下放
//    Set_Servoangle(2,20);
//    Set_Servoangle(3,180);
//    Set_Servoangle(4,20);
//    delay_ms(1500);
    Set_Servoangle(1,30);
    Set_Servoangle(2,180);//30
    Set_Servoangle(3,20);
    Set_Servoangle(4,180);
    delay_ms(1500);
    //Locate_Rle1(2000,5000,CW);
    Locate_Rle3(4000,5000,CCW);//3：间歇机构
    delay_ms(1500);
}


void AG_LvD_QianJin(u16 speed)//speed 0~1000
{
    AG_LvD_TingZhi();
    delay_ms(500);
    Set_LvDSpeed('l', 'f', speed);
    Set_LvDSpeed('r', 'f', speed);
}


void AG_LvD_HouTui(u16 speed)//speed 0~100
{
    AG_LvD_TingZhi();
    delay_ms(500);
    Set_LvDSpeed('l', 'b', speed);
    Set_LvDSpeed('r', 'b', speed);
}


void AG_LvD_TingZhi(void)
{
    Set_LvDSpeed('l', 's', 0);
    Set_LvDSpeed('r', 's', 0);
}


void AG_LvD_ZuoZhuan(u16 speed)//speed 0~100
{
    AG_LvD_TingZhi();
    delay_ms(500);
    Set_LvDSpeed('l', 'b', speed);
    Set_LvDSpeed('r', 'f', speed);
}


void AG_LvD_YouZhuan(u16 speed)//speed 0~100
{
    AG_LvD_TingZhi();
    delay_ms(500);
    Set_LvDSpeed('l', 'f', speed);
    Set_LvDSpeed('r', 'b', speed);
}


void AG_TJQ_ShangSheng(u16 speed)//speed 正转0~100，反转-100~0
{
    Set_Paddlespeed(5, speed);
    Set_Paddlespeed(2, speed);
}


void AG_TJQ_XiaQian(u16 speed)//speed 正转0~100，反转-100~0
{
    Set_Paddlespeed(5, -speed);
    Set_Paddlespeed(2, -speed);
}


void AG_TJQ_QianJin(u16 speed)//speed 正转0~100，反转-100~0
{
	Set_Paddlespeed(1, -speed);
    Set_Paddlespeed(6, -speed);
    Set_Paddlespeed(3, speed);
    Set_Paddlespeed(4, -speed);
}


void AG_TJQ_HouTui(u16 speed)//speed 正转0~100，反转-100~0
{
    Set_Paddlespeed(1,speed);
    Set_Paddlespeed(6,speed);
    Set_Paddlespeed(3,-speed);
    Set_Paddlespeed(4,speed);
}


void AG_TJQ_ZuoYi(u16 speed)//speed 正转0~100，反转-100~0
{
    Set_Paddlespeed(1,-speed);
    Set_Paddlespeed(6,speed);
    Set_Paddlespeed(3,-speed);
    Set_Paddlespeed(4,-speed);
}


void AG_TJQ_YouYi(u16 speed)//speed 正转0~100，反转-100~0
{
    Set_Paddlespeed(1,speed);
    Set_Paddlespeed(6,-speed);
    Set_Paddlespeed(3,speed);
    Set_Paddlespeed(4,speed);
}


void AG_TJQ_ZuoZhuan(u16 speed)//speed 正转0~100，反转-100~0
{
    Set_Paddlespeed(1,speed);
    Set_Paddlespeed(6,-speed);
    Set_Paddlespeed(3,-speed);
    Set_Paddlespeed(4,-speed);
}


void AG_TJQ_YouZhuan(u16 speed)//speed 正转0~100，反转-100~0
{
    Set_Paddlespeed(1,-speed);
    Set_Paddlespeed(6,speed);
    Set_Paddlespeed(3,speed);
    Set_Paddlespeed(4,speed);
}


void AG_TJQ_TingZhi(void)
{
    Set_Paddlespeed(1, 0);
    Set_Paddlespeed(2, 0);
    Set_Paddlespeed(3, 0);
    Set_Paddlespeed(4, 0);
    Set_Paddlespeed(5, 0);
    Set_Paddlespeed(6, 0);
}


//改之前
//void AG_TJQ_ShangSheng(u16 speed)//speed 0~100
//{
//    Set_Paddlespeed(1, -speed);
//    Set_Paddlespeed(4, speed);
//    Set_Paddlespeed(5, speed);
//    Set_Paddlespeed(6, speed);
//}


//void AG_TJQ_XiaQian(u16 speed)//speed 0~100
//{
//    Set_Paddlespeed(1,speed);
//    Set_Paddlespeed(4,-speed);
//    Set_Paddlespeed(5,-speed);
//    Set_Paddlespeed(6,-speed);
//}


//void AG_TJQ_QianJin(u16 speed)//speed 0~100
//{
//    Set_Paddlespeed(3,-speed);
//    Set_Paddlespeed(2,-speed);
//}


//void AG_TJQ_HouTui(u16 speed)//speed 0~100
//{
//    Set_Paddlespeed(3,speed);
//    Set_Paddlespeed(2,speed);
//}


//void AG_TJQ_ZuoZhuan(u16 speed)//speed 0~100
//{
//    Set_Paddlespeed(3,speed);
//    Set_Paddlespeed(2,-speed);
//}


//void AG_TJQ_YouZhuan(u16 speed)//speed 0~100
//{
//    Set_Paddlespeed(3,-speed);
//    Set_Paddlespeed(2,speed);
//}


//void AG_TJQ_TingZhi(void)
//{
//    Set_Paddlespeed(1, 0);
//    Set_Paddlespeed(2, 0);
//    Set_Paddlespeed(3, 0);
//    Set_Paddlespeed(4, 0);
//    Set_Paddlespeed(5, 0);
//    Set_Paddlespeed(6, 0);
//}
