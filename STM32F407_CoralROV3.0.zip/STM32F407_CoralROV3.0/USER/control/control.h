#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
#include "string.h"
#include "delay.h"
//#include "usart.h"
#include "dac.h"        //DAC
#include "adc.h"        //ADC
#include "driver.h"     //步进电机
#include "servo.h"      //舵机
#include "paddle.h"     //推进器
#include "usart3.h"     //--printf
#include "uart5.h"      //通信串口
#include "mpu6050.h"    //姿态传感器
#include "eMPL\inv_mpu.h"
#include "eMPL\inv_mpu_dmp_motion_driver.h"
//#include "Gyroscope_solve.h"
#include "relay.h"      //继电器
#include "ms5837.h"     //深度传感器
#include "lvD.h"        //履带电机
#include "test.h"
#include "PIDtimer.h"   //PID
#include "move_PID.h"
#include "pid.h"

extern uint8_t solve_flag;

void Contorl_Init(void);
void Contorl(void);
void RaspuartHandle(void);

void Set_para(float h_p, float h_i, float h_d, float v_p, float v_i, float v_d);
void AUTO(void);

//---ActionGroup_指令拼音--------//
void AG_XiaFang(void);
void AG_HuiShou(void);

void AG_LvD_QianJin(u16 speed);
void AG_LvD_HouTui(u16 speed);
void AG_LvD_TingZhi(void);
void AG_LvD_ZuoZhuan(u16 speed);
void AG_LvD_YouZhuan(u16 speed);

void AG_TJQ_ShangSheng(u16 speed);
void AG_TJQ_XiaQian(u16 speed);
void AG_TJQ_QianJin(u16 speed);
void AG_TJQ_HouTui(u16 speed);
void AG_TJQ_ZuoYi(u16 speed);
void AG_TJQ_YouYi(u16 speed);
void AG_TJQ_ZuoZhuan(u16 speed);
void AG_TJQ_YouZhuan(u16 speed);
void AG_TJQ_TingZhi(void);

#endif
